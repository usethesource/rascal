package snakes;

public class Die {
	static final int FACES = 6;
	
	public int roll() {
		int result = 1 + (int) (FACES * Math.random());
		assert result >= 1 && result <= FACES;
		return result;
	}
}
