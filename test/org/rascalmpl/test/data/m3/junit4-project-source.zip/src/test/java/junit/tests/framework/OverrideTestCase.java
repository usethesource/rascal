package junit.tests.framework;

/**
 * Test class used in SuiteTest
 */
public class OverrideTestCase extends OneTestCase {
    @Override
    public void testCase() {
    }
}