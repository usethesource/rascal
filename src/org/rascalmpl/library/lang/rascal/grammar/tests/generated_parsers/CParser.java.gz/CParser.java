package org.rascalmpl.library.lang.rascal.grammar.tests.generated_parsers;

import java.io.IOException;
import java.io.StringReader;

import io.usethesource.vallang.type.TypeFactory;
import io.usethesource.vallang.IConstructor;
import io.usethesource.vallang.ISourceLocation;
import io.usethesource.vallang.IValue;
import io.usethesource.vallang.IValueFactory;
import io.usethesource.vallang.exceptions.FactTypeUseException;
import io.usethesource.vallang.io.StandardTextReader;
import org.rascalmpl.parser.gtd.stack.*;
import org.rascalmpl.parser.gtd.stack.filter.*;
import org.rascalmpl.parser.gtd.stack.filter.follow.*;
import org.rascalmpl.parser.gtd.stack.filter.match.*;
import org.rascalmpl.parser.gtd.stack.filter.precede.*;
import org.rascalmpl.parser.gtd.preprocessing.ExpectBuilder;
import org.rascalmpl.parser.gtd.util.IntegerKeyedHashMap;
import org.rascalmpl.parser.gtd.util.IntegerList;
import org.rascalmpl.parser.gtd.util.IntegerMap;
import org.rascalmpl.values.ValueFactoryFactory;
import org.rascalmpl.values.uptr.RascalValueFactory;
import org.rascalmpl.values.uptr.ITree;

@SuppressWarnings("all")
public class CParser extends org.rascalmpl.parser.gtd.SGTDBF<IConstructor, ITree, ISourceLocation> {
  protected final static IValueFactory VF = ValueFactoryFactory.getValueFactory();

  protected static IValue _read(java.lang.String s, io.usethesource.vallang.type.Type type) {
    try {
      return new StandardTextReader().read(VF, org.rascalmpl.values.uptr.RascalValueFactory.uptr, type, new StringReader(s));
    }
    catch (FactTypeUseException e) {
      throw new RuntimeException("unexpected exception in generated parser", e);  
    } catch (IOException e) {
      throw new RuntimeException("unexpected exception in generated parser", e);  
    }
  }
	
  protected static java.lang.String _concat(java.lang.String ...args) {
    int length = 0;
    for (java.lang.String s :args) {
      length += s.length();
    }
    java.lang.StringBuilder b = new java.lang.StringBuilder(length);
    for (java.lang.String s : args) {
      b.append(s);
    }
    return b.toString();
  }
  protected static final TypeFactory _tf = TypeFactory.getInstance();
 
  private static final IntegerMap _resultStoreIdMappings;
  private static final IntegerKeyedHashMap<IntegerList> _dontNest;
	
  protected static void _putDontNest(IntegerKeyedHashMap<IntegerList> result, int parentId, int childId) {
    IntegerList donts = result.get(childId);
    if (donts == null) {
      donts = new IntegerList();
      result.put(childId, donts);
    }
    donts.add(parentId);
  }
    
  protected int getResultStoreId(int parentId) {
    return _resultStoreIdMappings.get(parentId);
  }
    
  protected static IntegerKeyedHashMap<IntegerList> _initDontNest() {
    IntegerKeyedHashMap<IntegerList> result = new IntegerKeyedHashMap<IntegerList>(); 
    
    
    
    
    _putDontNest(result, 1191, 1225);
    
    _putDontNest(result, 277, 336);
    
    _putDontNest(result, 277, 474);
    
    _putDontNest(result, 277, 438);
    
    _putDontNest(result, 277, 391);
    
    _putDontNest(result, 277, 361);
    
    _putDontNest(result, 277, 426);
    
    _putDontNest(result, 277, 462);
    
    _putDontNest(result, 277, 414);
    
    _putDontNest(result, 277, 385);
    
    _putDontNest(result, 277, 316);
    
    _putDontNest(result, 277, 450);
    
    _putDontNest(result, 277, 373);
    
    _putDontNest(result, 277, 323);
    
    _putDontNest(result, 277, 348);
    
    _putDontNest(result, 277, 432);
    
    _putDontNest(result, 277, 329);
    
    _putDontNest(result, 277, 310);
    
    _putDontNest(result, 277, 444);
    
    _putDontNest(result, 277, 456);
    
    _putDontNest(result, 277, 288);
    
    _putDontNest(result, 277, 481);
    
    _putDontNest(result, 277, 468);
    
    _putDontNest(result, 277, 379);
    
    _putDontNest(result, 277, 354);
    
    _putDontNest(result, 277, 420);
    
    _putDontNest(result, 277, 302);
    
    _putDontNest(result, 277, 407);
    
    _putDontNest(result, 277, 342);
    
    _putDontNest(result, 277, 367);
    
    _putDontNest(result, 277, 294);
    
    _putDontNest(result, 277, 397);
    
    _putDontNest(result, 312, 336);
    
    _putDontNest(result, 312, 474);
    
    _putDontNest(result, 312, 438);
    
    _putDontNest(result, 312, 391);
    
    _putDontNest(result, 312, 361);
    
    _putDontNest(result, 312, 426);
    
    _putDontNest(result, 312, 462);
    
    _putDontNest(result, 312, 414);
    
    _putDontNest(result, 312, 385);
    
    _putDontNest(result, 312, 407);
    
    _putDontNest(result, 312, 450);
    
    _putDontNest(result, 312, 373);
    
    _putDontNest(result, 312, 397);
    
    _putDontNest(result, 312, 323);
    
    _putDontNest(result, 312, 348);
    
    _putDontNest(result, 312, 432);
    
    _putDontNest(result, 312, 329);
    
    _putDontNest(result, 312, 444);
    
    _putDontNest(result, 312, 456);
    
    _putDontNest(result, 312, 481);
    
    _putDontNest(result, 312, 468);
    
    _putDontNest(result, 312, 379);
    
    _putDontNest(result, 312, 354);
    
    _putDontNest(result, 312, 420);
    
    _putDontNest(result, 312, 342);
    
    _putDontNest(result, 312, 367);
    
    _putDontNest(result, 361, 474);
    
    _putDontNest(result, 361, 438);
    
    _putDontNest(result, 361, 391);
    
    _putDontNest(result, 361, 361);
    
    _putDontNest(result, 361, 426);
    
    _putDontNest(result, 361, 432);
    
    _putDontNest(result, 361, 462);
    
    _putDontNest(result, 361, 414);
    
    _putDontNest(result, 361, 385);
    
    _putDontNest(result, 361, 407);
    
    _putDontNest(result, 361, 450);
    
    _putDontNest(result, 361, 373);
    
    _putDontNest(result, 361, 367);
    
    _putDontNest(result, 361, 397);
    
    _putDontNest(result, 361, 444);
    
    _putDontNest(result, 361, 456);
    
    _putDontNest(result, 361, 481);
    
    _putDontNest(result, 361, 468);
    
    _putDontNest(result, 361, 379);
    
    _putDontNest(result, 361, 420);
    
    _putDontNest(result, 297, 336);
    
    _putDontNest(result, 297, 474);
    
    _putDontNest(result, 297, 438);
    
    _putDontNest(result, 297, 391);
    
    _putDontNest(result, 297, 361);
    
    _putDontNest(result, 297, 426);
    
    _putDontNest(result, 297, 462);
    
    _putDontNest(result, 297, 414);
    
    _putDontNest(result, 297, 385);
    
    _putDontNest(result, 297, 316);
    
    _putDontNest(result, 297, 407);
    
    _putDontNest(result, 297, 450);
    
    _putDontNest(result, 297, 373);
    
    _putDontNest(result, 297, 397);
    
    _putDontNest(result, 297, 323);
    
    _putDontNest(result, 297, 348);
    
    _putDontNest(result, 297, 432);
    
    _putDontNest(result, 297, 329);
    
    _putDontNest(result, 297, 310);
    
    _putDontNest(result, 297, 444);
    
    _putDontNest(result, 297, 456);
    
    _putDontNest(result, 297, 481);
    
    _putDontNest(result, 297, 468);
    
    _putDontNest(result, 297, 379);
    
    _putDontNest(result, 297, 354);
    
    _putDontNest(result, 297, 420);
    
    _putDontNest(result, 297, 342);
    
    _putDontNest(result, 297, 367);
    
    _putDontNest(result, 336, 336);
    
    _putDontNest(result, 336, 474);
    
    _putDontNest(result, 336, 438);
    
    _putDontNest(result, 336, 348);
    
    _putDontNest(result, 336, 391);
    
    _putDontNest(result, 336, 361);
    
    _putDontNest(result, 336, 426);
    
    _putDontNest(result, 336, 432);
    
    _putDontNest(result, 336, 462);
    
    _putDontNest(result, 336, 414);
    
    _putDontNest(result, 336, 385);
    
    _putDontNest(result, 336, 407);
    
    _putDontNest(result, 336, 450);
    
    _putDontNest(result, 336, 373);
    
    _putDontNest(result, 336, 397);
    
    _putDontNest(result, 336, 444);
    
    _putDontNest(result, 336, 456);
    
    _putDontNest(result, 336, 481);
    
    _putDontNest(result, 336, 468);
    
    _putDontNest(result, 336, 379);
    
    _putDontNest(result, 336, 354);
    
    _putDontNest(result, 336, 420);
    
    _putDontNest(result, 336, 342);
    
    _putDontNest(result, 336, 367);
    
    _putDontNest(result, 265, 336);
    
    _putDontNest(result, 265, 474);
    
    _putDontNest(result, 265, 438);
    
    _putDontNest(result, 265, 391);
    
    _putDontNest(result, 265, 361);
    
    _putDontNest(result, 265, 426);
    
    _putDontNest(result, 265, 462);
    
    _putDontNest(result, 265, 414);
    
    _putDontNest(result, 265, 385);
    
    _putDontNest(result, 265, 316);
    
    _putDontNest(result, 265, 450);
    
    _putDontNest(result, 265, 373);
    
    _putDontNest(result, 265, 323);
    
    _putDontNest(result, 265, 348);
    
    _putDontNest(result, 265, 432);
    
    _putDontNest(result, 265, 329);
    
    _putDontNest(result, 265, 310);
    
    _putDontNest(result, 265, 444);
    
    _putDontNest(result, 265, 456);
    
    _putDontNest(result, 265, 288);
    
    _putDontNest(result, 265, 481);
    
    _putDontNest(result, 265, 468);
    
    _putDontNest(result, 265, 379);
    
    _putDontNest(result, 265, 354);
    
    _putDontNest(result, 265, 420);
    
    _putDontNest(result, 265, 302);
    
    _putDontNest(result, 265, 407);
    
    _putDontNest(result, 265, 342);
    
    _putDontNest(result, 265, 367);
    
    _putDontNest(result, 265, 294);
    
    _putDontNest(result, 265, 397);
    
    _putDontNest(result, 474, 481);
    
    _putDontNest(result, 338, 474);
    
    _putDontNest(result, 338, 438);
    
    _putDontNest(result, 338, 391);
    
    _putDontNest(result, 338, 361);
    
    _putDontNest(result, 338, 426);
    
    _putDontNest(result, 338, 432);
    
    _putDontNest(result, 338, 462);
    
    _putDontNest(result, 338, 414);
    
    _putDontNest(result, 338, 385);
    
    _putDontNest(result, 338, 407);
    
    _putDontNest(result, 338, 450);
    
    _putDontNest(result, 338, 373);
    
    _putDontNest(result, 338, 367);
    
    _putDontNest(result, 338, 397);
    
    _putDontNest(result, 338, 444);
    
    _putDontNest(result, 338, 456);
    
    _putDontNest(result, 338, 481);
    
    _putDontNest(result, 338, 468);
    
    _putDontNest(result, 338, 379);
    
    _putDontNest(result, 338, 420);
    
    _putDontNest(result, 438, 481);
    
    _putDontNest(result, 1507, 1534);
    
    _putDontNest(result, 166, 277);
    
    _putDontNest(result, 166, 474);
    
    _putDontNest(result, 166, 438);
    
    _putDontNest(result, 166, 361);
    
    _putDontNest(result, 166, 426);
    
    _putDontNest(result, 166, 462);
    
    _putDontNest(result, 166, 414);
    
    _putDontNest(result, 166, 316);
    
    _putDontNest(result, 166, 450);
    
    _putDontNest(result, 166, 373);
    
    _putDontNest(result, 166, 336);
    
    _putDontNest(result, 166, 265);
    
    _putDontNest(result, 166, 323);
    
    _putDontNest(result, 166, 348);
    
    _putDontNest(result, 166, 273);
    
    _putDontNest(result, 166, 240);
    
    _putDontNest(result, 166, 257);
    
    _putDontNest(result, 166, 391);
    
    _putDontNest(result, 166, 247);
    
    _putDontNest(result, 166, 432);
    
    _putDontNest(result, 166, 329);
    
    _putDontNest(result, 166, 310);
    
    _putDontNest(result, 166, 444);
    
    _putDontNest(result, 166, 261);
    
    _putDontNest(result, 166, 456);
    
    _putDontNest(result, 166, 288);
    
    _putDontNest(result, 166, 385);
    
    _putDontNest(result, 166, 281);
    
    _putDontNest(result, 166, 481);
    
    _putDontNest(result, 166, 468);
    
    _putDontNest(result, 166, 379);
    
    _putDontNest(result, 166, 354);
    
    _putDontNest(result, 166, 420);
    
    _putDontNest(result, 166, 302);
    
    _putDontNest(result, 166, 407);
    
    _putDontNest(result, 166, 235);
    
    _putDontNest(result, 166, 342);
    
    _putDontNest(result, 166, 367);
    
    _putDontNest(result, 166, 294);
    
    _putDontNest(result, 166, 397);
    
    _putDontNest(result, 166, 253);
    
    _putDontNest(result, 325, 336);
    
    _putDontNest(result, 325, 474);
    
    _putDontNest(result, 325, 438);
    
    _putDontNest(result, 325, 348);
    
    _putDontNest(result, 325, 391);
    
    _putDontNest(result, 325, 361);
    
    _putDontNest(result, 325, 426);
    
    _putDontNest(result, 325, 432);
    
    _putDontNest(result, 325, 462);
    
    _putDontNest(result, 325, 414);
    
    _putDontNest(result, 325, 385);
    
    _putDontNest(result, 325, 407);
    
    _putDontNest(result, 325, 450);
    
    _putDontNest(result, 325, 373);
    
    _putDontNest(result, 325, 397);
    
    _putDontNest(result, 325, 444);
    
    _putDontNest(result, 325, 456);
    
    _putDontNest(result, 325, 481);
    
    _putDontNest(result, 325, 468);
    
    _putDontNest(result, 325, 379);
    
    _putDontNest(result, 325, 354);
    
    _putDontNest(result, 325, 420);
    
    _putDontNest(result, 325, 342);
    
    _putDontNest(result, 325, 367);
    
    _putDontNest(result, 323, 336);
    
    _putDontNest(result, 323, 474);
    
    _putDontNest(result, 323, 438);
    
    _putDontNest(result, 323, 391);
    
    _putDontNest(result, 323, 361);
    
    _putDontNest(result, 323, 426);
    
    _putDontNest(result, 323, 462);
    
    _putDontNest(result, 323, 414);
    
    _putDontNest(result, 323, 385);
    
    _putDontNest(result, 323, 407);
    
    _putDontNest(result, 323, 450);
    
    _putDontNest(result, 323, 373);
    
    _putDontNest(result, 323, 397);
    
    _putDontNest(result, 323, 323);
    
    _putDontNest(result, 323, 348);
    
    _putDontNest(result, 323, 432);
    
    _putDontNest(result, 323, 329);
    
    _putDontNest(result, 323, 444);
    
    _putDontNest(result, 323, 456);
    
    _putDontNest(result, 323, 481);
    
    _putDontNest(result, 323, 468);
    
    _putDontNest(result, 323, 379);
    
    _putDontNest(result, 323, 354);
    
    _putDontNest(result, 323, 420);
    
    _putDontNest(result, 323, 342);
    
    _putDontNest(result, 323, 367);
    
    _putDontNest(result, 348, 336);
    
    _putDontNest(result, 348, 474);
    
    _putDontNest(result, 348, 438);
    
    _putDontNest(result, 348, 348);
    
    _putDontNest(result, 348, 391);
    
    _putDontNest(result, 348, 361);
    
    _putDontNest(result, 348, 426);
    
    _putDontNest(result, 348, 432);
    
    _putDontNest(result, 348, 462);
    
    _putDontNest(result, 348, 414);
    
    _putDontNest(result, 348, 385);
    
    _putDontNest(result, 348, 407);
    
    _putDontNest(result, 348, 450);
    
    _putDontNest(result, 348, 373);
    
    _putDontNest(result, 348, 397);
    
    _putDontNest(result, 348, 444);
    
    _putDontNest(result, 348, 456);
    
    _putDontNest(result, 348, 481);
    
    _putDontNest(result, 348, 468);
    
    _putDontNest(result, 348, 379);
    
    _putDontNest(result, 348, 354);
    
    _putDontNest(result, 348, 420);
    
    _putDontNest(result, 348, 342);
    
    _putDontNest(result, 348, 367);
    
    _putDontNest(result, 452, 474);
    
    _putDontNest(result, 452, 438);
    
    _putDontNest(result, 452, 426);
    
    _putDontNest(result, 452, 432);
    
    _putDontNest(result, 452, 462);
    
    _putDontNest(result, 452, 414);
    
    _putDontNest(result, 452, 420);
    
    _putDontNest(result, 452, 450);
    
    _putDontNest(result, 452, 444);
    
    _putDontNest(result, 452, 456);
    
    _putDontNest(result, 452, 481);
    
    _putDontNest(result, 452, 468);
    
    _putDontNest(result, 273, 336);
    
    _putDontNest(result, 273, 474);
    
    _putDontNest(result, 273, 438);
    
    _putDontNest(result, 273, 391);
    
    _putDontNest(result, 273, 361);
    
    _putDontNest(result, 273, 426);
    
    _putDontNest(result, 273, 462);
    
    _putDontNest(result, 273, 414);
    
    _putDontNest(result, 273, 385);
    
    _putDontNest(result, 273, 316);
    
    _putDontNest(result, 273, 450);
    
    _putDontNest(result, 273, 373);
    
    _putDontNest(result, 273, 323);
    
    _putDontNest(result, 273, 348);
    
    _putDontNest(result, 273, 432);
    
    _putDontNest(result, 273, 329);
    
    _putDontNest(result, 273, 310);
    
    _putDontNest(result, 273, 444);
    
    _putDontNest(result, 273, 456);
    
    _putDontNest(result, 273, 288);
    
    _putDontNest(result, 273, 481);
    
    _putDontNest(result, 273, 468);
    
    _putDontNest(result, 273, 379);
    
    _putDontNest(result, 273, 354);
    
    _putDontNest(result, 273, 420);
    
    _putDontNest(result, 273, 302);
    
    _putDontNest(result, 273, 407);
    
    _putDontNest(result, 273, 342);
    
    _putDontNest(result, 273, 367);
    
    _putDontNest(result, 273, 294);
    
    _putDontNest(result, 273, 397);
    
    _putDontNest(result, 240, 336);
    
    _putDontNest(result, 240, 474);
    
    _putDontNest(result, 240, 438);
    
    _putDontNest(result, 240, 391);
    
    _putDontNest(result, 240, 361);
    
    _putDontNest(result, 240, 426);
    
    _putDontNest(result, 240, 462);
    
    _putDontNest(result, 240, 414);
    
    _putDontNest(result, 240, 385);
    
    _putDontNest(result, 240, 316);
    
    _putDontNest(result, 240, 450);
    
    _putDontNest(result, 240, 373);
    
    _putDontNest(result, 240, 323);
    
    _putDontNest(result, 240, 348);
    
    _putDontNest(result, 240, 432);
    
    _putDontNest(result, 240, 329);
    
    _putDontNest(result, 240, 310);
    
    _putDontNest(result, 240, 444);
    
    _putDontNest(result, 240, 456);
    
    _putDontNest(result, 240, 288);
    
    _putDontNest(result, 240, 481);
    
    _putDontNest(result, 240, 468);
    
    _putDontNest(result, 240, 379);
    
    _putDontNest(result, 240, 354);
    
    _putDontNest(result, 240, 420);
    
    _putDontNest(result, 240, 302);
    
    _putDontNest(result, 240, 407);
    
    _putDontNest(result, 240, 342);
    
    _putDontNest(result, 240, 367);
    
    _putDontNest(result, 240, 294);
    
    _putDontNest(result, 240, 397);
    
    _putDontNest(result, 350, 474);
    
    _putDontNest(result, 350, 438);
    
    _putDontNest(result, 350, 391);
    
    _putDontNest(result, 350, 361);
    
    _putDontNest(result, 350, 426);
    
    _putDontNest(result, 350, 432);
    
    _putDontNest(result, 350, 462);
    
    _putDontNest(result, 350, 414);
    
    _putDontNest(result, 350, 385);
    
    _putDontNest(result, 350, 407);
    
    _putDontNest(result, 350, 450);
    
    _putDontNest(result, 350, 373);
    
    _putDontNest(result, 350, 367);
    
    _putDontNest(result, 350, 397);
    
    _putDontNest(result, 350, 444);
    
    _putDontNest(result, 350, 456);
    
    _putDontNest(result, 350, 481);
    
    _putDontNest(result, 350, 468);
    
    _putDontNest(result, 350, 379);
    
    _putDontNest(result, 350, 420);
    
    _putDontNest(result, 177, 277);
    
    _putDontNest(result, 177, 474);
    
    _putDontNest(result, 177, 438);
    
    _putDontNest(result, 177, 361);
    
    _putDontNest(result, 177, 426);
    
    _putDontNest(result, 177, 462);
    
    _putDontNest(result, 177, 414);
    
    _putDontNest(result, 177, 316);
    
    _putDontNest(result, 177, 450);
    
    _putDontNest(result, 177, 373);
    
    _putDontNest(result, 177, 336);
    
    _putDontNest(result, 177, 265);
    
    _putDontNest(result, 177, 323);
    
    _putDontNest(result, 177, 348);
    
    _putDontNest(result, 177, 273);
    
    _putDontNest(result, 177, 240);
    
    _putDontNest(result, 177, 257);
    
    _putDontNest(result, 177, 391);
    
    _putDontNest(result, 177, 247);
    
    _putDontNest(result, 177, 432);
    
    _putDontNest(result, 177, 329);
    
    _putDontNest(result, 177, 310);
    
    _putDontNest(result, 177, 444);
    
    _putDontNest(result, 177, 261);
    
    _putDontNest(result, 177, 456);
    
    _putDontNest(result, 177, 288);
    
    _putDontNest(result, 177, 385);
    
    _putDontNest(result, 177, 281);
    
    _putDontNest(result, 177, 481);
    
    _putDontNest(result, 177, 468);
    
    _putDontNest(result, 177, 379);
    
    _putDontNest(result, 177, 354);
    
    _putDontNest(result, 177, 420);
    
    _putDontNest(result, 177, 302);
    
    _putDontNest(result, 177, 407);
    
    _putDontNest(result, 177, 235);
    
    _putDontNest(result, 177, 342);
    
    _putDontNest(result, 177, 367);
    
    _putDontNest(result, 177, 294);
    
    _putDontNest(result, 177, 397);
    
    _putDontNest(result, 177, 253);
    
    _putDontNest(result, 375, 474);
    
    _putDontNest(result, 375, 438);
    
    _putDontNest(result, 375, 391);
    
    _putDontNest(result, 375, 426);
    
    _putDontNest(result, 375, 432);
    
    _putDontNest(result, 375, 462);
    
    _putDontNest(result, 375, 414);
    
    _putDontNest(result, 375, 385);
    
    _putDontNest(result, 375, 420);
    
    _putDontNest(result, 375, 407);
    
    _putDontNest(result, 375, 450);
    
    _putDontNest(result, 375, 397);
    
    _putDontNest(result, 375, 444);
    
    _putDontNest(result, 375, 456);
    
    _putDontNest(result, 375, 481);
    
    _putDontNest(result, 375, 468);
    
    _putDontNest(result, 195, 277);
    
    _putDontNest(result, 195, 474);
    
    _putDontNest(result, 195, 438);
    
    _putDontNest(result, 195, 361);
    
    _putDontNest(result, 195, 426);
    
    _putDontNest(result, 195, 462);
    
    _putDontNest(result, 195, 414);
    
    _putDontNest(result, 195, 316);
    
    _putDontNest(result, 195, 450);
    
    _putDontNest(result, 195, 373);
    
    _putDontNest(result, 195, 336);
    
    _putDontNest(result, 195, 265);
    
    _putDontNest(result, 195, 323);
    
    _putDontNest(result, 195, 348);
    
    _putDontNest(result, 195, 273);
    
    _putDontNest(result, 195, 240);
    
    _putDontNest(result, 195, 257);
    
    _putDontNest(result, 195, 391);
    
    _putDontNest(result, 195, 247);
    
    _putDontNest(result, 195, 432);
    
    _putDontNest(result, 195, 329);
    
    _putDontNest(result, 195, 310);
    
    _putDontNest(result, 195, 444);
    
    _putDontNest(result, 195, 261);
    
    _putDontNest(result, 195, 456);
    
    _putDontNest(result, 195, 288);
    
    _putDontNest(result, 195, 385);
    
    _putDontNest(result, 195, 281);
    
    _putDontNest(result, 195, 481);
    
    _putDontNest(result, 195, 468);
    
    _putDontNest(result, 195, 379);
    
    _putDontNest(result, 195, 354);
    
    _putDontNest(result, 195, 420);
    
    _putDontNest(result, 195, 302);
    
    _putDontNest(result, 195, 407);
    
    _putDontNest(result, 195, 235);
    
    _putDontNest(result, 195, 342);
    
    _putDontNest(result, 195, 367);
    
    _putDontNest(result, 195, 294);
    
    _putDontNest(result, 195, 397);
    
    _putDontNest(result, 195, 253);
    
    _putDontNest(result, 357, 474);
    
    _putDontNest(result, 357, 438);
    
    _putDontNest(result, 357, 391);
    
    _putDontNest(result, 357, 426);
    
    _putDontNest(result, 357, 432);
    
    _putDontNest(result, 357, 462);
    
    _putDontNest(result, 357, 414);
    
    _putDontNest(result, 357, 385);
    
    _putDontNest(result, 357, 407);
    
    _putDontNest(result, 357, 450);
    
    _putDontNest(result, 357, 373);
    
    _putDontNest(result, 357, 397);
    
    _putDontNest(result, 357, 444);
    
    _putDontNest(result, 357, 456);
    
    _putDontNest(result, 357, 481);
    
    _putDontNest(result, 357, 468);
    
    _putDontNest(result, 357, 379);
    
    _putDontNest(result, 357, 420);
    
    _putDontNest(result, 189, 277);
    
    _putDontNest(result, 189, 474);
    
    _putDontNest(result, 189, 438);
    
    _putDontNest(result, 189, 361);
    
    _putDontNest(result, 189, 426);
    
    _putDontNest(result, 189, 462);
    
    _putDontNest(result, 189, 414);
    
    _putDontNest(result, 189, 316);
    
    _putDontNest(result, 189, 450);
    
    _putDontNest(result, 189, 373);
    
    _putDontNest(result, 189, 336);
    
    _putDontNest(result, 189, 265);
    
    _putDontNest(result, 189, 323);
    
    _putDontNest(result, 189, 348);
    
    _putDontNest(result, 189, 273);
    
    _putDontNest(result, 189, 240);
    
    _putDontNest(result, 189, 257);
    
    _putDontNest(result, 189, 391);
    
    _putDontNest(result, 189, 247);
    
    _putDontNest(result, 189, 432);
    
    _putDontNest(result, 189, 329);
    
    _putDontNest(result, 189, 310);
    
    _putDontNest(result, 189, 444);
    
    _putDontNest(result, 189, 261);
    
    _putDontNest(result, 189, 456);
    
    _putDontNest(result, 189, 288);
    
    _putDontNest(result, 189, 385);
    
    _putDontNest(result, 189, 281);
    
    _putDontNest(result, 189, 481);
    
    _putDontNest(result, 189, 468);
    
    _putDontNest(result, 189, 379);
    
    _putDontNest(result, 189, 354);
    
    _putDontNest(result, 189, 420);
    
    _putDontNest(result, 189, 302);
    
    _putDontNest(result, 189, 407);
    
    _putDontNest(result, 189, 235);
    
    _putDontNest(result, 189, 342);
    
    _putDontNest(result, 189, 367);
    
    _putDontNest(result, 189, 294);
    
    _putDontNest(result, 189, 397);
    
    _putDontNest(result, 189, 253);
    
    _putDontNest(result, 257, 336);
    
    _putDontNest(result, 257, 474);
    
    _putDontNest(result, 257, 438);
    
    _putDontNest(result, 257, 391);
    
    _putDontNest(result, 257, 361);
    
    _putDontNest(result, 257, 426);
    
    _putDontNest(result, 257, 462);
    
    _putDontNest(result, 257, 414);
    
    _putDontNest(result, 257, 385);
    
    _putDontNest(result, 257, 316);
    
    _putDontNest(result, 257, 450);
    
    _putDontNest(result, 257, 373);
    
    _putDontNest(result, 257, 323);
    
    _putDontNest(result, 257, 348);
    
    _putDontNest(result, 257, 432);
    
    _putDontNest(result, 257, 329);
    
    _putDontNest(result, 257, 310);
    
    _putDontNest(result, 257, 444);
    
    _putDontNest(result, 257, 456);
    
    _putDontNest(result, 257, 288);
    
    _putDontNest(result, 257, 481);
    
    _putDontNest(result, 257, 468);
    
    _putDontNest(result, 257, 379);
    
    _putDontNest(result, 257, 354);
    
    _putDontNest(result, 257, 420);
    
    _putDontNest(result, 257, 302);
    
    _putDontNest(result, 257, 407);
    
    _putDontNest(result, 257, 342);
    
    _putDontNest(result, 257, 367);
    
    _putDontNest(result, 257, 294);
    
    _putDontNest(result, 257, 397);
    
    _putDontNest(result, 391, 474);
    
    _putDontNest(result, 391, 438);
    
    _putDontNest(result, 391, 426);
    
    _putDontNest(result, 391, 432);
    
    _putDontNest(result, 391, 462);
    
    _putDontNest(result, 391, 414);
    
    _putDontNest(result, 391, 420);
    
    _putDontNest(result, 391, 407);
    
    _putDontNest(result, 391, 450);
    
    _putDontNest(result, 391, 397);
    
    _putDontNest(result, 391, 444);
    
    _putDontNest(result, 391, 456);
    
    _putDontNest(result, 391, 481);
    
    _putDontNest(result, 391, 468);
    
    _putDontNest(result, 247, 336);
    
    _putDontNest(result, 247, 474);
    
    _putDontNest(result, 247, 438);
    
    _putDontNest(result, 247, 391);
    
    _putDontNest(result, 247, 361);
    
    _putDontNest(result, 247, 426);
    
    _putDontNest(result, 247, 462);
    
    _putDontNest(result, 247, 414);
    
    _putDontNest(result, 247, 385);
    
    _putDontNest(result, 247, 316);
    
    _putDontNest(result, 247, 450);
    
    _putDontNest(result, 247, 373);
    
    _putDontNest(result, 247, 323);
    
    _putDontNest(result, 247, 348);
    
    _putDontNest(result, 247, 432);
    
    _putDontNest(result, 247, 329);
    
    _putDontNest(result, 247, 310);
    
    _putDontNest(result, 247, 444);
    
    _putDontNest(result, 247, 456);
    
    _putDontNest(result, 247, 288);
    
    _putDontNest(result, 247, 481);
    
    _putDontNest(result, 247, 468);
    
    _putDontNest(result, 247, 379);
    
    _putDontNest(result, 247, 354);
    
    _putDontNest(result, 247, 420);
    
    _putDontNest(result, 247, 302);
    
    _putDontNest(result, 247, 407);
    
    _putDontNest(result, 247, 342);
    
    _putDontNest(result, 247, 367);
    
    _putDontNest(result, 247, 294);
    
    _putDontNest(result, 247, 397);
    
    _putDontNest(result, 426, 481);
    
    _putDontNest(result, 399, 474);
    
    _putDontNest(result, 399, 438);
    
    _putDontNest(result, 399, 426);
    
    _putDontNest(result, 399, 432);
    
    _putDontNest(result, 399, 462);
    
    _putDontNest(result, 399, 414);
    
    _putDontNest(result, 399, 420);
    
    _putDontNest(result, 399, 450);
    
    _putDontNest(result, 399, 444);
    
    _putDontNest(result, 399, 456);
    
    _putDontNest(result, 399, 481);
    
    _putDontNest(result, 399, 468);
    
    _putDontNest(result, 432, 481);
    
    _putDontNest(result, 329, 336);
    
    _putDontNest(result, 329, 474);
    
    _putDontNest(result, 329, 438);
    
    _putDontNest(result, 329, 391);
    
    _putDontNest(result, 329, 361);
    
    _putDontNest(result, 329, 426);
    
    _putDontNest(result, 329, 462);
    
    _putDontNest(result, 329, 414);
    
    _putDontNest(result, 329, 385);
    
    _putDontNest(result, 329, 407);
    
    _putDontNest(result, 329, 450);
    
    _putDontNest(result, 329, 373);
    
    _putDontNest(result, 329, 397);
    
    _putDontNest(result, 329, 323);
    
    _putDontNest(result, 329, 348);
    
    _putDontNest(result, 329, 432);
    
    _putDontNest(result, 329, 329);
    
    _putDontNest(result, 329, 444);
    
    _putDontNest(result, 329, 456);
    
    _putDontNest(result, 329, 481);
    
    _putDontNest(result, 329, 468);
    
    _putDontNest(result, 329, 379);
    
    _putDontNest(result, 329, 354);
    
    _putDontNest(result, 329, 420);
    
    _putDontNest(result, 329, 342);
    
    _putDontNest(result, 329, 367);
    
    _putDontNest(result, 310, 336);
    
    _putDontNest(result, 310, 474);
    
    _putDontNest(result, 310, 438);
    
    _putDontNest(result, 310, 391);
    
    _putDontNest(result, 310, 361);
    
    _putDontNest(result, 310, 426);
    
    _putDontNest(result, 310, 462);
    
    _putDontNest(result, 310, 414);
    
    _putDontNest(result, 310, 385);
    
    _putDontNest(result, 310, 316);
    
    _putDontNest(result, 310, 407);
    
    _putDontNest(result, 310, 450);
    
    _putDontNest(result, 310, 373);
    
    _putDontNest(result, 310, 397);
    
    _putDontNest(result, 310, 323);
    
    _putDontNest(result, 310, 348);
    
    _putDontNest(result, 310, 432);
    
    _putDontNest(result, 310, 329);
    
    _putDontNest(result, 310, 310);
    
    _putDontNest(result, 310, 444);
    
    _putDontNest(result, 310, 456);
    
    _putDontNest(result, 310, 481);
    
    _putDontNest(result, 310, 468);
    
    _putDontNest(result, 310, 379);
    
    _putDontNest(result, 310, 354);
    
    _putDontNest(result, 310, 420);
    
    _putDontNest(result, 310, 342);
    
    _putDontNest(result, 310, 367);
    
    _putDontNest(result, 444, 481);
    
    _putDontNest(result, 456, 481);
    
    _putDontNest(result, 219, 277);
    
    _putDontNest(result, 219, 474);
    
    _putDontNest(result, 219, 438);
    
    _putDontNest(result, 219, 361);
    
    _putDontNest(result, 219, 426);
    
    _putDontNest(result, 219, 462);
    
    _putDontNest(result, 219, 414);
    
    _putDontNest(result, 219, 316);
    
    _putDontNest(result, 219, 450);
    
    _putDontNest(result, 219, 373);
    
    _putDontNest(result, 219, 336);
    
    _putDontNest(result, 219, 265);
    
    _putDontNest(result, 219, 323);
    
    _putDontNest(result, 219, 348);
    
    _putDontNest(result, 219, 273);
    
    _putDontNest(result, 219, 240);
    
    _putDontNest(result, 219, 257);
    
    _putDontNest(result, 219, 391);
    
    _putDontNest(result, 219, 247);
    
    _putDontNest(result, 219, 432);
    
    _putDontNest(result, 219, 329);
    
    _putDontNest(result, 219, 310);
    
    _putDontNest(result, 219, 444);
    
    _putDontNest(result, 219, 261);
    
    _putDontNest(result, 219, 456);
    
    _putDontNest(result, 219, 288);
    
    _putDontNest(result, 219, 385);
    
    _putDontNest(result, 219, 281);
    
    _putDontNest(result, 219, 481);
    
    _putDontNest(result, 219, 468);
    
    _putDontNest(result, 219, 379);
    
    _putDontNest(result, 219, 354);
    
    _putDontNest(result, 219, 420);
    
    _putDontNest(result, 219, 302);
    
    _putDontNest(result, 219, 407);
    
    _putDontNest(result, 219, 235);
    
    _putDontNest(result, 219, 342);
    
    _putDontNest(result, 219, 367);
    
    _putDontNest(result, 219, 294);
    
    _putDontNest(result, 219, 397);
    
    _putDontNest(result, 219, 253);
    
    _putDontNest(result, 261, 336);
    
    _putDontNest(result, 261, 474);
    
    _putDontNest(result, 261, 438);
    
    _putDontNest(result, 261, 391);
    
    _putDontNest(result, 261, 361);
    
    _putDontNest(result, 261, 426);
    
    _putDontNest(result, 261, 462);
    
    _putDontNest(result, 261, 414);
    
    _putDontNest(result, 261, 385);
    
    _putDontNest(result, 261, 316);
    
    _putDontNest(result, 261, 450);
    
    _putDontNest(result, 261, 373);
    
    _putDontNest(result, 261, 323);
    
    _putDontNest(result, 261, 348);
    
    _putDontNest(result, 261, 432);
    
    _putDontNest(result, 261, 329);
    
    _putDontNest(result, 261, 310);
    
    _putDontNest(result, 261, 444);
    
    _putDontNest(result, 261, 456);
    
    _putDontNest(result, 261, 288);
    
    _putDontNest(result, 261, 481);
    
    _putDontNest(result, 261, 468);
    
    _putDontNest(result, 261, 379);
    
    _putDontNest(result, 261, 354);
    
    _putDontNest(result, 261, 420);
    
    _putDontNest(result, 261, 302);
    
    _putDontNest(result, 261, 407);
    
    _putDontNest(result, 261, 342);
    
    _putDontNest(result, 261, 367);
    
    _putDontNest(result, 261, 294);
    
    _putDontNest(result, 261, 397);
    
    _putDontNest(result, 288, 336);
    
    _putDontNest(result, 288, 474);
    
    _putDontNest(result, 288, 438);
    
    _putDontNest(result, 288, 391);
    
    _putDontNest(result, 288, 361);
    
    _putDontNest(result, 288, 426);
    
    _putDontNest(result, 288, 462);
    
    _putDontNest(result, 288, 414);
    
    _putDontNest(result, 288, 385);
    
    _putDontNest(result, 288, 316);
    
    _putDontNest(result, 288, 450);
    
    _putDontNest(result, 288, 373);
    
    _putDontNest(result, 288, 323);
    
    _putDontNest(result, 288, 348);
    
    _putDontNest(result, 288, 432);
    
    _putDontNest(result, 288, 329);
    
    _putDontNest(result, 288, 310);
    
    _putDontNest(result, 288, 444);
    
    _putDontNest(result, 288, 456);
    
    _putDontNest(result, 288, 288);
    
    _putDontNest(result, 288, 481);
    
    _putDontNest(result, 288, 468);
    
    _putDontNest(result, 288, 379);
    
    _putDontNest(result, 288, 354);
    
    _putDontNest(result, 288, 420);
    
    _putDontNest(result, 288, 302);
    
    _putDontNest(result, 288, 407);
    
    _putDontNest(result, 288, 342);
    
    _putDontNest(result, 288, 367);
    
    _putDontNest(result, 288, 294);
    
    _putDontNest(result, 288, 397);
    
    _putDontNest(result, 462, 481);
    
    _putDontNest(result, 203, 277);
    
    _putDontNest(result, 203, 474);
    
    _putDontNest(result, 203, 438);
    
    _putDontNest(result, 203, 361);
    
    _putDontNest(result, 203, 426);
    
    _putDontNest(result, 203, 462);
    
    _putDontNest(result, 203, 414);
    
    _putDontNest(result, 203, 316);
    
    _putDontNest(result, 203, 450);
    
    _putDontNest(result, 203, 373);
    
    _putDontNest(result, 203, 336);
    
    _putDontNest(result, 203, 265);
    
    _putDontNest(result, 203, 323);
    
    _putDontNest(result, 203, 348);
    
    _putDontNest(result, 203, 273);
    
    _putDontNest(result, 203, 240);
    
    _putDontNest(result, 203, 257);
    
    _putDontNest(result, 203, 391);
    
    _putDontNest(result, 203, 247);
    
    _putDontNest(result, 203, 432);
    
    _putDontNest(result, 203, 329);
    
    _putDontNest(result, 203, 310);
    
    _putDontNest(result, 203, 444);
    
    _putDontNest(result, 203, 261);
    
    _putDontNest(result, 203, 456);
    
    _putDontNest(result, 203, 288);
    
    _putDontNest(result, 203, 385);
    
    _putDontNest(result, 203, 281);
    
    _putDontNest(result, 203, 481);
    
    _putDontNest(result, 203, 468);
    
    _putDontNest(result, 203, 379);
    
    _putDontNest(result, 203, 354);
    
    _putDontNest(result, 203, 420);
    
    _putDontNest(result, 203, 302);
    
    _putDontNest(result, 203, 407);
    
    _putDontNest(result, 203, 235);
    
    _putDontNest(result, 203, 342);
    
    _putDontNest(result, 203, 367);
    
    _putDontNest(result, 203, 294);
    
    _putDontNest(result, 203, 397);
    
    _putDontNest(result, 203, 253);
    
    _putDontNest(result, 1495, 1534);
    
    _putDontNest(result, 306, 336);
    
    _putDontNest(result, 306, 474);
    
    _putDontNest(result, 306, 438);
    
    _putDontNest(result, 306, 391);
    
    _putDontNest(result, 306, 361);
    
    _putDontNest(result, 306, 426);
    
    _putDontNest(result, 306, 462);
    
    _putDontNest(result, 306, 414);
    
    _putDontNest(result, 306, 385);
    
    _putDontNest(result, 306, 407);
    
    _putDontNest(result, 306, 450);
    
    _putDontNest(result, 306, 373);
    
    _putDontNest(result, 306, 397);
    
    _putDontNest(result, 306, 323);
    
    _putDontNest(result, 306, 348);
    
    _putDontNest(result, 306, 432);
    
    _putDontNest(result, 306, 329);
    
    _putDontNest(result, 306, 444);
    
    _putDontNest(result, 306, 456);
    
    _putDontNest(result, 306, 481);
    
    _putDontNest(result, 306, 468);
    
    _putDontNest(result, 306, 379);
    
    _putDontNest(result, 306, 354);
    
    _putDontNest(result, 306, 420);
    
    _putDontNest(result, 306, 342);
    
    _putDontNest(result, 306, 367);
    
    _putDontNest(result, 387, 474);
    
    _putDontNest(result, 387, 438);
    
    _putDontNest(result, 387, 426);
    
    _putDontNest(result, 387, 432);
    
    _putDontNest(result, 387, 462);
    
    _putDontNest(result, 387, 414);
    
    _putDontNest(result, 387, 420);
    
    _putDontNest(result, 387, 407);
    
    _putDontNest(result, 387, 450);
    
    _putDontNest(result, 387, 397);
    
    _putDontNest(result, 387, 444);
    
    _putDontNest(result, 387, 456);
    
    _putDontNest(result, 387, 481);
    
    _putDontNest(result, 387, 468);
    
    _putDontNest(result, 414, 481);
    
    _putDontNest(result, 381, 474);
    
    _putDontNest(result, 381, 438);
    
    _putDontNest(result, 381, 391);
    
    _putDontNest(result, 381, 426);
    
    _putDontNest(result, 381, 432);
    
    _putDontNest(result, 381, 462);
    
    _putDontNest(result, 381, 414);
    
    _putDontNest(result, 381, 420);
    
    _putDontNest(result, 381, 407);
    
    _putDontNest(result, 381, 450);
    
    _putDontNest(result, 381, 397);
    
    _putDontNest(result, 381, 444);
    
    _putDontNest(result, 381, 456);
    
    _putDontNest(result, 381, 481);
    
    _putDontNest(result, 381, 468);
    
    _putDontNest(result, 440, 474);
    
    _putDontNest(result, 440, 438);
    
    _putDontNest(result, 440, 426);
    
    _putDontNest(result, 440, 432);
    
    _putDontNest(result, 440, 462);
    
    _putDontNest(result, 440, 414);
    
    _putDontNest(result, 440, 420);
    
    _putDontNest(result, 440, 450);
    
    _putDontNest(result, 440, 444);
    
    _putDontNest(result, 440, 456);
    
    _putDontNest(result, 440, 481);
    
    _putDontNest(result, 440, 468);
    
    _putDontNest(result, 385, 474);
    
    _putDontNest(result, 385, 438);
    
    _putDontNest(result, 385, 391);
    
    _putDontNest(result, 385, 426);
    
    _putDontNest(result, 385, 432);
    
    _putDontNest(result, 385, 462);
    
    _putDontNest(result, 385, 414);
    
    _putDontNest(result, 385, 420);
    
    _putDontNest(result, 385, 407);
    
    _putDontNest(result, 385, 450);
    
    _putDontNest(result, 385, 397);
    
    _putDontNest(result, 385, 444);
    
    _putDontNest(result, 385, 456);
    
    _putDontNest(result, 385, 481);
    
    _putDontNest(result, 385, 468);
    
    _putDontNest(result, 281, 336);
    
    _putDontNest(result, 281, 474);
    
    _putDontNest(result, 281, 438);
    
    _putDontNest(result, 281, 391);
    
    _putDontNest(result, 281, 361);
    
    _putDontNest(result, 281, 426);
    
    _putDontNest(result, 281, 462);
    
    _putDontNest(result, 281, 414);
    
    _putDontNest(result, 281, 385);
    
    _putDontNest(result, 281, 316);
    
    _putDontNest(result, 281, 450);
    
    _putDontNest(result, 281, 373);
    
    _putDontNest(result, 281, 323);
    
    _putDontNest(result, 281, 348);
    
    _putDontNest(result, 281, 432);
    
    _putDontNest(result, 281, 329);
    
    _putDontNest(result, 281, 310);
    
    _putDontNest(result, 281, 444);
    
    _putDontNest(result, 281, 456);
    
    _putDontNest(result, 281, 288);
    
    _putDontNest(result, 281, 481);
    
    _putDontNest(result, 281, 468);
    
    _putDontNest(result, 281, 379);
    
    _putDontNest(result, 281, 354);
    
    _putDontNest(result, 281, 420);
    
    _putDontNest(result, 281, 302);
    
    _putDontNest(result, 281, 407);
    
    _putDontNest(result, 281, 342);
    
    _putDontNest(result, 281, 367);
    
    _putDontNest(result, 281, 294);
    
    _putDontNest(result, 281, 397);
    
    _putDontNest(result, 316, 336);
    
    _putDontNest(result, 316, 474);
    
    _putDontNest(result, 316, 438);
    
    _putDontNest(result, 316, 391);
    
    _putDontNest(result, 316, 361);
    
    _putDontNest(result, 316, 426);
    
    _putDontNest(result, 316, 462);
    
    _putDontNest(result, 316, 414);
    
    _putDontNest(result, 316, 385);
    
    _putDontNest(result, 316, 316);
    
    _putDontNest(result, 316, 407);
    
    _putDontNest(result, 316, 450);
    
    _putDontNest(result, 316, 373);
    
    _putDontNest(result, 316, 397);
    
    _putDontNest(result, 316, 323);
    
    _putDontNest(result, 316, 348);
    
    _putDontNest(result, 316, 432);
    
    _putDontNest(result, 316, 329);
    
    _putDontNest(result, 316, 310);
    
    _putDontNest(result, 316, 444);
    
    _putDontNest(result, 316, 456);
    
    _putDontNest(result, 316, 481);
    
    _putDontNest(result, 316, 468);
    
    _putDontNest(result, 316, 379);
    
    _putDontNest(result, 316, 354);
    
    _putDontNest(result, 316, 420);
    
    _putDontNest(result, 316, 342);
    
    _putDontNest(result, 316, 367);
    
    _putDontNest(result, 1441, 1475);
    
    _putDontNest(result, 470, 474);
    
    _putDontNest(result, 470, 438);
    
    _putDontNest(result, 470, 426);
    
    _putDontNest(result, 470, 432);
    
    _putDontNest(result, 470, 462);
    
    _putDontNest(result, 470, 414);
    
    _putDontNest(result, 470, 420);
    
    _putDontNest(result, 470, 450);
    
    _putDontNest(result, 470, 444);
    
    _putDontNest(result, 470, 456);
    
    _putDontNest(result, 470, 481);
    
    _putDontNest(result, 470, 468);
    
    _putDontNest(result, 468, 481);
    
    _putDontNest(result, 422, 474);
    
    _putDontNest(result, 422, 438);
    
    _putDontNest(result, 422, 426);
    
    _putDontNest(result, 422, 432);
    
    _putDontNest(result, 422, 462);
    
    _putDontNest(result, 422, 414);
    
    _putDontNest(result, 422, 420);
    
    _putDontNest(result, 422, 450);
    
    _putDontNest(result, 422, 444);
    
    _putDontNest(result, 422, 456);
    
    _putDontNest(result, 422, 481);
    
    _putDontNest(result, 422, 468);
    
    _putDontNest(result, 420, 481);
    
    _putDontNest(result, 379, 474);
    
    _putDontNest(result, 379, 438);
    
    _putDontNest(result, 379, 391);
    
    _putDontNest(result, 379, 426);
    
    _putDontNest(result, 379, 432);
    
    _putDontNest(result, 379, 462);
    
    _putDontNest(result, 379, 414);
    
    _putDontNest(result, 379, 385);
    
    _putDontNest(result, 379, 420);
    
    _putDontNest(result, 379, 407);
    
    _putDontNest(result, 379, 450);
    
    _putDontNest(result, 379, 397);
    
    _putDontNest(result, 379, 444);
    
    _putDontNest(result, 379, 456);
    
    _putDontNest(result, 379, 481);
    
    _putDontNest(result, 379, 468);
    
    _putDontNest(result, 354, 336);
    
    _putDontNest(result, 354, 474);
    
    _putDontNest(result, 354, 438);
    
    _putDontNest(result, 354, 348);
    
    _putDontNest(result, 354, 391);
    
    _putDontNest(result, 354, 361);
    
    _putDontNest(result, 354, 426);
    
    _putDontNest(result, 354, 432);
    
    _putDontNest(result, 354, 462);
    
    _putDontNest(result, 354, 414);
    
    _putDontNest(result, 354, 385);
    
    _putDontNest(result, 354, 407);
    
    _putDontNest(result, 354, 450);
    
    _putDontNest(result, 354, 373);
    
    _putDontNest(result, 354, 397);
    
    _putDontNest(result, 354, 444);
    
    _putDontNest(result, 354, 456);
    
    _putDontNest(result, 354, 481);
    
    _putDontNest(result, 354, 468);
    
    _putDontNest(result, 354, 379);
    
    _putDontNest(result, 354, 354);
    
    _putDontNest(result, 354, 420);
    
    _putDontNest(result, 354, 342);
    
    _putDontNest(result, 354, 367);
    
    _putDontNest(result, 363, 474);
    
    _putDontNest(result, 363, 438);
    
    _putDontNest(result, 363, 391);
    
    _putDontNest(result, 363, 426);
    
    _putDontNest(result, 363, 432);
    
    _putDontNest(result, 363, 462);
    
    _putDontNest(result, 363, 414);
    
    _putDontNest(result, 363, 385);
    
    _putDontNest(result, 363, 407);
    
    _putDontNest(result, 363, 450);
    
    _putDontNest(result, 363, 373);
    
    _putDontNest(result, 363, 397);
    
    _putDontNest(result, 363, 444);
    
    _putDontNest(result, 363, 456);
    
    _putDontNest(result, 363, 481);
    
    _putDontNest(result, 363, 468);
    
    _putDontNest(result, 363, 379);
    
    _putDontNest(result, 363, 420);
    
    _putDontNest(result, 416, 474);
    
    _putDontNest(result, 416, 438);
    
    _putDontNest(result, 416, 426);
    
    _putDontNest(result, 416, 432);
    
    _putDontNest(result, 416, 462);
    
    _putDontNest(result, 416, 414);
    
    _putDontNest(result, 416, 420);
    
    _putDontNest(result, 416, 450);
    
    _putDontNest(result, 416, 444);
    
    _putDontNest(result, 416, 456);
    
    _putDontNest(result, 416, 481);
    
    _putDontNest(result, 416, 468);
    
    _putDontNest(result, 1453, 1475);
    
    _putDontNest(result, 434, 474);
    
    _putDontNest(result, 434, 438);
    
    _putDontNest(result, 434, 426);
    
    _putDontNest(result, 434, 432);
    
    _putDontNest(result, 434, 462);
    
    _putDontNest(result, 434, 414);
    
    _putDontNest(result, 434, 420);
    
    _putDontNest(result, 434, 450);
    
    _putDontNest(result, 434, 444);
    
    _putDontNest(result, 434, 456);
    
    _putDontNest(result, 434, 481);
    
    _putDontNest(result, 434, 468);
    
    _putDontNest(result, 302, 336);
    
    _putDontNest(result, 302, 474);
    
    _putDontNest(result, 302, 438);
    
    _putDontNest(result, 302, 391);
    
    _putDontNest(result, 302, 361);
    
    _putDontNest(result, 302, 426);
    
    _putDontNest(result, 302, 462);
    
    _putDontNest(result, 302, 414);
    
    _putDontNest(result, 302, 385);
    
    _putDontNest(result, 302, 316);
    
    _putDontNest(result, 302, 450);
    
    _putDontNest(result, 302, 373);
    
    _putDontNest(result, 302, 323);
    
    _putDontNest(result, 302, 348);
    
    _putDontNest(result, 302, 432);
    
    _putDontNest(result, 302, 329);
    
    _putDontNest(result, 302, 310);
    
    _putDontNest(result, 302, 444);
    
    _putDontNest(result, 302, 456);
    
    _putDontNest(result, 302, 288);
    
    _putDontNest(result, 302, 481);
    
    _putDontNest(result, 302, 468);
    
    _putDontNest(result, 302, 379);
    
    _putDontNest(result, 302, 354);
    
    _putDontNest(result, 302, 420);
    
    _putDontNest(result, 302, 302);
    
    _putDontNest(result, 302, 407);
    
    _putDontNest(result, 302, 342);
    
    _putDontNest(result, 302, 367);
    
    _putDontNest(result, 302, 294);
    
    _putDontNest(result, 302, 397);
    
    _putDontNest(result, 284, 336);
    
    _putDontNest(result, 284, 474);
    
    _putDontNest(result, 284, 438);
    
    _putDontNest(result, 284, 391);
    
    _putDontNest(result, 284, 361);
    
    _putDontNest(result, 284, 426);
    
    _putDontNest(result, 284, 462);
    
    _putDontNest(result, 284, 414);
    
    _putDontNest(result, 284, 385);
    
    _putDontNest(result, 284, 316);
    
    _putDontNest(result, 284, 407);
    
    _putDontNest(result, 284, 450);
    
    _putDontNest(result, 284, 373);
    
    _putDontNest(result, 284, 397);
    
    _putDontNest(result, 284, 323);
    
    _putDontNest(result, 284, 348);
    
    _putDontNest(result, 284, 432);
    
    _putDontNest(result, 284, 329);
    
    _putDontNest(result, 284, 310);
    
    _putDontNest(result, 284, 444);
    
    _putDontNest(result, 284, 456);
    
    _putDontNest(result, 284, 481);
    
    _putDontNest(result, 284, 468);
    
    _putDontNest(result, 284, 379);
    
    _putDontNest(result, 284, 354);
    
    _putDontNest(result, 284, 420);
    
    _putDontNest(result, 284, 342);
    
    _putDontNest(result, 284, 367);
    
    _putDontNest(result, 344, 474);
    
    _putDontNest(result, 344, 438);
    
    _putDontNest(result, 344, 391);
    
    _putDontNest(result, 344, 361);
    
    _putDontNest(result, 344, 426);
    
    _putDontNest(result, 344, 432);
    
    _putDontNest(result, 344, 462);
    
    _putDontNest(result, 344, 414);
    
    _putDontNest(result, 344, 385);
    
    _putDontNest(result, 344, 407);
    
    _putDontNest(result, 344, 450);
    
    _putDontNest(result, 344, 373);
    
    _putDontNest(result, 344, 367);
    
    _putDontNest(result, 344, 397);
    
    _putDontNest(result, 344, 444);
    
    _putDontNest(result, 344, 456);
    
    _putDontNest(result, 344, 481);
    
    _putDontNest(result, 344, 468);
    
    _putDontNest(result, 344, 379);
    
    _putDontNest(result, 344, 420);
    
    _putDontNest(result, 407, 474);
    
    _putDontNest(result, 407, 438);
    
    _putDontNest(result, 407, 426);
    
    _putDontNest(result, 407, 432);
    
    _putDontNest(result, 407, 462);
    
    _putDontNest(result, 407, 414);
    
    _putDontNest(result, 407, 420);
    
    _putDontNest(result, 407, 450);
    
    _putDontNest(result, 407, 444);
    
    _putDontNest(result, 407, 456);
    
    _putDontNest(result, 407, 481);
    
    _putDontNest(result, 407, 468);
    
    _putDontNest(result, 464, 474);
    
    _putDontNest(result, 464, 438);
    
    _putDontNest(result, 464, 426);
    
    _putDontNest(result, 464, 432);
    
    _putDontNest(result, 464, 462);
    
    _putDontNest(result, 464, 414);
    
    _putDontNest(result, 464, 420);
    
    _putDontNest(result, 464, 450);
    
    _putDontNest(result, 464, 444);
    
    _putDontNest(result, 464, 456);
    
    _putDontNest(result, 464, 481);
    
    _putDontNest(result, 464, 468);
    
    _putDontNest(result, 393, 474);
    
    _putDontNest(result, 393, 438);
    
    _putDontNest(result, 393, 426);
    
    _putDontNest(result, 393, 432);
    
    _putDontNest(result, 393, 462);
    
    _putDontNest(result, 393, 414);
    
    _putDontNest(result, 393, 420);
    
    _putDontNest(result, 393, 407);
    
    _putDontNest(result, 393, 450);
    
    _putDontNest(result, 393, 444);
    
    _putDontNest(result, 393, 456);
    
    _putDontNest(result, 393, 481);
    
    _putDontNest(result, 393, 468);
    
    _putDontNest(result, 450, 481);
    
    _putDontNest(result, 332, 474);
    
    _putDontNest(result, 332, 438);
    
    _putDontNest(result, 332, 391);
    
    _putDontNest(result, 332, 361);
    
    _putDontNest(result, 332, 426);
    
    _putDontNest(result, 332, 432);
    
    _putDontNest(result, 332, 462);
    
    _putDontNest(result, 332, 414);
    
    _putDontNest(result, 332, 385);
    
    _putDontNest(result, 332, 407);
    
    _putDontNest(result, 332, 450);
    
    _putDontNest(result, 332, 373);
    
    _putDontNest(result, 332, 367);
    
    _putDontNest(result, 332, 397);
    
    _putDontNest(result, 332, 444);
    
    _putDontNest(result, 332, 456);
    
    _putDontNest(result, 332, 481);
    
    _putDontNest(result, 332, 468);
    
    _putDontNest(result, 332, 379);
    
    _putDontNest(result, 332, 420);
    
    _putDontNest(result, 290, 336);
    
    _putDontNest(result, 290, 474);
    
    _putDontNest(result, 290, 438);
    
    _putDontNest(result, 290, 391);
    
    _putDontNest(result, 290, 361);
    
    _putDontNest(result, 290, 426);
    
    _putDontNest(result, 290, 462);
    
    _putDontNest(result, 290, 414);
    
    _putDontNest(result, 290, 385);
    
    _putDontNest(result, 290, 316);
    
    _putDontNest(result, 290, 407);
    
    _putDontNest(result, 290, 450);
    
    _putDontNest(result, 290, 373);
    
    _putDontNest(result, 290, 397);
    
    _putDontNest(result, 290, 323);
    
    _putDontNest(result, 290, 348);
    
    _putDontNest(result, 290, 432);
    
    _putDontNest(result, 290, 329);
    
    _putDontNest(result, 290, 310);
    
    _putDontNest(result, 290, 444);
    
    _putDontNest(result, 290, 456);
    
    _putDontNest(result, 290, 481);
    
    _putDontNest(result, 290, 468);
    
    _putDontNest(result, 290, 379);
    
    _putDontNest(result, 290, 354);
    
    _putDontNest(result, 290, 420);
    
    _putDontNest(result, 290, 342);
    
    _putDontNest(result, 290, 367);
    
    _putDontNest(result, 373, 474);
    
    _putDontNest(result, 373, 438);
    
    _putDontNest(result, 373, 391);
    
    _putDontNest(result, 373, 426);
    
    _putDontNest(result, 373, 432);
    
    _putDontNest(result, 373, 462);
    
    _putDontNest(result, 373, 414);
    
    _putDontNest(result, 373, 385);
    
    _putDontNest(result, 373, 407);
    
    _putDontNest(result, 373, 450);
    
    _putDontNest(result, 373, 397);
    
    _putDontNest(result, 373, 444);
    
    _putDontNest(result, 373, 456);
    
    _putDontNest(result, 373, 481);
    
    _putDontNest(result, 373, 468);
    
    _putDontNest(result, 373, 379);
    
    _putDontNest(result, 373, 420);
    
    _putDontNest(result, 446, 474);
    
    _putDontNest(result, 446, 438);
    
    _putDontNest(result, 446, 426);
    
    _putDontNest(result, 446, 432);
    
    _putDontNest(result, 446, 462);
    
    _putDontNest(result, 446, 414);
    
    _putDontNest(result, 446, 420);
    
    _putDontNest(result, 446, 450);
    
    _putDontNest(result, 446, 444);
    
    _putDontNest(result, 446, 456);
    
    _putDontNest(result, 446, 481);
    
    _putDontNest(result, 446, 468);
    
    _putDontNest(result, 1206, 1225);
    
    _putDontNest(result, 458, 474);
    
    _putDontNest(result, 458, 438);
    
    _putDontNest(result, 458, 426);
    
    _putDontNest(result, 458, 432);
    
    _putDontNest(result, 458, 462);
    
    _putDontNest(result, 458, 414);
    
    _putDontNest(result, 458, 420);
    
    _putDontNest(result, 458, 450);
    
    _putDontNest(result, 458, 444);
    
    _putDontNest(result, 458, 456);
    
    _putDontNest(result, 458, 481);
    
    _putDontNest(result, 458, 468);
    
    _putDontNest(result, 428, 474);
    
    _putDontNest(result, 428, 438);
    
    _putDontNest(result, 428, 426);
    
    _putDontNest(result, 428, 432);
    
    _putDontNest(result, 428, 462);
    
    _putDontNest(result, 428, 414);
    
    _putDontNest(result, 428, 420);
    
    _putDontNest(result, 428, 450);
    
    _putDontNest(result, 428, 444);
    
    _putDontNest(result, 428, 456);
    
    _putDontNest(result, 428, 481);
    
    _putDontNest(result, 428, 468);
    
    _putDontNest(result, 235, 336);
    
    _putDontNest(result, 235, 474);
    
    _putDontNest(result, 235, 438);
    
    _putDontNest(result, 235, 391);
    
    _putDontNest(result, 235, 361);
    
    _putDontNest(result, 235, 426);
    
    _putDontNest(result, 235, 462);
    
    _putDontNest(result, 235, 414);
    
    _putDontNest(result, 235, 385);
    
    _putDontNest(result, 235, 316);
    
    _putDontNest(result, 235, 450);
    
    _putDontNest(result, 235, 373);
    
    _putDontNest(result, 235, 323);
    
    _putDontNest(result, 235, 348);
    
    _putDontNest(result, 235, 432);
    
    _putDontNest(result, 235, 329);
    
    _putDontNest(result, 235, 310);
    
    _putDontNest(result, 235, 444);
    
    _putDontNest(result, 235, 456);
    
    _putDontNest(result, 235, 288);
    
    _putDontNest(result, 235, 481);
    
    _putDontNest(result, 235, 468);
    
    _putDontNest(result, 235, 379);
    
    _putDontNest(result, 235, 354);
    
    _putDontNest(result, 235, 420);
    
    _putDontNest(result, 235, 302);
    
    _putDontNest(result, 235, 407);
    
    _putDontNest(result, 235, 342);
    
    _putDontNest(result, 235, 367);
    
    _putDontNest(result, 235, 294);
    
    _putDontNest(result, 235, 397);
    
    _putDontNest(result, 342, 336);
    
    _putDontNest(result, 342, 474);
    
    _putDontNest(result, 342, 438);
    
    _putDontNest(result, 342, 348);
    
    _putDontNest(result, 342, 391);
    
    _putDontNest(result, 342, 361);
    
    _putDontNest(result, 342, 426);
    
    _putDontNest(result, 342, 432);
    
    _putDontNest(result, 342, 462);
    
    _putDontNest(result, 342, 414);
    
    _putDontNest(result, 342, 385);
    
    _putDontNest(result, 342, 407);
    
    _putDontNest(result, 342, 450);
    
    _putDontNest(result, 342, 373);
    
    _putDontNest(result, 342, 397);
    
    _putDontNest(result, 342, 444);
    
    _putDontNest(result, 342, 456);
    
    _putDontNest(result, 342, 481);
    
    _putDontNest(result, 342, 468);
    
    _putDontNest(result, 342, 379);
    
    _putDontNest(result, 342, 354);
    
    _putDontNest(result, 342, 420);
    
    _putDontNest(result, 342, 342);
    
    _putDontNest(result, 342, 367);
    
    _putDontNest(result, 367, 474);
    
    _putDontNest(result, 367, 438);
    
    _putDontNest(result, 367, 391);
    
    _putDontNest(result, 367, 361);
    
    _putDontNest(result, 367, 426);
    
    _putDontNest(result, 367, 432);
    
    _putDontNest(result, 367, 462);
    
    _putDontNest(result, 367, 414);
    
    _putDontNest(result, 367, 385);
    
    _putDontNest(result, 367, 407);
    
    _putDontNest(result, 367, 450);
    
    _putDontNest(result, 367, 373);
    
    _putDontNest(result, 367, 367);
    
    _putDontNest(result, 367, 397);
    
    _putDontNest(result, 367, 444);
    
    _putDontNest(result, 367, 456);
    
    _putDontNest(result, 367, 481);
    
    _putDontNest(result, 367, 468);
    
    _putDontNest(result, 367, 379);
    
    _putDontNest(result, 367, 420);
    
    _putDontNest(result, 369, 474);
    
    _putDontNest(result, 369, 438);
    
    _putDontNest(result, 369, 391);
    
    _putDontNest(result, 369, 426);
    
    _putDontNest(result, 369, 432);
    
    _putDontNest(result, 369, 462);
    
    _putDontNest(result, 369, 414);
    
    _putDontNest(result, 369, 385);
    
    _putDontNest(result, 369, 407);
    
    _putDontNest(result, 369, 450);
    
    _putDontNest(result, 369, 397);
    
    _putDontNest(result, 369, 444);
    
    _putDontNest(result, 369, 456);
    
    _putDontNest(result, 369, 481);
    
    _putDontNest(result, 369, 468);
    
    _putDontNest(result, 369, 379);
    
    _putDontNest(result, 369, 420);
    
    _putDontNest(result, 397, 474);
    
    _putDontNest(result, 397, 438);
    
    _putDontNest(result, 397, 426);
    
    _putDontNest(result, 397, 432);
    
    _putDontNest(result, 397, 462);
    
    _putDontNest(result, 397, 414);
    
    _putDontNest(result, 397, 420);
    
    _putDontNest(result, 397, 407);
    
    _putDontNest(result, 397, 450);
    
    _putDontNest(result, 397, 444);
    
    _putDontNest(result, 397, 456);
    
    _putDontNest(result, 397, 481);
    
    _putDontNest(result, 397, 468);
    
    _putDontNest(result, 253, 336);
    
    _putDontNest(result, 253, 474);
    
    _putDontNest(result, 253, 438);
    
    _putDontNest(result, 253, 391);
    
    _putDontNest(result, 253, 361);
    
    _putDontNest(result, 253, 426);
    
    _putDontNest(result, 253, 462);
    
    _putDontNest(result, 253, 414);
    
    _putDontNest(result, 253, 385);
    
    _putDontNest(result, 253, 316);
    
    _putDontNest(result, 253, 450);
    
    _putDontNest(result, 253, 373);
    
    _putDontNest(result, 253, 323);
    
    _putDontNest(result, 253, 348);
    
    _putDontNest(result, 253, 432);
    
    _putDontNest(result, 253, 329);
    
    _putDontNest(result, 253, 310);
    
    _putDontNest(result, 253, 444);
    
    _putDontNest(result, 253, 456);
    
    _putDontNest(result, 253, 288);
    
    _putDontNest(result, 253, 481);
    
    _putDontNest(result, 253, 468);
    
    _putDontNest(result, 253, 379);
    
    _putDontNest(result, 253, 354);
    
    _putDontNest(result, 253, 420);
    
    _putDontNest(result, 253, 302);
    
    _putDontNest(result, 253, 407);
    
    _putDontNest(result, 253, 342);
    
    _putDontNest(result, 253, 367);
    
    _putDontNest(result, 253, 294);
    
    _putDontNest(result, 253, 397);
    
    _putDontNest(result, 410, 474);
    
    _putDontNest(result, 410, 438);
    
    _putDontNest(result, 410, 426);
    
    _putDontNest(result, 410, 432);
    
    _putDontNest(result, 410, 462);
    
    _putDontNest(result, 410, 414);
    
    _putDontNest(result, 410, 420);
    
    _putDontNest(result, 410, 450);
    
    _putDontNest(result, 410, 444);
    
    _putDontNest(result, 410, 456);
    
    _putDontNest(result, 410, 481);
    
    _putDontNest(result, 410, 468);
    
    _putDontNest(result, 319, 336);
    
    _putDontNest(result, 319, 474);
    
    _putDontNest(result, 319, 438);
    
    _putDontNest(result, 319, 348);
    
    _putDontNest(result, 319, 391);
    
    _putDontNest(result, 319, 361);
    
    _putDontNest(result, 319, 426);
    
    _putDontNest(result, 319, 432);
    
    _putDontNest(result, 319, 462);
    
    _putDontNest(result, 319, 414);
    
    _putDontNest(result, 319, 385);
    
    _putDontNest(result, 319, 407);
    
    _putDontNest(result, 319, 450);
    
    _putDontNest(result, 319, 373);
    
    _putDontNest(result, 319, 397);
    
    _putDontNest(result, 319, 444);
    
    _putDontNest(result, 319, 456);
    
    _putDontNest(result, 319, 481);
    
    _putDontNest(result, 319, 468);
    
    _putDontNest(result, 319, 379);
    
    _putDontNest(result, 319, 354);
    
    _putDontNest(result, 319, 420);
    
    _putDontNest(result, 319, 342);
    
    _putDontNest(result, 319, 367);
    
    _putDontNest(result, 294, 336);
    
    _putDontNest(result, 294, 474);
    
    _putDontNest(result, 294, 438);
    
    _putDontNest(result, 294, 391);
    
    _putDontNest(result, 294, 361);
    
    _putDontNest(result, 294, 426);
    
    _putDontNest(result, 294, 462);
    
    _putDontNest(result, 294, 414);
    
    _putDontNest(result, 294, 385);
    
    _putDontNest(result, 294, 316);
    
    _putDontNest(result, 294, 450);
    
    _putDontNest(result, 294, 373);
    
    _putDontNest(result, 294, 323);
    
    _putDontNest(result, 294, 348);
    
    _putDontNest(result, 294, 432);
    
    _putDontNest(result, 294, 329);
    
    _putDontNest(result, 294, 310);
    
    _putDontNest(result, 294, 444);
    
    _putDontNest(result, 294, 456);
    
    _putDontNest(result, 294, 288);
    
    _putDontNest(result, 294, 481);
    
    _putDontNest(result, 294, 468);
    
    _putDontNest(result, 294, 379);
    
    _putDontNest(result, 294, 354);
    
    _putDontNest(result, 294, 420);
    
    _putDontNest(result, 294, 302);
    
    _putDontNest(result, 294, 407);
    
    _putDontNest(result, 294, 342);
    
    _putDontNest(result, 294, 367);
    
    _putDontNest(result, 294, 294);
    
    _putDontNest(result, 294, 397);
   return result;
  }
    
  protected static IntegerMap _initDontNestGroups() {
    IntegerMap result = new IntegerMap();
    int resultStoreId = result.size();
    
    
    ++resultStoreId;
    
    result.putUnsafe(1507, resultStoreId);
    result.putUnsafe(1495, resultStoreId);
    ++resultStoreId;
    
    result.putUnsafe(373, resultStoreId);
    result.putUnsafe(369, resultStoreId);
    ++resultStoreId;
    
    result.putUnsafe(1441, resultStoreId);
    result.putUnsafe(1453, resultStoreId);
    ++resultStoreId;
    
    result.putUnsafe(338, resultStoreId);
    result.putUnsafe(350, resultStoreId);
    result.putUnsafe(361, resultStoreId);
    result.putUnsafe(344, resultStoreId);
    result.putUnsafe(332, resultStoreId);
    result.putUnsafe(367, resultStoreId);
    ++resultStoreId;
    
    result.putUnsafe(375, resultStoreId);
    result.putUnsafe(379, resultStoreId);
    ++resultStoreId;
    
    result.putUnsafe(391, resultStoreId);
    result.putUnsafe(387, resultStoreId);
    ++resultStoreId;
    
    result.putUnsafe(310, resultStoreId);
    result.putUnsafe(316, resultStoreId);
    result.putUnsafe(284, resultStoreId);
    result.putUnsafe(290, resultStoreId);
    result.putUnsafe(297, resultStoreId);
    ++resultStoreId;
    
    result.putUnsafe(381, resultStoreId);
    result.putUnsafe(385, resultStoreId);
    ++resultStoreId;
    
    result.putUnsafe(1191, resultStoreId);
    result.putUnsafe(1206, resultStoreId);
    ++resultStoreId;
    
    result.putUnsafe(336, resultStoreId);
    result.putUnsafe(325, resultStoreId);
    result.putUnsafe(348, resultStoreId);
    result.putUnsafe(354, resultStoreId);
    result.putUnsafe(342, resultStoreId);
    result.putUnsafe(319, resultStoreId);
    ++resultStoreId;
    
    result.putUnsafe(357, resultStoreId);
    result.putUnsafe(363, resultStoreId);
    ++resultStoreId;
    
    result.putUnsafe(393, resultStoreId);
    result.putUnsafe(397, resultStoreId);
    ++resultStoreId;
    
    result.putUnsafe(323, resultStoreId);
    result.putUnsafe(312, resultStoreId);
    result.putUnsafe(329, resultStoreId);
    result.putUnsafe(306, resultStoreId);
    ++resultStoreId;
    
    result.putUnsafe(474, resultStoreId);
    result.putUnsafe(438, resultStoreId);
    result.putUnsafe(426, resultStoreId);
    result.putUnsafe(432, resultStoreId);
    result.putUnsafe(462, resultStoreId);
    result.putUnsafe(414, resultStoreId);
    result.putUnsafe(468, resultStoreId);
    result.putUnsafe(420, resultStoreId);
    result.putUnsafe(450, resultStoreId);
    result.putUnsafe(444, resultStoreId);
    result.putUnsafe(456, resultStoreId);
    ++resultStoreId;
    
    result.putUnsafe(166, resultStoreId);
    result.putUnsafe(177, resultStoreId);
    result.putUnsafe(195, resultStoreId);
    result.putUnsafe(189, resultStoreId);
    result.putUnsafe(219, resultStoreId);
    result.putUnsafe(203, resultStoreId);
    ++resultStoreId;
    
    result.putUnsafe(265, resultStoreId);
    result.putUnsafe(277, resultStoreId);
    result.putUnsafe(281, resultStoreId);
    result.putUnsafe(302, resultStoreId);
    result.putUnsafe(235, resultStoreId);
    result.putUnsafe(273, resultStoreId);
    result.putUnsafe(240, resultStoreId);
    result.putUnsafe(257, resultStoreId);
    result.putUnsafe(247, resultStoreId);
    result.putUnsafe(261, resultStoreId);
    result.putUnsafe(288, resultStoreId);
    result.putUnsafe(294, resultStoreId);
    result.putUnsafe(253, resultStoreId);
    ++resultStoreId;
    
    result.putUnsafe(452, resultStoreId);
    result.putUnsafe(399, resultStoreId);
    result.putUnsafe(440, resultStoreId);
    result.putUnsafe(470, resultStoreId);
    result.putUnsafe(422, resultStoreId);
    result.putUnsafe(407, resultStoreId);
    result.putUnsafe(464, resultStoreId);
    result.putUnsafe(446, resultStoreId);
    result.putUnsafe(410, resultStoreId);
    result.putUnsafe(434, resultStoreId);
    result.putUnsafe(416, resultStoreId);
    result.putUnsafe(458, resultStoreId);
    result.putUnsafe(428, resultStoreId);
      
    return result;
  }
  
  protected boolean hasNestingRestrictions(java.lang.String name){
		return (_dontNest.size() != 0); // TODO Make more specific.
  }
    
  protected IntegerList getFilteredParents(int childId) {
		return _dontNest.get(childId);
  }
    
  // initialize priorities     
  static {
    _dontNest = _initDontNest();
    _resultStoreIdMappings = _initDontNestGroups();
  }
    
  // Production declarations
	
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI9IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKHJpZ2h0KCkpfSk00 = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"=\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{assoc(right())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIiEiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDMzLDMzKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"!\"),[\\char-class([range(33,33)])],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiTm9uQ29tbWFFeHByZXNzaW9uIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSk00 = (IConstructor) _read("regular(\\iter-star-seps(sort(\"NonCommaExpression\"),[layouts(\"LAYOUTLIST\"),lit(\",\"),layouts(\"LAYOUTLIST\")]))", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihvcHQoc29ydCgiUGFyYW1ldGVycyIpKSk00 = (IConstructor) _read("regular(opt(sort(\"Parameters\")))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiY2hhciIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGl0KCJjaGFyIildLHt9KQ0000 = (IConstructor) _read("prod(label(\"char\",sort(\"TypeSpecifier\")),[lit(\"char\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFbnVtZXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkVudW1lcmF0b3JcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIkVudW1lcmF0b3IiKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Enumerator\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"Enumerator\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"Enumerator\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIioiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQyLDQyKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"*\"),[\\char-class([range(42,42)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQYXJhbWV0ZXJzIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgib3B0KHNvcnQoXCJQYXJhbWV0ZXJzXCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIob3B0KHNvcnQoIlBhcmFtZXRlcnMiKSkpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Parameters\")),[\\char-class([range(0,0)]),lit(\"opt(sort(\\\"Parameters\\\"))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(opt(sort(\"Parameters\"))))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImV4dGVybiIpXSx7fSk00 = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"extern\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJUcmFuc2xhdGlvblVuaXQiKSxbXGl0ZXItc2Vwcyhzb3J0KCJFeHRlcm5hbERlY2xhcmF0aW9uIiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pXSx7fSk00 = (IConstructor) _read("prod(sort(\"TranslationUnit\"),[\\iter-seps(sort(\"ExternalDeclaration\"),[layouts(\"LAYOUTLIST\")])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkNoYXJhY3RlckNvbnN0YW50IikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkNoYXJhY3RlckNvbnN0YW50XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihsZXgoIkNoYXJhY3RlckNvbnN0YW50IikpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",lex(\"CharacterConstant\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"CharacterConstant\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(lex(\"CharacterConstant\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zdGFyKFxcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTIsOTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDQsMTA0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDkxLDkxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAzLDEwMyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDUyLDUyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Niw1NildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDUzLDUzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1NSw1NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDkzLDkzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"\\\\iter-star(\\\\char-class([range(48,57)]))\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(40,40)]),\\char-class([range(92,92)]),\\char-class([range(99,99)]),\\char-class([range(104,104)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(115,115)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(91,91)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(52,52)]),\\char-class([range(56,56)]),\\char-class([range(44,44)]),\\char-class([range(53,53)]),\\char-class([range(55,55)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsZXgoIkludGVnZXJDb25zdGFudCIpLFtpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksY29uZGl0aW9uYWwoXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoNzYsNzYpLHJhbmdlKDg1LDg1KSxyYW5nZSgxMDgsMTA4KSxyYW5nZSgxMTcsMTE3KV0pKSx7XG5vdC1mb2xsb3coXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKX0pXSx7fSk00 = (IConstructor) _read("prod(lex(\"IntegerConstant\"),[iter(\\char-class([range(48,57)])),conditional(\\iter-star(\\char-class([range(76,76),range(85,85),range(108,108),range(117,117)])),{\\not-follow(\\char-class([range(48,57)]))})],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiYnJhY2tldCIsc29ydCgiRGVjbGFyYXRvciIpKSxbbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJkZWNsIixzb3J0KCJEZWNsYXJhdG9yIikpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKV0se2JyYWNrZXQoKX0p = (IConstructor) _read("prod(label(\"bracket\",sort(\"Declarator\")),[lit(\"(\"),layouts(\"LAYOUTLIST\"),label(\"decl\",sort(\"Declarator\")),layouts(\"LAYOUTLIST\"),lit(\")\")],{bracket()})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNob3J0IiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDQsMTA0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"short\"),[\\char-class([range(115,115)]),\\char-class([range(104,104)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlw11XD4iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDYyLDYyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2Miw2MildKV0se30p = (IConstructor) _read("prod(lit(\"\\>\\>\"),[\\char-class([range(62,62)]),\\char-class([range(62,62)])],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihzZXEoW1xjaGFyLWNsYXNzKFtyYW5nZSg2NSw5MCkscmFuZ2UoOTUsOTUpLHJhbmdlKDk3LDEyMildKSxjb25kaXRpb25hbChcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NykscmFuZ2UoNjUsOTApLHJhbmdlKDk1LDk1KSxyYW5nZSg5NywxMjIpXSkpLHtcbm90LWZvbGxvdyhcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpLHJhbmdlKDY1LDkwKSxyYW5nZSg5NSw5NSkscmFuZ2UoOTcsMTIyKV0pKX0pXSkp = (IConstructor) _read("regular(seq([\\char-class([range(65,90),range(95,95),range(97,122)]),conditional(\\iter-star(\\char-class([range(48,57),range(65,90),range(95,95),range(97,122)])),{\\not-follow(\\char-class([range(48,57),range(65,90),range(95,95),range(97,122)]))})]))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPj0iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7YXNzb2MobGVmdCgpKX0p = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"\\>=\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{assoc(left())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgic3RydWN0RGVjbFdpdGhEZWNsIixzb3J0KCJTdHJ1Y3REZWNsYXJhdGlvbiIpKSxbbGFiZWwoInNwZWNzIixcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXNlcHMoc29ydCgiU3RydWN0RGVjbGFyYXRvciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIsIiksbGF5b3V0cygiTEFZT1VUTElTVCIpXSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOyIpXSx7fSk00 = (IConstructor) _read("prod(label(\"structDeclWithDecl\",sort(\"StructDeclaration\")),[label(\"specs\",\\iter-seps(sort(\"Specifier\"),[layouts(\"LAYOUTLIST\")])),layouts(\"LAYOUTLIST\"),\\iter-seps(sort(\"StructDeclarator\"),[layouts(\"LAYOUTLIST\"),lit(\",\"),layouts(\"LAYOUTLIST\")]),layouts(\"LAYOUTLIST\"),lit(\";\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImRvdWJsZSIpXSx7fSk00 = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"double\")],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zZXBzKHNvcnQoIkV4dGVybmFsRGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkp = (IConstructor) _read("regular(\\iter-seps(sort(\"ExternalDeclaration\"),[layouts(\"LAYOUTLIST\")]))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJJZGVudGlmaWVyXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDczLDczKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDAsMTAwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDIsMTAyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"sort(\\\"Identifier\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(73,73)]),\\char-class([range(100,100)]),\\char-class([range(101,101)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(102,102)]),\\char-class([range(105,105)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJNb3JlUGFyYW1ldGVycyIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJNb3JlUGFyYW1ldGVyc1wiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiTW9yZVBhcmFtZXRlcnMiKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"MoreParameters\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"MoreParameters\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"MoreParameters\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJTdHJpbmdDb25zdGFudFwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4Myw4MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAzLDEwMyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjcsNjcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"sort(\\\"StringConstant\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(83,83)]),\\char-class([range(116,116)]),\\char-class([range(114,114)]),\\char-class([range(105,105)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(67,67)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJTdGF0ZW1lbnRcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODMsODMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"sort(\\\"Statement\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(83,83)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(109,109)]),\\char-class([range(101,101)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiZmxvYXQiLHNvcnQoIlR5cGVTcGVjaWZpZXIiKSksW2xpdCgiZmxvYXQiKV0se30p = (IConstructor) _read("prod(label(\"float\",sort(\"TypeSpecifier\")),[lit(\"float\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgifiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"Expression\"),[lit(\"~\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiZW51bUFub25EZWNsIixzb3J0KCJUeXBlU3BlY2lmaWVyIikpLFtsaXQoImVudW0iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ7IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXNlcHMoc29ydCgiRW51bWVyYXRvciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIsIiksbGF5b3V0cygiTEFZT1VUTElTVCIpXSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgifSIpXSx7fSk00 = (IConstructor) _read("prod(label(\"enumAnonDecl\",sort(\"TypeSpecifier\")),[lit(\"enum\"),layouts(\"LAYOUTLIST\"),lit(\"{\"),layouts(\"LAYOUTLIST\"),\\iter-seps(sort(\"Enumerator\"),[layouts(\"LAYOUTLIST\"),lit(\",\"),layouts(\"LAYOUTLIST\")]),layouts(\"LAYOUTLIST\"),lit(\"}\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI9PSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhsZWZ0KCkpfSk00 = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"==\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{assoc(left())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInN0cnVjdCIpXSx7fSk00 = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"struct\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgidHlwZVNwZWNpZmllciIsc29ydCgiU3BlY2lmaWVyIikpLFtzb3J0KCJUeXBlU3BlY2lmaWVyIildLHt9KQ0000 = (IConstructor) _read("prod(label(\"typeSpecifier\",sort(\"Specifier\")),[sort(\"TypeSpecifier\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkxBWU9VVCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJMQVlPVVRcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGxleCgiTEFZT1VUIikpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",lex(\"LAYOUT\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"LAYOUT\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(lex(\"LAYOUT\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xleCgiRmxvYXRpbmdQb2ludENvbnN0YW50IildLHt0YWcoImNhdGVnb3J5IigiQ29uc3RhbnQiKSl9KQ0000 = (IConstructor) _read("prod(sort(\"Expression\"),[lex(\"FloatingPointConstant\")],{tag(\"category\"(\"Constant\"))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXJzIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgib3B0KHNvcnQoXCJQcm90b3R5cGVQYXJhbWV0ZXJzXCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIob3B0KHNvcnQoIlByb3RvdHlwZVBhcmFtZXRlcnMiKSkpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"PrototypeParameters\")),[\\char-class([range(0,0)]),lit(\"opt(sort(\\\"PrototypeParameters\\\"))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(opt(sort(\"PrototypeParameters\"))))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdHJ1Y3REZWNsYXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlN0cnVjdERlY2xhcmF0b3JcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlN0cnVjdERlY2xhcmF0b3IiKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"StructDeclarator\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"StructDeclarator\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"StructDeclarator\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIn4iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEyNiwxMjYpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"~\"),[\\char-class([range(126,126)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xleCgiSW50ZWdlckNvbnN0YW50IildLHt0YWcoImNhdGVnb3J5IigiQ29uc3RhbnQiKSl9KQ0000 = (IConstructor) _read("prod(sort(\"Expression\"),[lex(\"IntegerConstant\")],{tag(\"category\"(\"Constant\"))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJTcGVjaWZpZXJcIikpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4Myw4MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEyLDExMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMiwxMDIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"\\\\iter-star(sort(\\\"Specifier\\\"))\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(83,83)]),\\char-class([range(112,112)]),\\char-class([range(101,101)]),\\char-class([range(99,99)]),\\char-class([range(105,105)]),\\char-class([range(102,102)]),\\char-class([range(105,105)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJUeXBlTmFtZSIpLFtcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiQWJzdHJhY3REZWNsYXJhdG9yIildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"TypeName\"),[\\iter-seps(sort(\"Specifier\"),[layouts(\"LAYOUTLIST\")]),layouts(\"LAYOUTLIST\"),sort(\"AbstractDeclarator\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgibG9uZyIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGl0KCJsb25nIildLHt9KQ0000 = (IConstructor) _read("prod(label(\"long\",sort(\"TypeSpecifier\")),[lit(\"long\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiZG91YmxlIixzb3J0KCJUeXBlU3BlY2lmaWVyIikpLFtsaXQoImRvdWJsZSIpXSx7fSk00 = (IConstructor) _read("prod(label(\"double\",sort(\"TypeSpecifier\")),[lit(\"double\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xleCgiU3RyaW5nQ29uc3RhbnQiKV0se3RhZygiY2F0ZWdvcnkiKCJDb25zdGFudCIpKX0p = (IConstructor) _read("prod(sort(\"Expression\"),[lex(\"StringConstant\")],{tag(\"category\"(\"Constant\"))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJTdHJpbmdDb25zdGFudENvbnRlbnRcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODMsODMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY3LDY3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjcsNjcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"sort(\\\"StringConstantContent\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(83,83)]),\\char-class([range(116,116)]),\\char-class([range(114,114)]),\\char-class([range(105,105)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(67,67)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(67,67)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIm9wdChzb3J0KFwiUHJvdG90eXBlUGFyYW1ldGVyc1wiKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDgwLDgwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjEsMTIxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4MCw4MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"opt(sort(\\\"PrototypeParameters\\\"))\"),[\\char-class([range(111,111)]),\\char-class([range(112,112)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(80,80)]),\\char-class([range(114,114)]),\\char-class([range(111,111)]),\\char-class([range(116,116)]),\\char-class([range(111,111)]),\\char-class([range(116,116)]),\\char-class([range(121,121)]),\\char-class([range(112,112)]),\\char-class([range(101,101)]),\\char-class([range(80,80)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(109,109)]),\\char-class([range(101,101)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(115,115)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImludCIpXSx7fSk00 = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"int\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIiY9IiksW1xjaGFyLWNsYXNzKFtyYW5nZSgzOCwzOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjEsNjEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"&=\"),[\\char-class([range(38,38)]),\\char-class([range(61,61)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInNpZ25lZCIpXSx7fSk00 = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"signed\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIj0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDYxLDYxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"=\"),[\\char-class([range(61,61)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsZXgoIkFzdGVyaXNrIiksW2NvbmRpdGlvbmFsKFxjaGFyLWNsYXNzKFtyYW5nZSg0Miw0MildKSx7XG5vdC1mb2xsb3coXGNoYXItY2xhc3MoW3JhbmdlKDQ3LDQ3KV0pKX0pXSx7fSk00 = (IConstructor) _read("prod(lex(\"Asterisk\"),[conditional(\\char-class([range(42,42)]),{\\not-follow(\\char-class([range(47,47)]))})],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInx8IiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMjQsMTI0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjQsMTI0KV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"||\"),[\\char-class([range(124,124)]),\\char-class([range(124,124)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIlN0cmluZ0NvbnN0YW50IikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlN0cmluZ0NvbnN0YW50XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihsZXgoIlN0cmluZ0NvbnN0YW50IikpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",lex(\"StringConstant\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"StringConstant\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(lex(\"StringConstant\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zdGFyLXNlcHMoc29ydChcIk5vbkNvbW1hRXhwcmVzc2lvblwiKSxbbGl0KFwiLFwiKV0pIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEyLDExMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNzgsNzgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDY3LDY3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjksNjkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEyMCwxMjApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDkxLDkxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDkzLDkzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"\\\\iter-star-seps(sort(\\\"NonCommaExpression\\\"),[lit(\\\",\\\")])\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(101,101)]),\\char-class([range(112,112)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(78,78)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(67,67)]),\\char-class([range(111,111)]),\\char-class([range(109,109)]),\\char-class([range(109,109)]),\\char-class([range(97,97)]),\\char-class([range(69,69)]),\\char-class([range(120,120)]),\\char-class([range(112,112)]),\\char-class([range(114,114)]),\\char-class([range(101,101)]),\\char-class([range(115,115)]),\\char-class([range(115,115)]),\\char-class([range(105,105)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(91,91)]),\\char-class([range(108,108)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(44,44)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkxLDkxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"[\"),[\\char-class([range(91,91)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIio9IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg0Miw0MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjEsNjEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"*=\"),[\\char-class([range(42,42)]),\\char-class([range(61,61)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkZsb2F0aW5nUG9pbnRDb25zdGFudCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJGbG9hdGluZ1BvaW50Q29uc3RhbnRcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGxleCgiRmxvYXRpbmdQb2ludENvbnN0YW50IikpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",lex(\"FloatingPointConstant\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"FloatingPointConstant\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(lex(\"FloatingPointConstant\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJTdHJ1Y3REZWNsYXJhdG9yIiksW29wdChzb3J0KCJEZWNsYXJhdG9yIikpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjoiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7fSk00 = (IConstructor) _read("prod(sort(\"StructDeclarator\"),[opt(sort(\"Declarator\")),layouts(\"LAYOUTLIST\"),lit(\":\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpLHJhbmdlKDY1LDkwKSxyYW5nZSg5NSw5NSkscmFuZ2UoOTcsMTIyKV0pKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zdGFyKFxcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpLHJhbmdlKDY1LDkwKSxyYW5nZSg5NSw5NSkscmFuZ2UoOTcsMTIyKV0pKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpLHJhbmdlKDY1LDkwKSxyYW5nZSg5NSw5NSkscmFuZ2UoOTcsMTIyKV0pKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",\\char-class([range(48,57),range(65,90),range(95,95),range(97,122)])),[\\char-class([range(0,0)]),lit(\"\\\\iter-star(\\\\char-class([range(48,57),range(65,90),range(95,95),range(97,122)]))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-star(\\char-class([range(48,57),range(65,90),range(95,95),range(97,122)]))))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCItXD4iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGV4KCJJZGVudGlmaWVyIildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"-\\>\"),layouts(\"LAYOUTLIST\"),lex(\"Identifier\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIi4uLiIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoNDYsNDYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ2LDQ2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0Niw0NildKV0se30p = (IConstructor) _read("prod(lit(\"...\"),[\\char-class([range(46,46)]),\\char-class([range(46,46)]),\\char-class([range(46,46)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJQYXJhbWV0ZXJcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODAsODApXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA5LDEwOSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"sort(\\\"Parameter\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(80,80)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(109,109)]),\\char-class([range(101,101)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zdGFyKFxcY2hhci1jbGFzcyhbcmFuZ2UoMSw5KSxyYW5nZSgxMSwxNjc3NzIxNSldKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkyLDkyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNCwxMDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTEsOTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDksNDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Nyw1NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAzLDEwMyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ5LDQ5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0OSw0OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ5LDQ5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1NCw1NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTUsNTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDU1LDU1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1NSw1NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTAsNTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ5LDQ5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Myw1MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDkzLDkzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"\\\\iter-star(\\\\char-class([range(1,9),range(11,16777215)]))\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(40,40)]),\\char-class([range(92,92)]),\\char-class([range(99,99)]),\\char-class([range(104,104)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(115,115)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(91,91)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(49,49)]),\\char-class([range(44,44)]),\\char-class([range(57,57)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(49,49)]),\\char-class([range(49,49)]),\\char-class([range(44,44)]),\\char-class([range(49,49)]),\\char-class([range(54,54)]),\\char-class([range(55,55)]),\\char-class([range(55,55)]),\\char-class([range(55,55)]),\\char-class([range(50,50)]),\\char-class([range(49,49)]),\\char-class([range(53,53)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJTdHJ1Y3REZWNsYXJhdGlvblwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4Myw4MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE3LDExNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY4LDY4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"sort(\\\"StructDeclaration\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(83,83)]),\\char-class([range(116,116)]),\\char-class([range(114,114)]),\\char-class([range(117,117)]),\\char-class([range(99,99)]),\\char-class([range(116,116)]),\\char-class([range(68,68)]),\\char-class([range(101,101)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiZnVuY3Rpb25EZWNsYXJhdG9yIixzb3J0KCJEZWNsYXJhdG9yIikpLFtsYWJlbCgiZGVjbCIsc29ydCgiRGVjbGFyYXRvciIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJwYXJhbXMiLG9wdChzb3J0KCJQYXJhbWV0ZXJzIikpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIpIildLHt9KQ0000 = (IConstructor) _read("prod(label(\"functionDeclarator\",sort(\"Declarator\")),[label(\"decl\",sort(\"Declarator\")),layouts(\"LAYOUTLIST\"),lit(\"(\"),layouts(\"LAYOUTLIST\"),label(\"params\",opt(sort(\"Parameters\"))),layouts(\"LAYOUTLIST\"),lit(\")\")],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiVHlwZVF1YWxpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSk00 = (IConstructor) _read("regular(\\iter-star-seps(sort(\"TypeQualifier\"),[layouts(\"LAYOUTLIST\")]))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXJzIiksW1xpdGVyLXNlcHMoc29ydCgiUHJvdG90eXBlUGFyYW1ldGVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksb3B0KHNvcnQoIk1vcmVQYXJhbWV0ZXJzIikpXSx7fSk00 = (IConstructor) _read("prod(sort(\"PrototypeParameters\"),[\\iter-seps(sort(\"PrototypeParameter\"),[layouts(\"LAYOUTLIST\"),lit(\",\"),layouts(\"LAYOUTLIST\")]),layouts(\"LAYOUTLIST\"),opt(sort(\"MoreParameters\"))],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNlcShbXFxjaGFyLWNsYXNzKFtyYW5nZSg2NSw5MCkscmFuZ2UoOTUsOTUpLHJhbmdlKDk3LDEyMildKSxjb25kaXRpb25hbChcXGl0ZXItc3RhcihcXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KSxyYW5nZSg2NSw5MCkscmFuZ2UoOTUsOTUpLHJhbmdlKDk3LDEyMildKSkse1xcbm90LWZvbGxvdyhcXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KSxyYW5nZSg2NSw5MCkscmFuZ2UoOTUsOTUpLHJhbmdlKDk3LDEyMildKSl9KV0pIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTMsMTEzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTEsOTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDkyLDkyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA0LDEwNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ1LDQ1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5MSw5MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1NCw1NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTMsNTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Nyw1NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Nyw1NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTMsNTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Nyw1NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTMsNTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Nyw1NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTUsNTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0OSw0OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTAsNTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDUwLDUwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTMsOTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMCwxMDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTIsOTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ1LDQ1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDkyLDkyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA0LDEwNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ1LDQ1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5MSw5MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Miw1MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTYsNTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Myw1MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTUsNTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1NCw1NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTMsNTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Nyw1NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Nyw1NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTMsNTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Nyw1NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTMsNTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Nyw1NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTUsNTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0OSw0OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTAsNTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDUwLDUwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTMsOTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEyMywxMjMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDkyLDkyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAyLDEwMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE5LDExOSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDkyLDkyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA0LDEwNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ1LDQ1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5MSw5MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Miw1MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTYsNTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Myw1MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTUsNTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1NCw1NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTMsNTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Nyw1NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Nyw1NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTMsNTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Nyw1NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTMsNTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Nyw1NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTUsNTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0OSw0OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTAsNTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDUwLDUwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTMsOTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTI1LDEyNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDkzLDkzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"seq([\\\\char-class([range(65,90),range(95,95),range(97,122)]),conditional(\\\\iter-star(\\\\char-class([range(48,57),range(65,90),range(95,95),range(97,122)])),{\\\\not-follow(\\\\char-class([range(48,57),range(65,90),range(95,95),range(97,122)]))})])\"),[\\char-class([range(115,115)]),\\char-class([range(101,101)]),\\char-class([range(113,113)]),\\char-class([range(40,40)]),\\char-class([range(91,91)]),\\char-class([range(92,92)]),\\char-class([range(99,99)]),\\char-class([range(104,104)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(115,115)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(91,91)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(54,54)]),\\char-class([range(53,53)]),\\char-class([range(44,44)]),\\char-class([range(57,57)]),\\char-class([range(48,48)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(57,57)]),\\char-class([range(53,53)]),\\char-class([range(44,44)]),\\char-class([range(57,57)]),\\char-class([range(53,53)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(57,57)]),\\char-class([range(55,55)]),\\char-class([range(44,44)]),\\char-class([range(49,49)]),\\char-class([range(50,50)]),\\char-class([range(50,50)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(99,99)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(100,100)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(97,97)]),\\char-class([range(108,108)]),\\char-class([range(40,40)]),\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(40,40)]),\\char-class([range(92,92)]),\\char-class([range(99,99)]),\\char-class([range(104,104)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(115,115)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(91,91)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(52,52)]),\\char-class([range(56,56)]),\\char-class([range(44,44)]),\\char-class([range(53,53)]),\\char-class([range(55,55)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(54,54)]),\\char-class([range(53,53)]),\\char-class([range(44,44)]),\\char-class([range(57,57)]),\\char-class([range(48,48)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(57,57)]),\\char-class([range(53,53)]),\\char-class([range(44,44)]),\\char-class([range(57,57)]),\\char-class([range(53,53)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(57,57)]),\\char-class([range(55,55)]),\\char-class([range(44,44)]),\\char-class([range(49,49)]),\\char-class([range(50,50)]),\\char-class([range(50,50)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(123,123)]),\\char-class([range(92,92)]),\\char-class([range(110,110)]),\\char-class([range(111,111)]),\\char-class([range(116,116)]),\\char-class([range(45,45)]),\\char-class([range(102,102)]),\\char-class([range(111,111)]),\\char-class([range(108,108)]),\\char-class([range(108,108)]),\\char-class([range(111,111)]),\\char-class([range(119,119)]),\\char-class([range(40,40)]),\\char-class([range(92,92)]),\\char-class([range(99,99)]),\\char-class([range(104,104)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(115,115)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(91,91)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(52,52)]),\\char-class([range(56,56)]),\\char-class([range(44,44)]),\\char-class([range(53,53)]),\\char-class([range(55,55)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(54,54)]),\\char-class([range(53,53)]),\\char-class([range(44,44)]),\\char-class([range(57,57)]),\\char-class([range(48,48)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(57,57)]),\\char-class([range(53,53)]),\\char-class([range(44,44)]),\\char-class([range(57,57)]),\\char-class([range(53,53)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(57,57)]),\\char-class([range(55,55)]),\\char-class([range(44,44)]),\\char-class([range(49,49)]),\\char-class([range(50,50)]),\\char-class([range(50,50)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)]),\\char-class([range(41,41)]),\\char-class([range(125,125)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInN3aXRjaCIpXSx7fSk00 = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"switch\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiYnJhY2tldCIsc29ydCgiQWJzdHJhY3REZWNsYXJhdG9yIikpLFtsaXQoIigiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGFiZWwoImRlY2wiLHNvcnQoIkFic3RyYWN0RGVjbGFyYXRvciIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIpIildLHticmFja2V0KCl9KQ0000 = (IConstructor) _read("prod(label(\"bracket\",sort(\"AbstractDeclarator\")),[lit(\"(\"),layouts(\"LAYOUTLIST\"),label(\"decl\",sort(\"AbstractDeclarator\")),layouts(\"LAYOUTLIST\"),lit(\")\")],{bracket()})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJTdG9yYWdlQ2xhc3MiKSxbbGl0KCJhdXRvIildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"StorageClass\"),[lit(\"auto\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImNhc2UiKV0se30p = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"case\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbc29ydCgiRXhwcmVzc2lvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKV0se30p = (IConstructor) _read("prod(sort(\"Statement\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\";\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdG9yYWdlQ2xhc3MiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiU3RvcmFnZUNsYXNzXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJTdG9yYWdlQ2xhc3MiKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"StorageClass\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"StorageClass\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"StorageClass\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoIndoaWxlIildLHt9KQ0000 = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"while\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ8fCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"||\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsZXgoIkhleGFkZWNpbWFsQ29uc3RhbnQiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDQ4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4OCw4OCkscmFuZ2UoMTIwLDEyMCldKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NykscmFuZ2UoNjUsNzApLHJhbmdlKDk3LDEwMildKSksY29uZGl0aW9uYWwoXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoNzYsNzYpLHJhbmdlKDg1LDg1KSxyYW5nZSgxMDgsMTA4KSxyYW5nZSgxMTcsMTE3KV0pKSx7XG5vdC1mb2xsb3coXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KSxyYW5nZSg2NSw3MCkscmFuZ2UoOTcsMTAyKV0pKX0pXSx7fSk00 = (IConstructor) _read("prod(lex(\"HexadecimalConstant\"),[\\char-class([range(48,48)]),\\char-class([range(88,88),range(120,120)]),iter(\\char-class([range(48,57),range(65,70),range(97,102)])),conditional(\\iter-star(\\char-class([range(76,76),range(85,85),range(108,108),range(117,117)])),{\\not-follow(\\char-class([range(48,57),range(65,70),range(97,102)]))})],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiaXRlcihcXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpKSl9KQ0000 = (IConstructor) _read("prod(label(\"$MetaHole\",\\char-class([range(48,57)])),[\\char-class([range(0,0)]),lit(\"iter(\\\\char-class([range(48,57)]))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(iter(\\char-class([range(48,57)]))))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFbnVtZXJhdG9yIiksW2xleCgiSWRlbnRpZmllciIpXSx7fSk00 = (IConstructor) _read("prod(sort(\"Enumerator\"),[lex(\"Identifier\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJUeXBlU3BlY2lmaWVyIiksW2xpdCgidW5zaWduZWQiKV0se30p = (IConstructor) _read("prod(sort(\"TypeSpecifier\"),[lit(\"unsigned\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJOb25Db21tYUV4cHJlc3Npb24iKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc3Rhci1zZXBzKHNvcnQoXCJOb25Db21tYUV4cHJlc3Npb25cIiksW2xpdChcIixcIildKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc3Rhci1zZXBzKHNvcnQoIk5vbkNvbW1hRXhwcmVzc2lvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIsIiksbGF5b3V0cygiTEFZT1VUTElTVCIpXSkpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"NonCommaExpression\")),[\\char-class([range(0,0)]),lit(\"\\\\iter-star-seps(sort(\\\"NonCommaExpression\\\"),[lit(\\\",\\\")])\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-star-seps(sort(\"NonCommaExpression\"),[layouts(\"LAYOUTLIST\"),lit(\",\"),layouts(\"LAYOUTLIST\")])))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImNoYXIiKV0se30p = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"char\")],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihvcHQoc29ydCgiUHJvdG90eXBlUGFyYW1ldGVycyIpKSk00 = (IConstructor) _read("regular(opt(sort(\"PrototypeParameters\")))", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp = (IConstructor) _read("regular(\\iter-star(\\char-class([range(48,57)])))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIisrIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg0Myw0MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDMsNDMpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"++\"),[\\char-class([range(43,43)]),\\char-class([range(43,43)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPD0iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7YXNzb2MobGVmdCgpKX0p = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"\\<=\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{assoc(left())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPFw8IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKGxlZnQoKSl9KQ0000 = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"\\<\\<\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{assoc(left())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJTdHJ1Y3REZWNsYXJhdG9yIiksW3NvcnQoIkRlY2xhcmF0b3IiKV0se30p = (IConstructor) _read("prod(sort(\"StructDeclarator\"),[sort(\"Declarator\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImRlZmF1bHQiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwMCwxMDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMiwxMDIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"default\"),[\\char-class([range(100,100)]),\\char-class([range(101,101)]),\\char-class([range(102,102)]),\\char-class([range(97,97)]),\\char-class([range(117,117)]),\\char-class([range(108,108)]),\\char-class([range(116,116)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlw8XDwiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDYwLDYwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2MCw2MCldKV0se30p = (IConstructor) _read("prod(lit(\"\\<\\<\"),[\\char-class([range(60,60)]),\\char-class([range(60,60)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgibm9uQ29tbWFFeHByZXNzaW9uIixzb3J0KCJOb25Db21tYUV4cHJlc3Npb24iKSksW2xhYmVsKCJleHByIixzb3J0KCJFeHByZXNzaW9uIikpXSx7fSk00 = (IConstructor) _read("prod(label(\"nonCommaExpression\",sort(\"NonCommaExpression\")),[label(\"expr\",sort(\"Expression\"))],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImNvbnN0IildLHt9KQ0000 = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"const\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJEZWNsYXJhdGlvblwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJEZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Declaration\")),[\\char-class([range(0,0)]),lit(\"\\\\iter-star(sort(\\\"Declaration\\\"))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-star-seps(sort(\"Declaration\"),[layouts(\"LAYOUTLIST\")])))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHRlcm5hbERlY2xhcmF0aW9uIiksW3NvcnQoIkZ1bmN0aW9uRGVmaW5pdGlvbiIpXSx7fSk00 = (IConstructor) _read("prod(sort(\"ExternalDeclaration\"),[sort(\"FunctionDefinition\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdGF0ZW1lbnQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc3Rhcihzb3J0KFwiU3RhdGVtZW50XCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0YXRlbWVudCIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Statement\")),[\\char-class([range(0,0)]),lit(\"\\\\iter-star(sort(\\\"Statement\\\"))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-star-seps(sort(\"Statement\"),[layouts(\"LAYOUTLIST\")])))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJ3aGlsZSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIigiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiU3RhdGVtZW50IildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"Statement\"),[lit(\"while\"),layouts(\"LAYOUTLIST\"),lit(\"(\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\")\"),layouts(\"LAYOUTLIST\"),sort(\"Statement\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgic3RydWN0Iixzb3J0KCJUeXBlU3BlY2lmaWVyIikpLFtsaXQoInN0cnVjdCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsZXgoIklkZW50aWZpZXIiKV0se30p = (IConstructor) _read("prod(label(\"struct\",sort(\"TypeSpecifier\")),[lit(\"struct\"),layouts(\"LAYOUTLIST\"),lex(\"Identifier\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIiYmIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgzOCwzOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzgsMzgpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"&&\"),[\\char-class([range(38,38)]),\\char-class([range(38,38)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJJbnRlZ2VyQ29uc3RhbnRcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNzMsNzMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY3LDY3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"sort(\\\"IntegerConstant\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(73,73)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(67,67)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJpZiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIigiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiU3RhdGVtZW50IildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"Statement\"),[lit(\"if\"),layouts(\"LAYOUTLIST\"),lit(\"(\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\")\"),layouts(\"LAYOUTLIST\"),sort(\"Statement\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInR5cGVkZWYiKV0se30p = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"typedef\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInwiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEyNCwxMjQpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"|\"),[\\char-class([range(124,124)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImV4dGVybiIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTIwLDEyMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKV0se30p = (IConstructor) _read("prod(lit(\"extern\"),[\\char-class([range(101,101)]),\\char-class([range(120,120)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(110,110)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgid2hpdGVzcGFjZSIsbGV4KCJMQVlPVVQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSg5LDEwKSxyYW5nZSgxMywxMykscmFuZ2UoMzIsMzIpXSldLHt9KQ0000 = (IConstructor) _read("prod(label(\"whitespace\",lex(\"LAYOUT\")),[\\char-class([range(9,10),range(13,13),range(32,32)])],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp = (IConstructor) _read("regular(iter(\\char-class([range(48,57)])))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPlw11PSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"\\>\\>=\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{assoc(right())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJIZXhhZGVjaW1hbENvbnN0YW50XCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDcyLDcyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjAsMTIwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAwLDEwMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2Nyw2NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"sort(\\\"HexadecimalConstant\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(72,72)]),\\char-class([range(101,101)]),\\char-class([range(120,120)]),\\char-class([range(97,97)]),\\char-class([range(100,100)]),\\char-class([range(101,101)]),\\char-class([range(99,99)]),\\char-class([range(105,105)]),\\char-class([range(109,109)]),\\char-class([range(97,97)]),\\char-class([range(108,108)]),\\char-class([range(67,67)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYXlvdXRzKCJMQVlPVVRMSVNUIiksW2NvbmRpdGlvbmFsKFxpdGVyLXN0YXIobGV4KCJMQVlPVVQiKSkse1xub3QtZm9sbG93KFxjaGFyLWNsYXNzKFtyYW5nZSg5LDEwKSxyYW5nZSgxMywxMykscmFuZ2UoMzIsMzIpXSkpfSldLHt9KQ0000 = (IConstructor) _read("prod(layouts(\"LAYOUTLIST\"),[conditional(\\iter-star(lex(\"LAYOUT\")),{\\not-follow(\\char-class([range(9,10),range(13,13),range(32,32)]))})],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiaWRlbnRpZmllciIsc29ydCgiUHJvdG90eXBlRGVjbGFyYXRvciIpKSxbbGV4KCJJZGVudGlmaWVyIildLHt9KQ0000 = (IConstructor) _read("prod(label(\"identifier\",sort(\"PrototypeDeclarator\")),[lex(\"Identifier\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkRlY2xhcmF0b3JcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIkRlY2xhcmF0b3IiKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Declarator\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"Declarator\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"Declarator\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzdGFydChzb3J0KCJUcmFuc2xhdGlvblVuaXQiKSksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgidG9wIixzb3J0KCJUcmFuc2xhdGlvblVuaXQiKSksbGF5b3V0cygiTEFZT1VUTElTVCIpXSx7fSk00 = (IConstructor) _read("prod(start(sort(\"TranslationUnit\")),[layouts(\"LAYOUTLIST\"),label(\"top\",sort(\"TranslationUnit\")),layouts(\"LAYOUTLIST\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIml0ZXIoc29ydChcIkNoYXJhY3RlckNvbnN0YW50Q29udGVudFwiKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY3LDY3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDQsMTA0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2Nyw2NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY3LDY3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"iter(sort(\\\"CharacterConstantContent\\\"))\"),[\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(67,67)]),\\char-class([range(104,104)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(99,99)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(67,67)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(67,67)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFeHByZXNzaW9uIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkV4cHJlc3Npb25cIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIkV4cHJlc3Npb24iKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Expression\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"Expression\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"Expression\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiLSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"Expression\"),[lit(\"-\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiKyIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"Expression\"),[lit(\"+\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiKiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"Expression\"),[lit(\"*\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgicG9pbnRlckRlY2xhcmF0b3IiLHNvcnQoIlByb3RvdHlwZURlY2xhcmF0b3IiKSksW2xpdCgiKiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgicXVhbGlmaWVycyIsXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlR5cGVRdWFsaWZpZXIiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgiZGVjbCIsc29ydCgiUHJvdG90eXBlRGVjbGFyYXRvciIpKV0se30p = (IConstructor) _read("prod(label(\"pointerDeclarator\",sort(\"PrototypeDeclarator\")),[lit(\"*\"),layouts(\"LAYOUTLIST\"),label(\"qualifiers\",\\iter-star-seps(sort(\"TypeQualifier\"),[layouts(\"LAYOUTLIST\")])),layouts(\"LAYOUTLIST\"),label(\"decl\",sort(\"PrototypeDeclarator\"))],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImNvbnN0IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKV0se30p = (IConstructor) _read("prod(lit(\"const\"),[\\char-class([range(99,99)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(115,115)]),\\char-class([range(116,116)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgidW5pb25Bbm9uRGVjbCIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGl0KCJ1bmlvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoInsiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0cnVjdERlY2xhcmF0aW9uIiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIn0iKV0se30p = (IConstructor) _read("prod(label(\"unionAnonDecl\",sort(\"TypeSpecifier\")),[lit(\"union\"),layouts(\"LAYOUTLIST\"),lit(\"{\"),layouts(\"LAYOUTLIST\"),\\iter-star-seps(sort(\"StructDeclaration\"),[layouts(\"LAYOUTLIST\")]),layouts(\"LAYOUTLIST\"),lit(\"}\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIrPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"+=\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{assoc(right())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkludGVnZXJDb25zdGFudCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJJbnRlZ2VyQ29uc3RhbnRcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGxleCgiSW50ZWdlckNvbnN0YW50IikpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",lex(\"IntegerConstant\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"IntegerConstant\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(lex(\"IntegerConstant\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJ7IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJEZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0YXRlbWVudCIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ9IildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"Statement\"),[lit(\"{\"),layouts(\"LAYOUTLIST\"),\\iter-star-seps(sort(\"Declaration\"),[layouts(\"LAYOUTLIST\")]),layouts(\"LAYOUTLIST\"),\\iter-star-seps(sort(\"Statement\"),[layouts(\"LAYOUTLIST\")]),layouts(\"LAYOUTLIST\"),lit(\"}\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJUeXBlU3BlY2lmaWVyIiksW2xpdCgic2lnbmVkIildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"TypeSpecifier\"),[lit(\"signed\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiYXJyYXlEZWNsYXJhdG9yIixzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSksW2xhYmVsKCJkZWNsIixzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiWyIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgiZXhwIixvcHQoc29ydCgiRXhwcmVzc2lvbiIpKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiXSIpXSx7fSk00 = (IConstructor) _read("prod(label(\"arrayDeclarator\",sort(\"AbstractDeclarator\")),[label(\"decl\",sort(\"AbstractDeclarator\")),layouts(\"LAYOUTLIST\"),lit(\"[\"),layouts(\"LAYOUTLIST\"),label(\"exp\",opt(sort(\"Expression\"))),layouts(\"LAYOUTLIST\"),lit(\"]\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInJlZ2lzdGVyIildLHt9KQ0000 = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"register\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJGdW5jdGlvbkRlZmluaXRpb25cIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNzAsNzApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNywxMTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2OCw2OCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAyLDEwMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"sort(\\\"FunctionDefinition\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(70,70)]),\\char-class([range(117,117)]),\\char-class([range(110,110)]),\\char-class([range(99,99)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(68,68)]),\\char-class([range(101,101)]),\\char-class([range(102,102)]),\\char-class([range(105,105)]),\\char-class([range(110,110)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixcY2hhci1jbGFzcyhbcmFuZ2UoNDMsNDMpLHJhbmdlKDQ1LDQ1KV0pKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIm9wdChcXGNoYXItY2xhc3MoW3JhbmdlKDQzLDQzKSxyYW5nZSg0NSw0NSldKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKG9wdChcY2hhci1jbGFzcyhbcmFuZ2UoNDMsNDMpLHJhbmdlKDQ1LDQ1KV0pKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",\\char-class([range(43,43),range(45,45)])),[\\char-class([range(0,0)]),lit(\"opt(\\\\char-class([range(43,43),range(45,45)]))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(opt(\\char-class([range(43,43),range(45,45)]))))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFeHRlcm5hbERlY2xhcmF0aW9uIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkV4dGVybmFsRGVjbGFyYXRpb25cIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIkV4dGVybmFsRGVjbGFyYXRpb24iKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"ExternalDeclaration\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"ExternalDeclaration\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"ExternalDeclaration\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiZW51bSIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGl0KCJlbnVtIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxleCgiSWRlbnRpZmllciIpXSx7fSk00 = (IConstructor) _read("prod(label(\"enum\",sort(\"TypeSpecifier\")),[lit(\"enum\"),layouts(\"LAYOUTLIST\"),lex(\"Identifier\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInN3aXRjaCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE5LDExOSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNCwxMDQpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"switch\"),[\\char-class([range(115,115)]),\\char-class([range(119,119)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(99,99)]),\\char-class([range(104,104)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiKCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJUeXBlTmFtZSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7fSk00 = (IConstructor) _read("prod(sort(\"Expression\"),[lit(\"(\"),layouts(\"LAYOUTLIST\"),sort(\"TypeName\"),layouts(\"LAYOUTLIST\"),lit(\")\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsZXgoIkNoYXJhY3RlckNvbnN0YW50IiksW29wdChcY2hhci1jbGFzcyhbcmFuZ2UoNzYsNzYpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgzOSwzOSldKSxpdGVyKGxleCgiQ2hhcmFjdGVyQ29uc3RhbnRDb250ZW50IikpLFxjaGFyLWNsYXNzKFtyYW5nZSgzOSwzOSldKV0se30p = (IConstructor) _read("prod(lex(\"CharacterConstant\"),[opt(\\char-class([range(76,76)])),\\char-class([range(39,39)]),iter(lex(\"CharacterConstantContent\")),\\char-class([range(39,39)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiISIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"Expression\"),[lit(\"!\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiJiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"Expression\"),[lit(\"&\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgidW5pb25EZWNsIixzb3J0KCJUeXBlU3BlY2lmaWVyIikpLFtsaXQoInVuaW9uIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxleCgiSWRlbnRpZmllciIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoInsiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0cnVjdERlY2xhcmF0aW9uIiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIn0iKV0se30p = (IConstructor) _read("prod(label(\"unionDecl\",sort(\"TypeSpecifier\")),[lit(\"union\"),layouts(\"LAYOUTLIST\"),lex(\"Identifier\"),layouts(\"LAYOUTLIST\"),lit(\"{\"),layouts(\"LAYOUTLIST\"),\\iter-star-seps(sort(\"StructDeclaration\"),[layouts(\"LAYOUTLIST\")]),layouts(\"LAYOUTLIST\"),lit(\"}\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJUeXBlUXVhbGlmaWVyIiksW2xpdCgidm9sYXRpbGUiKV0se30p = (IConstructor) _read("prod(sort(\"TypeQualifier\"),[lit(\"volatile\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInVuaW9uIildLHt9KQ0000 = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"union\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJDaGFyYWN0ZXJDb25zdGFudFwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2Nyw2NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA0LDEwNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjcsNjcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"sort(\\\"CharacterConstant\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(67,67)]),\\char-class([range(104,104)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(99,99)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(67,67)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSg3Niw3NikscmFuZ2UoODUsODUpLHJhbmdlKDEwOCwxMDgpLHJhbmdlKDExNywxMTcpXSkpKQ0000 = (IConstructor) _read("regular(\\iter-star(\\char-class([range(76,76),range(85,85),range(108,108),range(117,117)])))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTcGVjaWZpZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJpdGVyKHNvcnQoXCJTcGVjaWZpZXJcIikpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Specifier\")),[\\char-class([range(0,0)]),lit(\"iter(sort(\\\"Specifier\\\"))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-seps(sort(\"Specifier\"),[layouts(\"LAYOUTLIST\")])))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJQYXJhbWV0ZXJzXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDgwLDgwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"sort(\\\"Parameters\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(80,80)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(109,109)]),\\char-class([range(101,101)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(115,115)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJkbyIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJTdGF0ZW1lbnQiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ3aGlsZSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIigiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI7IildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"Statement\"),[lit(\"do\"),layouts(\"LAYOUTLIST\"),sort(\"Statement\"),layouts(\"LAYOUTLIST\"),lit(\"while\"),layouts(\"LAYOUTLIST\"),lit(\"(\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\")\"),layouts(\"LAYOUTLIST\"),lit(\";\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJQYXJhbWV0ZXJzIiksW1xpdGVyLXNlcHMoc29ydCgiUGFyYW1ldGVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksb3B0KHNvcnQoIk1vcmVQYXJhbWV0ZXJzIikpXSx7fSk00 = (IConstructor) _read("prod(sort(\"Parameters\"),[\\iter-seps(sort(\"Parameter\"),[layouts(\"LAYOUTLIST\"),lit(\",\"),layouts(\"LAYOUTLIST\")]),layouts(\"LAYOUTLIST\"),opt(sort(\"MoreParameters\"))],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIm9wdChzb3J0KFwiRXhwb25lbnRcIikpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2OSw2OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTIwLDEyMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEyLDExMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"opt(sort(\\\"Exponent\\\"))\"),[\\char-class([range(111,111)]),\\char-class([range(112,112)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(69,69)]),\\char-class([range(120,120)]),\\char-class([range(112,112)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(101,101)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJQYXJhbWV0ZXIiKSxbXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRGVjbGFyYXRvciIpXSx7fSk00 = (IConstructor) _read("prod(sort(\"Parameter\"),[\\iter-star-seps(sort(\"Specifier\"),[layouts(\"LAYOUTLIST\")]),layouts(\"LAYOUTLIST\"),sort(\"Declarator\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIlN0cmluZ0NvbnN0YW50Q29udGVudCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJTdHJpbmdDb25zdGFudENvbnRlbnRcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGxleCgiU3RyaW5nQ29uc3RhbnRDb250ZW50IikpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",lex(\"StringConstantContent\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"StringConstantContent\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(lex(\"StringConstantContent\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInR5cGVkZWYiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEyMSwxMjEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMCwxMDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMiwxMDIpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"typedef\"),[\\char-class([range(116,116)]),\\char-class([range(121,121)]),\\char-class([range(112,112)]),\\char-class([range(101,101)]),\\char-class([range(100,100)]),\\char-class([range(101,101)]),\\char-class([range(102,102)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgib3B0KHNvcnQoXCJEZWNsYXJhdG9yXCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIob3B0KHNvcnQoIkRlY2xhcmF0b3IiKSkpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Declarator\")),[\\char-class([range(0,0)]),lit(\"opt(sort(\\\"Declarator\\\"))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(opt(sort(\"Declarator\"))))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJTdHJ1Y3REZWNsYXJhdG9yXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDgzLDgzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjgsNjgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"sort(\\\"StructDeclarator\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(83,83)]),\\char-class([range(116,116)]),\\char-class([range(114,114)]),\\char-class([range(117,117)]),\\char-class([range(99,99)]),\\char-class([range(116,116)]),\\char-class([range(68,68)]),\\char-class([range(101,101)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJnb3RvIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxleCgiSWRlbnRpZmllciIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKV0se30p = (IConstructor) _read("prod(sort(\"Statement\"),[lit(\"goto\"),layouts(\"LAYOUTLIST\"),lex(\"Identifier\"),layouts(\"LAYOUTLIST\"),lit(\";\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJGbG9hdGluZ1BvaW50Q29uc3RhbnRcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNzAsNzApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4MCw4MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjcsNjcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"sort(\\\"FloatingPointConstant\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(70,70)]),\\char-class([range(108,108)]),\\char-class([range(111,111)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(80,80)]),\\char-class([range(111,111)]),\\char-class([range(105,105)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(67,67)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInVuc2lnbmVkIildLHt9KQ0000 = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"unsigned\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgic3RydWN0RGVjbFdpdGhvdXREZWNsIixzb3J0KCJTdHJ1Y3REZWNsYXJhdGlvbiIpKSxbbGFiZWwoInNwZWNzIixcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOyIpXSx7fSk00 = (IConstructor) _read("prod(label(\"structDeclWithoutDecl\",sort(\"StructDeclaration\")),[label(\"specs\",\\iter-seps(sort(\"Specifier\"),[layouts(\"LAYOUTLIST\")])),layouts(\"LAYOUTLIST\"),lit(\";\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIm9wdChzb3J0KFwiUGFyYW1ldGVyc1wiKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDgwLDgwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"opt(sort(\\\"Parameters\\\"))\"),[\\char-class([range(111,111)]),\\char-class([range(112,112)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(80,80)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(109,109)]),\\char-class([range(101,101)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(115,115)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJMQVlPVVRcIikpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg3Niw3NildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjUsNjUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDg5LDg5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg3OSw3OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODUsODUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDg0LDg0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"\\\\iter-star(sort(\\\"LAYOUT\\\"))\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(76,76)]),\\char-class([range(65,65)]),\\char-class([range(89,89)]),\\char-class([range(79,79)]),\\char-class([range(85,85)]),\\char-class([range(84,84)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiU3BlY2lmaWVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pKQ0000 = (IConstructor) _read("regular(\\iter-star-seps(sort(\"Specifier\"),[layouts(\"LAYOUTLIST\")]))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNpZ25lZCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAzLDEwMyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAwLDEwMCldKV0se30p = (IConstructor) _read("prod(lit(\"signed\"),[\\char-class([range(115,115)]),\\char-class([range(105,105)]),\\char-class([range(103,103)]),\\char-class([range(110,110)]),\\char-class([range(101,101)]),\\char-class([range(100,100)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTcGVjaWZpZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiU3BlY2lmaWVyXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJTcGVjaWZpZXIiKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Specifier\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"Specifier\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"Specifier\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJFeHBvbmVudFwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2OSw2OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTIwLDEyMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEyLDExMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"sort(\\\"Exponent\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(69,69)]),\\char-class([range(120,120)]),\\char-class([range(112,112)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(101,101)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiZGVjbGFyYXRpb25XaXRob3V0SW5pdERlY2xzIixzb3J0KCJEZWNsYXJhdGlvbiIpKSxbbGFiZWwoInNwZWNzIixcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOyIpXSx7fSk00 = (IConstructor) _read("prod(label(\"declarationWithoutInitDecls\",sort(\"Declaration\")),[label(\"specs\",\\iter-seps(sort(\"Specifier\"),[layouts(\"LAYOUTLIST\")])),layouts(\"LAYOUTLIST\"),lit(\";\")],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NykscmFuZ2UoNjUsNzApLHJhbmdlKDk3LDEwMildKSkp = (IConstructor) _read("regular(iter(\\char-class([range(48,57),range(65,70),range(97,102)])))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXJzIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlByb3RvdHlwZVBhcmFtZXRlcnNcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlByb3RvdHlwZVBhcmFtZXRlcnMiKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"PrototypeParameters\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"PrototypeParameters\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"PrototypeParameters\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJEZWNsYXJhdGlvblwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiRGVjbGFyYXRpb24iKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Declaration\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"Declaration\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"Declaration\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJUeXBlU3BlY2lmaWVyIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlR5cGVTcGVjaWZpZXJcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlR5cGVTcGVjaWZpZXIiKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"TypeSpecifier\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"TypeSpecifier\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"TypeSpecifier\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsZXgoIk11bHRpTGluZUNvbW1lbnRCb2R5VG9rZW4iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEsNDEpLHJhbmdlKDQzLDE2Nzc3MjE1KV0pXSx7fSk00 = (IConstructor) _read("prod(lex(\"MultiLineCommentBodyToken\"),[\\char-class([range(1,41),range(43,16777215)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkNoYXJhY3RlckNvbnN0YW50Q29udGVudCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIml0ZXIoc29ydChcIkNoYXJhY3RlckNvbnN0YW50Q29udGVudFwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGl0ZXIobGV4KCJDaGFyYWN0ZXJDb25zdGFudENvbnRlbnQiKSkpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",lex(\"CharacterConstantContent\")),[\\char-class([range(0,0)]),lit(\"iter(sort(\\\"CharacterConstantContent\\\"))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(iter(lex(\"CharacterConstantContent\"))))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIiYiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDM4LDM4KV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"&\"),[\\char-class([range(38,38)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJFbnVtZXJhdG9yXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY5LDY5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"sort(\\\"Enumerator\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(69,69)]),\\char-class([range(110,110)]),\\char-class([range(117,117)]),\\char-class([range(109,109)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpLHJhbmdlKDY1LDcwKSxyYW5nZSg5NywxMDIpXSkpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiaXRlcihcXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KSxyYW5nZSg2NSw3MCkscmFuZ2UoOTcsMTAyKV0pKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpLHJhbmdlKDY1LDcwKSxyYW5nZSg5NywxMDIpXSkpKSl9KQ0000 = (IConstructor) _read("prod(label(\"$MetaHole\",\\char-class([range(48,57),range(65,70),range(97,102)])),[\\char-class([range(0,0)]),lit(\"iter(\\\\char-class([range(48,57),range(65,70),range(97,102)]))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(iter(\\char-class([range(48,57),range(65,70),range(97,102)]))))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJUeXBlU3BlY2lmaWVyXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDg0LDg0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjEsMTIxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4Myw4MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEyLDExMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMiwxMDIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"sort(\\\"TypeSpecifier\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(84,84)]),\\char-class([range(121,121)]),\\char-class([range(112,112)]),\\char-class([range(101,101)]),\\char-class([range(83,83)]),\\char-class([range(112,112)]),\\char-class([range(101,101)]),\\char-class([range(99,99)]),\\char-class([range(105,105)]),\\char-class([range(102,102)]),\\char-class([range(105,105)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIqPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"*=\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{assoc(right())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJjYXNlIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI6IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIlN0YXRlbWVudCIpXSx7fSk00 = (IConstructor) _read("prod(sort(\"Statement\"),[lit(\"case\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\":\"),layouts(\"LAYOUTLIST\"),sort(\"Statement\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkhleGFkZWNpbWFsQ29uc3RhbnQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiSGV4YWRlY2ltYWxDb25zdGFudFwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIobGV4KCJIZXhhZGVjaW1hbENvbnN0YW50IikpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",lex(\"HexadecimalConstant\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"HexadecimalConstant\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(lex(\"HexadecimalConstant\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIjsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU5LDU5KV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\";\"),[\\char-class([range(59,59)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIndoaWxlIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTksMTE5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDQsMTA0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"while\"),[\\char-class([range(119,119)]),\\char-class([range(104,104)]),\\char-class([range(105,105)]),\\char-class([range(108,108)]),\\char-class([range(101,101)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJQcm90b3R5cGVEZWNsYXJhdG9yXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDgwLDgwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjEsMTIxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2OCw2OCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"sort(\\\"PrototypeDeclarator\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(80,80)]),\\char-class([range(114,114)]),\\char-class([range(111,111)]),\\char-class([range(116,116)]),\\char-class([range(111,111)]),\\char-class([range(116,116)]),\\char-class([range(121,121)]),\\char-class([range(112,112)]),\\char-class([range(101,101)]),\\char-class([range(68,68)]),\\char-class([range(101,101)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihvcHQobGV4KCJFeHBvbmVudCIpKSk00 = (IConstructor) _read("regular(opt(lex(\"Exponent\")))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIm9wdChcXGNoYXItY2xhc3MoW3JhbmdlKDQzLDQzKSxyYW5nZSg0NSw0NSldKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNCwxMDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTEsOTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTIsNTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDUxLDUxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTIsNTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDUxLDUxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTIsNTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDUzLDUzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTIsNTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDUzLDUzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTMsOTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"opt(\\\\char-class([range(43,43),range(45,45)]))\"),[\\char-class([range(111,111)]),\\char-class([range(112,112)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(92,92)]),\\char-class([range(99,99)]),\\char-class([range(104,104)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(115,115)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(91,91)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(52,52)]),\\char-class([range(51,51)]),\\char-class([range(44,44)]),\\char-class([range(52,52)]),\\char-class([range(51,51)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(52,52)]),\\char-class([range(53,53)]),\\char-class([range(44,44)]),\\char-class([range(52,52)]),\\char-class([range(53,53)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIi09IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjEsNjEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"-=\"),[\\char-class([range(45,45)]),\\char-class([range(61,61)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImRlZmF1bHQiKV0se30p = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"default\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCImJiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"&&\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdHJ1Y3REZWNsYXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiXFxpdGVyLXNlcHMoc29ydChcIlN0cnVjdERlY2xhcmF0b3JcIiksW2xpdChcIixcIildKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc2Vwcyhzb3J0KCJTdHJ1Y3REZWNsYXJhdG9yIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"StructDeclarator\")),[\\char-class([range(0,0)]),lit(\"\\\\iter-seps(sort(\\\"StructDeclarator\\\"),[lit(\\\",\\\")])\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-seps(sort(\"StructDeclarator\"),[layouts(\"LAYOUTLIST\"),lit(\",\"),layouts(\"LAYOUTLIST\")])))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQYXJhbWV0ZXJzIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlBhcmFtZXRlcnNcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlBhcmFtZXRlcnMiKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Parameters\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"Parameters\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"Parameters\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPlw11IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKGxlZnQoKSl9KQ0000 = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"\\>\\>\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{assoc(left())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJyZXR1cm4iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI7IildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"Statement\"),[lit(\"return\"),layouts(\"LAYOUTLIST\"),lit(\";\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsZXgoIklkZW50aWZpZXIiKSxbY29uZGl0aW9uYWwoc2VxKFtcY2hhci1jbGFzcyhbcmFuZ2UoNjUsOTApLHJhbmdlKDk1LDk1KSxyYW5nZSg5NywxMjIpXSksY29uZGl0aW9uYWwoXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpLHJhbmdlKDY1LDkwKSxyYW5nZSg5NSw5NSkscmFuZ2UoOTcsMTIyKV0pKSx7XG5vdC1mb2xsb3coXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KSxyYW5nZSg2NSw5MCkscmFuZ2UoOTUsOTUpLHJhbmdlKDk3LDEyMildKSl9KV0pLHtkZWxldGUoa2V5d29yZHMoIktleXdvcmQiKSl9KV0se30p = (IConstructor) _read("prod(lex(\"Identifier\"),[conditional(seq([\\char-class([range(65,90),range(95,95),range(97,122)]),conditional(\\iter-star(\\char-class([range(48,57),range(65,90),range(95,95),range(97,122)])),{\\not-follow(\\char-class([range(48,57),range(65,90),range(95,95),range(97,122)]))})]),{delete(keywords(\"Keyword\"))})],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiZ2xvYmFsRGVjbGFyYXRpb25XaXRoSW5pdERlY2xzIixzb3J0KCJHbG9iYWxEZWNsYXJhdGlvbiIpKSxbbGFiZWwoInNwZWNzMCIsXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJpbml0RGVjbGFyYXRvcnMiLFxpdGVyLXNlcHMoc29ydCgiSW5pdERlY2xhcmF0b3IiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiLCIpLGxheW91dHMoIkxBWU9VVExJU1QiKV0pKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI7IildLHt9KQ0000 = (IConstructor) _read("prod(label(\"globalDeclarationWithInitDecls\",sort(\"GlobalDeclaration\")),[label(\"specs0\",\\iter-star-seps(sort(\"Specifier\"),[layouts(\"LAYOUTLIST\")])),layouts(\"LAYOUTLIST\"),label(\"initDeclarators\",\\iter-seps(sort(\"InitDeclarator\"),[layouts(\"LAYOUTLIST\"),lit(\",\"),layouts(\"LAYOUTLIST\")])),layouts(\"LAYOUTLIST\"),lit(\";\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiZW51bURlY2wiLHNvcnQoIlR5cGVTcGVjaWZpZXIiKSksW2xpdCgiZW51bSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsZXgoIklkZW50aWZpZXIiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ7IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXNlcHMoc29ydCgiRW51bWVyYXRvciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIsIiksbGF5b3V0cygiTEFZT1VUTElTVCIpXSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgifSIpXSx7fSk00 = (IConstructor) _read("prod(label(\"enumDecl\",sort(\"TypeSpecifier\")),[lit(\"enum\"),layouts(\"LAYOUTLIST\"),lex(\"Identifier\"),layouts(\"LAYOUTLIST\"),lit(\"{\"),layouts(\"LAYOUTLIST\"),\\iter-seps(sort(\"Enumerator\"),[layouts(\"LAYOUTLIST\"),lit(\",\"),layouts(\"LAYOUTLIST\")]),layouts(\"LAYOUTLIST\"),lit(\"}\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJmb3IiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLG9wdChzb3J0KCJFeHByZXNzaW9uIikpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksb3B0KHNvcnQoIkV4cHJlc3Npb24iKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOyIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxvcHQoc29ydCgiRXhwcmVzc2lvbiIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIpIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIlN0YXRlbWVudCIpXSx7fSk00 = (IConstructor) _read("prod(sort(\"Statement\"),[lit(\"for\"),layouts(\"LAYOUTLIST\"),lit(\"(\"),layouts(\"LAYOUTLIST\"),opt(sort(\"Expression\")),layouts(\"LAYOUTLIST\"),lit(\";\"),layouts(\"LAYOUTLIST\"),opt(sort(\"Expression\")),layouts(\"LAYOUTLIST\"),lit(\";\"),layouts(\"LAYOUTLIST\"),opt(sort(\"Expression\")),layouts(\"LAYOUTLIST\"),lit(\")\"),layouts(\"LAYOUTLIST\"),sort(\"Statement\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgicG9pbnRlckRlY2xhcmF0b3IiLHNvcnQoIkFic3RyYWN0RGVjbGFyYXRvciIpKSxbbGl0KCIqIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJxdWFsaWZpZXJzIixcaXRlci1zdGFyLXNlcHMoc29ydCgiVHlwZVF1YWxpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJkZWNsIixzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSldLHt9KQ0000 = (IConstructor) _read("prod(label(\"pointerDeclarator\",sort(\"AbstractDeclarator\")),[lit(\"*\"),layouts(\"LAYOUTLIST\"),label(\"qualifiers\",\\iter-star-seps(sort(\"TypeQualifier\"),[layouts(\"LAYOUTLIST\")])),layouts(\"LAYOUTLIST\"),label(\"decl\",sort(\"AbstractDeclarator\"))],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJMQVlPVVRcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNzYsNzYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY1LDY1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4OSw4OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNzksNzkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDg1LDg1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4NCw4NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"sort(\\\"LAYOUT\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(76,76)]),\\char-class([range(65,65)]),\\char-class([range(89,89)]),\\char-class([range(79,79)]),\\char-class([range(85,85)]),\\char-class([range(84,84)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImZsb2F0IildLHt9KQ0000 = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"float\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgidmFyaWFibGUiLHNvcnQoIkV4cHJlc3Npb24iKSksW2xleCgiSWRlbnRpZmllciIpXSx7fSk00 = (IConstructor) _read("prod(label(\"variable\",sort(\"Expression\")),[lex(\"Identifier\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJGdW5jdGlvbkRlZmluaXRpb24iKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiRnVuY3Rpb25EZWZpbml0aW9uXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJGdW5jdGlvbkRlZmluaXRpb24iKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"FunctionDefinition\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"FunctionDefinition\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"FunctionDefinition\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJOb25Db21tYUV4cHJlc3Npb24iKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiTm9uQ29tbWFFeHByZXNzaW9uXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJOb25Db21tYUV4cHJlc3Npb24iKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"NonCommaExpression\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"NonCommaExpression\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"NonCommaExpression\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJBbm9ueW1vdXNJZGVudGlmaWVyXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY1LDY1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjEsMTIxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg3Myw3MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAwLDEwMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAyLDEwMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"sort(\\\"AnonymousIdentifier\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(65,65)]),\\char-class([range(110,110)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(121,121)]),\\char-class([range(109,109)]),\\char-class([range(111,111)]),\\char-class([range(117,117)]),\\char-class([range(115,115)]),\\char-class([range(73,73)]),\\char-class([range(100,100)]),\\char-class([range(101,101)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(102,102)]),\\char-class([range(105,105)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsZXgoIkV4cG9uZW50IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg2OSw2OSkscmFuZ2UoMTAxLDEwMSldKSxvcHQoXGNoYXItY2xhc3MoW3JhbmdlKDQzLDQzKSxyYW5nZSg0NSw0NSldKSksY29uZGl0aW9uYWwoaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLHtcbm90LWZvbGxvdyhcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpfSldLHt9KQ0000 = (IConstructor) _read("prod(lex(\"Exponent\"),[\\char-class([range(69,69),range(101,101)]),opt(\\char-class([range(43,43),range(45,45)])),conditional(iter(\\char-class([range(48,57)])),{\\not-follow(\\char-class([range(48,57)]))})],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJJbml0RGVjbGFyYXRvclwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg3Myw3MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjgsNjgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"sort(\\\"InitDeclarator\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(73,73)]),\\char-class([range(110,110)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(68,68)]),\\char-class([range(101,101)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJUeXBlTmFtZSIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJUeXBlTmFtZVwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiVHlwZU5hbWUiKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"TypeName\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"TypeName\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"TypeName\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImxvbmciKV0se30p = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"long\")],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiRGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkp = (IConstructor) _read("regular(\\iter-star-seps(sort(\"Declaration\"),[layouts(\"LAYOUTLIST\")]))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiZ2xvYmFsRGVjbGFyYXRpb25XaXRob3V0SW5pdERlY2xzIixzb3J0KCJHbG9iYWxEZWNsYXJhdGlvbiIpKSxbbGFiZWwoInNwZWNzMSIsXGl0ZXItc2Vwcyhzb3J0KCJTcGVjaWZpZXIiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKV0se30p = (IConstructor) _read("prod(label(\"globalDeclarationWithoutInitDecls\",sort(\"GlobalDeclaration\")),[label(\"specs1\",\\iter-seps(sort(\"Specifier\"),[layouts(\"LAYOUTLIST\")])),layouts(\"LAYOUTLIST\"),lit(\";\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJJbml0aWFsaXplciIpLFtsaXQoInsiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksXGl0ZXItc2Vwcyhzb3J0KCJJbml0aWFsaXplciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIsIiksbGF5b3V0cygiTEFZT1VUTElTVCIpXSksbGF5b3V0cygiTEFZT1VUTElTVCIpLG9wdChsaXQoIiwiKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgifSIpXSx7fSk00 = (IConstructor) _read("prod(sort(\"Initializer\"),[lit(\"{\"),layouts(\"LAYOUTLIST\"),\\iter-seps(sort(\"Initializer\"),[layouts(\"LAYOUTLIST\"),lit(\",\"),layouts(\"LAYOUTLIST\")]),layouts(\"LAYOUTLIST\"),opt(lit(\",\")),layouts(\"LAYOUTLIST\"),lit(\"}\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEyMywxMjMpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"{\"),[\\char-class([range(123,123)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImNvbnRpbnVlIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE3LDExNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKV0se30p = (IConstructor) _read("prod(lit(\"continue\"),[\\char-class([range(99,99)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(110,110)]),\\char-class([range(117,117)]),\\char-class([range(101,101)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIm9wdChzb3J0KFwiRXhwcmVzc2lvblwiKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY5LDY5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjAsMTIwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"opt(sort(\\\"Expression\\\"))\"),[\\char-class([range(111,111)]),\\char-class([range(112,112)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(69,69)]),\\char-class([range(120,120)]),\\char-class([range(112,112)]),\\char-class([range(114,114)]),\\char-class([range(101,101)]),\\char-class([range(115,115)]),\\char-class([range(115,115)]),\\char-class([range(105,105)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlw11PSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoNjIsNjIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDYxLDYxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"\\>=\"),[\\char-class([range(62,62)]),\\char-class([range(61,61)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInJlZ2lzdGVyIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"register\"),[\\char-class([range(114,114)]),\\char-class([range(101,101)]),\\char-class([range(103,103)]),\\char-class([range(105,105)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiQWJzdHJhY3REZWNsYXJhdG9yXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"AbstractDeclarator\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"AbstractDeclarator\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"AbstractDeclarator\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInN0YXRpYyIpXSx7fSk00 = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"static\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJFeHRlcm5hbERlY2xhcmF0aW9uXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY5LDY5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjAsMTIwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjgsNjgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"sort(\\\"ExternalDeclaration\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(69,69)]),\\char-class([range(120,120)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(110,110)]),\\char-class([range(97,97)]),\\char-class([range(108,108)]),\\char-class([range(68,68)]),\\char-class([range(101,101)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJNb3JlUGFyYW1ldGVycyIpLFtsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIuLi4iKV0se30p = (IConstructor) _read("prod(sort(\"MoreParameters\"),[lit(\",\"),layouts(\"LAYOUTLIST\"),lit(\"...\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJzd2l0Y2giKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIpIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIlN0YXRlbWVudCIpXSx7fSk00 = (IConstructor) _read("prod(sort(\"Statement\"),[lit(\"switch\"),layouts(\"LAYOUTLIST\"),lit(\"(\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\")\"),layouts(\"LAYOUTLIST\"),sort(\"Statement\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJkZWZhdWx0IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJTdGF0ZW1lbnQiKV0se30p = (IConstructor) _read("prod(sort(\"Statement\"),[lit(\"default\"),layouts(\"LAYOUTLIST\"),lit(\":\"),layouts(\"LAYOUTLIST\"),sort(\"Statement\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInNpemVvZiIpXSx7fSk00 = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"sizeof\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInZvbGF0aWxlIildLHt9KQ0000 = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"volatile\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJJbml0RGVjbGFyYXRvciIpLFtsYWJlbCgiZGVjbCIsc29ydCgiRGVjbGFyYXRvciIpKV0se30p = (IConstructor) _read("prod(sort(\"InitDeclarator\"),[label(\"decl\",sort(\"Declarator\"))],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYXlvdXRzKCIkZGVmYXVsdCQiKSxbXSx7fSk00 = (IConstructor) _read("prod(layouts(\"$default$\"),[],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPFw8PSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"\\<\\<=\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{assoc(right())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xleCgiSGV4YWRlY2ltYWxDb25zdGFudCIpXSx7dGFnKCJjYXRlZ29yeSIoIkNvbnN0YW50IikpfSk00 = (IConstructor) _read("prod(sort(\"Expression\"),[lex(\"HexadecimalConstant\")],{tag(\"category\"(\"Constant\"))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixcY2hhci1jbGFzcyhbcmFuZ2UoNzYsNzYpLHJhbmdlKDg1LDg1KSxyYW5nZSgxMDgsMTA4KSxyYW5nZSgxMTcsMTE3KV0pKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zdGFyKFxcY2hhci1jbGFzcyhbcmFuZ2UoNzYsNzYpLHJhbmdlKDg1LDg1KSxyYW5nZSgxMDgsMTA4KSxyYW5nZSgxMTcsMTE3KV0pKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoNzYsNzYpLHJhbmdlKDg1LDg1KSxyYW5nZSgxMDgsMTA4KSxyYW5nZSgxMTcsMTE3KV0pKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",\\char-class([range(76,76),range(85,85),range(108,108),range(117,117)])),[\\char-class([range(0,0)]),lit(\"\\\\iter-star(\\\\char-class([range(76,76),range(85,85),range(108,108),range(117,117)]))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-star(\\char-class([range(76,76),range(85,85),range(108,108),range(117,117)]))))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIlPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"%=\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{assoc(right())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImZvciIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTAyLDEwMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKV0se30p = (IConstructor) _read("prod(lit(\"for\"),[\\char-class([range(102,102)]),\\char-class([range(111,111)]),\\char-class([range(114,114)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInZvaWQiKV0se30p = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"void\")],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RydWN0RGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkp = (IConstructor) _read("regular(\\iter-star-seps(sort(\"StructDeclaration\"),[layouts(\"LAYOUTLIST\")]))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIm9wdChcXGNoYXItY2xhc3MoW3JhbmdlKDcwLDcwKSxyYW5nZSg3Niw3NikscmFuZ2UoMTAyLDEwMikscmFuZ2UoMTA4LDEwOCldKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNCwxMDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTEsOTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTUsNTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDQ4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTUsNTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDQ4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTUsNTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDU0LDU0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTUsNTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDU0LDU0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDksNDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDQ4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1MCw1MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ5LDQ5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw0OCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTAsNTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0OSw0OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDU2LDU2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDksNDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDQ4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Niw1NildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDkzLDkzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"opt(\\\\char-class([range(70,70),range(76,76),range(102,102),range(108,108)]))\"),[\\char-class([range(111,111)]),\\char-class([range(112,112)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(92,92)]),\\char-class([range(99,99)]),\\char-class([range(104,104)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(115,115)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(91,91)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(55,55)]),\\char-class([range(48,48)]),\\char-class([range(44,44)]),\\char-class([range(55,55)]),\\char-class([range(48,48)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(55,55)]),\\char-class([range(54,54)]),\\char-class([range(44,44)]),\\char-class([range(55,55)]),\\char-class([range(54,54)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(49,49)]),\\char-class([range(48,48)]),\\char-class([range(50,50)]),\\char-class([range(44,44)]),\\char-class([range(49,49)]),\\char-class([range(48,48)]),\\char-class([range(50,50)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(49,49)]),\\char-class([range(48,48)]),\\char-class([range(56,56)]),\\char-class([range(44,44)]),\\char-class([range(49,49)]),\\char-class([range(48,48)]),\\char-class([range(56,56)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJyZXR1cm4iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKV0se30p = (IConstructor) _read("prod(sort(\"Statement\"),[lit(\"return\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\";\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTcGVjaWZpZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc3Rhcihzb3J0KFwiU3BlY2lmaWVyXCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Specifier\")),[\\char-class([range(0,0)]),lit(\"\\\\iter-star(sort(\\\"Specifier\\\"))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-star-seps(sort(\"Specifier\"),[layouts(\"LAYOUTLIST\")])))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJUeXBlTmFtZVwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4NCw4NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTIxLDEyMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEyLDExMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNzgsNzgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"sort(\\\"TypeName\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(84,84)]),\\char-class([range(121,121)]),\\char-class([range(112,112)]),\\char-class([range(101,101)]),\\char-class([range(78,78)]),\\char-class([range(97,97)]),\\char-class([range(109,109)]),\\char-class([range(101,101)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCItPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"-=\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{assoc(right())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImVsc2UiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"else\"),[\\char-class([range(101,101)]),\\char-class([range(108,108)]),\\char-class([range(115,115)]),\\char-class([range(101,101)])],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zZXBzKHNvcnQoIlBhcmFtZXRlciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIsIiksbGF5b3V0cygiTEFZT1VUTElTVCIpXSkp = (IConstructor) _read("regular(\\iter-seps(sort(\"Parameter\"),[layouts(\"LAYOUTLIST\"),lit(\",\"),layouts(\"LAYOUTLIST\")]))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImF1dG8iKV0se30p = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"auto\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInN0cnVjdCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE3LDExNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"struct\"),[\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(114,114)]),\\char-class([range(117,117)]),\\char-class([range(99,99)]),\\char-class([range(116,116)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHRlcm5hbERlY2xhcmF0aW9uIiksW3NvcnQoIkdsb2JhbERlY2xhcmF0aW9uIildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"ExternalDeclaration\"),[sort(\"GlobalDeclaration\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiXFxpdGVyLXN0YXIoXFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXN0YXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",\\char-class([range(48,57)])),[\\char-class([range(0,0)]),lit(\"\\\\iter-star(\\\\char-class([range(48,57)]))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-star(\\char-class([range(48,57)]))))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImNoYXIiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDQsMTA0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKV0se30p = (IConstructor) _read("prod(lit(\"char\"),[\\char-class([range(99,99)]),\\char-class([range(104,104)]),\\char-class([range(97,97)]),\\char-class([range(114,114)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgidHlwZURlZiIsc29ydCgiU3RvcmFnZUNsYXNzIikpLFtsaXQoInR5cGVkZWYiKV0se30p = (IConstructor) _read("prod(label(\"typeDef\",sort(\"StorageClass\")),[lit(\"typedef\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsZXgoIkNvbW1lbnQiKSxbbGl0KCIvLyIpLFxpdGVyLXN0YXIoXGNoYXItY2xhc3MoW3JhbmdlKDEsOSkscmFuZ2UoMTEsMTY3NzcyMTUpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgxMCwxMCldKV0se30p = (IConstructor) _read("prod(lex(\"Comment\"),[lit(\"//\"),\\iter-star(\\char-class([range(1,9),range(11,16777215)])),\\char-class([range(10,10)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInZvaWQiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExOCwxMTgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMCwxMDApXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"void\"),[\\char-class([range(118,118)]),\\char-class([range(111,111)]),\\char-class([range(105,105)]),\\char-class([range(100,100)])],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSgxLDkpLHJhbmdlKDExLDE2Nzc3MjE1KV0pKSk00 = (IConstructor) _read("regular(\\iter-star(\\char-class([range(1,9),range(11,16777215)])))", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zdGFyKGxleCgiTEFZT1VUIikpKQ0000 = (IConstructor) _read("regular(\\iter-star(lex(\"LAYOUT\")))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhsZWZ0KCkpfSk00 = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"\\>\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{assoc(left())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhsZWZ0KCkpfSk00 = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"\\<\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{assoc(left())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsZXgoIkZsb2F0aW5nUG9pbnRDb25zdGFudCIpLFtcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDQ2LDQ2KV0pLGNvbmRpdGlvbmFsKGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSx7XG5vdC1mb2xsb3coXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKX0pLG9wdChsZXgoIkV4cG9uZW50IikpLG9wdChcY2hhci1jbGFzcyhbcmFuZ2UoNzAsNzApLHJhbmdlKDc2LDc2KSxyYW5nZSgxMDIsMTAyKSxyYW5nZSgxMDgsMTA4KV0pKV0se30p = (IConstructor) _read("prod(lex(\"FloatingPointConstant\"),[\\iter-star(\\char-class([range(48,57)])),\\char-class([range(46,46)]),conditional(iter(\\char-class([range(48,57)])),{\\not-follow(\\char-class([range(48,57)]))}),opt(lex(\"Exponent\")),opt(\\char-class([range(70,70),range(76,76),range(102,102),range(108,108)]))],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIhPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhsZWZ0KCkpfSk00 = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"!=\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{assoc(left())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\":\"),[\\char-class([range(58,58)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIi8vIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg0Nyw0NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDcsNDcpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"//\"),[\\char-class([range(47,47)]),\\char-class([range(47,47)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIml0ZXIoXFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNCwxMDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTEsOTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTIsNTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDU2LDU2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTMsNTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDU1LDU1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTMsOTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"iter(\\\\char-class([range(48,57)]))\"),[\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(40,40)]),\\char-class([range(92,92)]),\\char-class([range(99,99)]),\\char-class([range(104,104)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(115,115)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(91,91)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(52,52)]),\\char-class([range(56,56)]),\\char-class([range(44,44)]),\\char-class([range(53,53)]),\\char-class([range(55,55)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiaWRlbnRpZmllciIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGV4KCJJZGVudGlmaWVyIildLHt9KQ0000 = (IConstructor) _read("prod(label(\"identifier\",sort(\"TypeSpecifier\")),[lex(\"Identifier\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCImIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se30p = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"&\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zZXBzKHNvcnQoXCJQYXJhbWV0ZXJcIiksW2xpdChcIixcIildKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoOTIsOTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ1LDQ1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4MCw4MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5MSw5MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Myw5MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"\\\\iter-seps(sort(\\\"Parameter\\\"),[lit(\\\",\\\")])\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(101,101)]),\\char-class([range(112,112)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(80,80)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(109,109)]),\\char-class([range(101,101)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(91,91)]),\\char-class([range(108,108)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(44,44)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInVuaW9uIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"union\"),[\\char-class([range(117,117)]),\\char-class([range(110,110)]),\\char-class([range(105,105)]),\\char-class([range(111,111)]),\\char-class([range(110,110)])],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihvcHQobGl0KCIsIikpKQ0000 = (IConstructor) _read("regular(opt(lit(\",\")))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJNdWx0aUxpbmVDb21tZW50Qm9keVRva2VuXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDc3LDc3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg3Niw3NildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjcsNjcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY2LDY2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDAsMTAwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjEsMTIxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4NCw4NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA3LDEwNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"sort(\\\"MultiLineCommentBodyToken\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(77,77)]),\\char-class([range(117,117)]),\\char-class([range(108,108)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(76,76)]),\\char-class([range(105,105)]),\\char-class([range(110,110)]),\\char-class([range(101,101)]),\\char-class([range(67,67)]),\\char-class([range(111,111)]),\\char-class([range(109,109)]),\\char-class([range(109,109)]),\\char-class([range(101,101)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(66,66)]),\\char-class([range(111,111)]),\\char-class([range(100,100)]),\\char-class([range(121,121)]),\\char-class([range(84,84)]),\\char-class([range(111,111)]),\\char-class([range(107,107)]),\\char-class([range(101,101)]),\\char-class([range(110,110)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJUcmFuc2xhdGlvblVuaXRcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODQsODQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODUsODUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"sort(\\\"TranslationUnit\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(84,84)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(115,115)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(85,85)]),\\char-class([range(110,110)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihvcHQoc29ydCgiRXhwcmVzc2lvbiIpKSk00 = (IConstructor) _read("regular(opt(sort(\"Expression\")))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiZGVjbGFyYXRpb25XaXRoSW5pdERlY2xzIixzb3J0KCJEZWNsYXJhdGlvbiIpKSxbbGFiZWwoInNwZWNzIixcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJpbml0RGVjbGFyYXRvcnMiLFxpdGVyLXNlcHMoc29ydCgiSW5pdERlY2xhcmF0b3IiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiLCIpLGxheW91dHMoIkxBWU9VVExJU1QiKV0pKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI7IildLHt9KQ0000 = (IConstructor) _read("prod(label(\"declarationWithInitDecls\",sort(\"Declaration\")),[label(\"specs\",\\iter-seps(sort(\"Specifier\"),[layouts(\"LAYOUTLIST\")])),layouts(\"LAYOUTLIST\"),label(\"initDeclarators\",\\iter-seps(sort(\"InitDeclarator\"),[layouts(\"LAYOUTLIST\"),lit(\",\"),layouts(\"LAYOUTLIST\")])),layouts(\"LAYOUTLIST\"),lit(\";\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIlIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKGxlZnQoKSl9KQ0000 = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"%\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{assoc(left())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJOb25Db21tYUV4cHJlc3Npb24iKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiLCIpLGxheW91dHMoIkxBWU9VVExJU1QiKV0pLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKV0se30p = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"(\"),layouts(\"LAYOUTLIST\"),\\iter-star-seps(sort(\"NonCommaExpression\"),[layouts(\"LAYOUTLIST\"),lit(\",\"),layouts(\"LAYOUTLIST\")]),layouts(\"LAYOUTLIST\"),lit(\")\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIj09IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg2MSw2MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjEsNjEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"==\"),[\\char-class([range(61,61)]),\\char-class([range(61,61)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJTcGVjaWZpZXJcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODMsODMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDIsMTAyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"sort(\\\"Specifier\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(83,83)]),\\char-class([range(112,112)]),\\char-class([range(101,101)]),\\char-class([range(99,99)]),\\char-class([range(105,105)]),\\char-class([range(102,102)]),\\char-class([range(105,105)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImNhc2UiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKV0se30p = (IConstructor) _read("prod(lit(\"case\"),[\\char-class([range(99,99)]),\\char-class([range(97,97)]),\\char-class([range(115,115)]),\\char-class([range(101,101)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFbnVtZXJhdG9yIiksW2xleCgiSWRlbnRpZmllciIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIj0iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiTm9uQ29tbWFFeHByZXNzaW9uIildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"Enumerator\"),[lex(\"Identifier\"),layouts(\"LAYOUTLIST\"),lit(\"=\"),layouts(\"LAYOUTLIST\"),sort(\"NonCommaExpression\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJQYXJhbWV0ZXJzIiksW2xpdCgidm9pZCIpXSx7fSk00 = (IConstructor) _read("prod(sort(\"Parameters\"),[lit(\"void\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlw8XDw9IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg2MCw2MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjAsNjApXSksXGNoYXItY2xhc3MoW3JhbmdlKDYxLDYxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"\\<\\<=\"),[\\char-class([range(60,60)]),\\char-class([range(60,60)]),\\char-class([range(61,61)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJUeXBlUXVhbGlmaWVyIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiXFxpdGVyLXN0YXIoc29ydChcIlR5cGVRdWFsaWZpZXJcIikpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zdGFyLXNlcHMoc29ydCgiVHlwZVF1YWxpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"TypeQualifier\")),[\\char-class([range(0,0)]),lit(\"\\\\iter-star(sort(\\\"TypeQualifier\\\"))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-star-seps(sort(\"TypeQualifier\"),[layouts(\"LAYOUTLIST\")])))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInN0YXRpYyIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"static\"),[\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(99,99)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgic3RydWN0QW5vbkRlY2wiLHNvcnQoIlR5cGVTcGVjaWZpZXIiKSksW2xpdCgic3RydWN0IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgieyIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RydWN0RGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgifSIpXSx7fSk00 = (IConstructor) _read("prod(label(\"structAnonDecl\",sort(\"TypeSpecifier\")),[lit(\"struct\"),layouts(\"LAYOUTLIST\"),lit(\"{\"),layouts(\"LAYOUTLIST\"),\\iter-star-seps(sort(\"StructDeclaration\"),[layouts(\"LAYOUTLIST\")]),layouts(\"LAYOUTLIST\"),lit(\"}\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zZXBzKHNvcnQoXCJFbnVtZXJhdG9yXCIpLFtsaXQoXCIsXCIpXSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkyLDkyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEyLDExMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjksNjkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNywxMTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5MSw5MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Myw5MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"\\\\iter-seps(sort(\\\"Enumerator\\\"),[lit(\\\",\\\")])\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(101,101)]),\\char-class([range(112,112)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(69,69)]),\\char-class([range(110,110)]),\\char-class([range(117,117)]),\\char-class([range(109,109)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(91,91)]),\\char-class([range(108,108)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(44,44)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiZnVuY3Rpb25EZWNsYXJhdG9yIixzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSksW2xhYmVsKCJkZWNsIixzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiKCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgicGFyYW1zIixvcHQoc29ydCgiUGFyYW1ldGVycyIpKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiKSIpXSx7fSk00 = (IConstructor) _read("prod(label(\"functionDeclarator\",sort(\"AbstractDeclarator\")),[label(\"decl\",sort(\"AbstractDeclarator\")),layouts(\"LAYOUTLIST\"),lit(\"(\"),layouts(\"LAYOUTLIST\"),label(\"params\",opt(sort(\"Parameters\"))),layouts(\"LAYOUTLIST\"),lit(\")\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgic2hvcnQiLHNvcnQoIlR5cGVTcGVjaWZpZXIiKSksW2xpdCgic2hvcnQiKV0se30p = (IConstructor) _read("prod(label(\"short\",sort(\"TypeSpecifier\")),[lit(\"short\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChlbXB0eSgpLFtdLHt9KQ0000 = (IConstructor) _read("prod(empty(),[],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIi0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ1LDQ1KV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"-\"),[\\char-class([range(45,45)])],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSk00 = (IConstructor) _read("regular(\\iter-seps(sort(\"Specifier\"),[layouts(\"LAYOUTLIST\")]))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsZXgoIlN0cmluZ0NvbnN0YW50IiksW29wdChcY2hhci1jbGFzcyhbcmFuZ2UoNzYsNzYpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcaXRlci1zdGFyKGxleCgiU3RyaW5nQ29uc3RhbnRDb250ZW50IikpLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKV0se30p = (IConstructor) _read("prod(lex(\"StringConstant\"),[opt(\\char-class([range(76,76)])),\\char-class([range(34,34)]),\\iter-star(lex(\"StringConstantContent\")),\\char-class([range(34,34)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIrIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKGxlZnQoKSl9KQ0000 = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"+\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{assoc(left())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIvIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKGxlZnQoKSl9KQ0000 = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"/\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{assoc(left())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCItIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKGxlZnQoKSl9KQ0000 = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"-\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{assoc(left())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiZGVmYXVsdEZ1bmN0aW9uRGVmaW5pdGlvbiIsc29ydCgiRnVuY3Rpb25EZWZpbml0aW9uIikpLFtsYWJlbCgic3BlY3MiLFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJTcGVjaWZpZXIiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJEZWNsYXJhdG9yIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJEZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ7IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJEZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0YXRlbWVudCIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ9IildLHt9KQ0000 = (IConstructor) _read("prod(label(\"defaultFunctionDefinition\",sort(\"FunctionDefinition\")),[label(\"specs\",\\iter-star-seps(sort(\"Specifier\"),[layouts(\"LAYOUTLIST\")])),layouts(\"LAYOUTLIST\"),sort(\"Declarator\"),layouts(\"LAYOUTLIST\"),\\iter-star-seps(sort(\"Declaration\"),[layouts(\"LAYOUTLIST\")]),layouts(\"LAYOUTLIST\"),lit(\"{\"),layouts(\"LAYOUTLIST\"),\\iter-star-seps(sort(\"Declaration\"),[layouts(\"LAYOUTLIST\")]),layouts(\"LAYOUTLIST\"),\\iter-star-seps(sort(\"Statement\"),[layouts(\"LAYOUTLIST\")]),layouts(\"LAYOUTLIST\"),lit(\"}\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc2Vwcyhzb3J0KFwiUHJvdG90eXBlUGFyYW1ldGVyXCIpLFtsaXQoXCIsXCIpXSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXNlcHMoc29ydCgiUHJvdG90eXBlUGFyYW1ldGVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"PrototypeParameter\")),[\\char-class([range(0,0)]),lit(\"\\\\iter-seps(sort(\\\"PrototypeParameter\\\"),[lit(\\\",\\\")])\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-seps(sort(\"PrototypeParameter\"),[layouts(\"LAYOUTLIST\"),lit(\",\"),layouts(\"LAYOUTLIST\")])))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJePSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"^=\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{assoc(right())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJGdW5jdGlvblByb3RvdHlwZSIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJGdW5jdGlvblByb3RvdHlwZVwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiRnVuY3Rpb25Qcm90b3R5cGUiKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"FunctionPrototype\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"FunctionPrototype\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"FunctionPrototype\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkFzdGVyaXNrIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkFzdGVyaXNrXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihsZXgoIkFzdGVyaXNrIikpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",lex(\"Asterisk\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"Asterisk\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(lex(\"Asterisk\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJpZiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIigiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiU3RhdGVtZW50IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiZWxzZSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJTdGF0ZW1lbnQiKV0se30p = (IConstructor) _read("prod(sort(\"Statement\"),[lit(\"if\"),layouts(\"LAYOUTLIST\"),lit(\"(\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\")\"),layouts(\"LAYOUTLIST\"),sort(\"Statement\"),layouts(\"LAYOUTLIST\"),lit(\"else\"),layouts(\"LAYOUTLIST\"),sort(\"Statement\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImVudW0iKV0se30p = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"enum\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJTdG9yYWdlQ2xhc3NcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODMsODMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2Nyw2NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"sort(\\\"StorageClass\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(83,83)]),\\char-class([range(116,116)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(67,67)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(115,115)]),\\char-class([range(115,115)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJJbml0aWFsaXplclwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg3Myw3MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEyMiwxMjIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"sort(\\\"Initializer\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(73,73)]),\\char-class([range(110,110)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(97,97)]),\\char-class([range(108,108)]),\\char-class([range(105,105)]),\\char-class([range(122,122)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zZXBzKHNvcnQoXCJQcm90b3R5cGVQYXJhbWV0ZXJcIiksW2xpdChcIixcIildKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoOTIsOTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ1LDQ1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4MCw4MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTIxLDEyMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEyLDExMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODAsODApXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA5LDEwOSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTEsOTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTMsOTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"\\\\iter-seps(sort(\\\"PrototypeParameter\\\"),[lit(\\\",\\\")])\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(101,101)]),\\char-class([range(112,112)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(80,80)]),\\char-class([range(114,114)]),\\char-class([range(111,111)]),\\char-class([range(116,116)]),\\char-class([range(111,111)]),\\char-class([range(116,116)]),\\char-class([range(121,121)]),\\char-class([range(112,112)]),\\char-class([range(101,101)]),\\char-class([range(80,80)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(109,109)]),\\char-class([range(101,101)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(91,91)]),\\char-class([range(108,108)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(44,44)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdGF0ZW1lbnQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiU3RhdGVtZW50XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJTdGF0ZW1lbnQiKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Statement\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"Statement\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"Statement\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsZXgoIlN0cmluZ0NvbnN0YW50Q29udGVudCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoOTIsOTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEsMTY3NzcyMTUpXSldLHt9KQ0000 = (IConstructor) _read("prod(lex(\"StringConstantContent\"),[\\char-class([range(92,92)]),\\char-class([range(1,16777215)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImludCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKV0se30p = (IConstructor) _read("prod(lit(\"int\"),[\\char-class([range(105,105)]),\\char-class([range(110,110)]),\\char-class([range(116,116)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgidm9pZCIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGl0KCJ2b2lkIildLHt9KQ0000 = (IConstructor) _read("prod(label(\"void\",sort(\"TypeSpecifier\")),[lit(\"void\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImlmIildLHt9KQ0000 = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"if\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJJbml0RGVjbGFyYXRvciIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zZXBzKHNvcnQoXCJJbml0RGVjbGFyYXRvclwiKSxbbGl0KFwiLFwiKV0pIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zZXBzKHNvcnQoIkluaXREZWNsYXJhdG9yIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"InitDeclarator\")),[\\char-class([range(0,0)]),lit(\"\\\\iter-seps(sort(\\\"InitDeclarator\\\"),[lit(\\\",\\\")])\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-seps(sort(\"InitDeclarator\"),[layouts(\"LAYOUTLIST\"),lit(\",\"),layouts(\"LAYOUTLIST\")])))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsaXQoIiwiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJvcHQobGl0KFwiLFwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKG9wdChsaXQoIiwiKSkpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",lit(\",\")),[\\char-class([range(0,0)]),lit(\"opt(lit(\\\",\\\"))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(opt(lit(\",\"))))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlw8PSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoNjAsNjApXSksXGNoYXItY2xhc3MoW3JhbmdlKDYxLDYxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"\\<=\"),[\\char-class([range(60,60)]),\\char-class([range(61,61)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJBc3Rlcmlza1wiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2NSw2NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA3LDEwNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"sort(\\\"Asterisk\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(65,65)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(105,105)]),\\char-class([range(115,115)]),\\char-class([range(107,107)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJTdG9yYWdlQ2xhc3MiKSxbbGl0KCJleHRlcm4iKV0se30p = (IConstructor) _read("prod(sort(\"StorageClass\"),[lit(\"extern\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQcm90b3R5cGVEZWNsYXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlByb3RvdHlwZURlY2xhcmF0b3JcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlByb3RvdHlwZURlY2xhcmF0b3IiKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"PrototypeDeclarator\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"PrototypeDeclarator\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"PrototypeDeclarator\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIiUiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDM3LDM3KV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"%\"),[\\char-class([range(37,37)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGV4KCJJZGVudGlmaWVyIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJTdGF0ZW1lbnQiKV0se30p = (IConstructor) _read("prod(sort(\"Statement\"),[lex(\"Identifier\"),layouts(\"LAYOUTLIST\"),lit(\":\"),layouts(\"LAYOUTLIST\"),sort(\"Statement\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJUeXBlUXVhbGlmaWVyXCIpKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoOTIsOTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ1LDQ1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODQsODQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEyMSwxMjEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDgxLDgxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAyLDEwMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"\\\\iter-star(sort(\\\"TypeQualifier\\\"))\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(84,84)]),\\char-class([range(121,121)]),\\char-class([range(112,112)]),\\char-class([range(101,101)]),\\char-class([range(81,81)]),\\char-class([range(117,117)]),\\char-class([range(97,97)]),\\char-class([range(108,108)]),\\char-class([range(105,105)]),\\char-class([range(102,102)]),\\char-class([range(105,105)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJGdW5jdGlvblByb3RvdHlwZVwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg3MCw3MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE3LDExNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDgwLDgwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjEsMTIxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"sort(\\\"FunctionPrototype\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(70,70)]),\\char-class([range(117,117)]),\\char-class([range(110,110)]),\\char-class([range(99,99)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(80,80)]),\\char-class([range(114,114)]),\\char-class([range(111,111)]),\\char-class([range(116,116)]),\\char-class([range(111,111)]),\\char-class([range(116,116)]),\\char-class([range(121,121)]),\\char-class([range(112,112)]),\\char-class([range(101,101)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJUeXBlUXVhbGlmaWVyXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDg0LDg0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjEsMTIxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4MSw4MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE3LDExNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMiwxMDIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"sort(\\\"TypeQualifier\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(84,84)]),\\char-class([range(121,121)]),\\char-class([range(112,112)]),\\char-class([range(101,101)]),\\char-class([range(81,81)]),\\char-class([range(117,117)]),\\char-class([range(97,97)]),\\char-class([range(108,108)]),\\char-class([range(105,105)]),\\char-class([range(102,102)]),\\char-class([range(105,105)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInJldHVybiIpXSx7fSk00 = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"return\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQYXJhbWV0ZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiUGFyYW1ldGVyXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJQYXJhbWV0ZXIiKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Parameter\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"Parameter\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"Parameter\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkxBWU9VVCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJMQVlPVVRcIikpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zdGFyKGxleCgiTEFZT1VUIikpKSl9KQ0000 = (IConstructor) _read("prod(label(\"$MetaHole\",lex(\"LAYOUT\")),[\\char-class([range(0,0)]),lit(\"\\\\iter-star(sort(\\\"LAYOUT\\\"))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-star(lex(\"LAYOUT\"))))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIi4iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ2LDQ2KV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\".\"),[\\char-class([range(46,46)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsZXgoIkZsb2F0aW5nUG9pbnRDb25zdGFudCIpLFtpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDQ2LDQ2KV0pLG9wdChsZXgoIkV4cG9uZW50IikpLG9wdChcY2hhci1jbGFzcyhbcmFuZ2UoNzAsNzApLHJhbmdlKDc2LDc2KSxyYW5nZSgxMDIsMTAyKSxyYW5nZSgxMDgsMTA4KV0pKV0se30p = (IConstructor) _read("prod(lex(\"FloatingPointConstant\"),[iter(\\char-class([range(48,57)])),\\char-class([range(46,46)]),opt(lex(\"Exponent\")),opt(\\char-class([range(70,70),range(76,76),range(102,102),range(108,108)]))],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImVsc2UiKV0se30p = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"else\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXJzIiksW2xpdCgidm9pZCIpXSx7fSk00 = (IConstructor) _read("prod(sort(\"PrototypeParameters\"),[lit(\"void\")],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihvcHQoc29ydCgiTW9yZVBhcmFtZXRlcnMiKSkp = (IConstructor) _read("regular(opt(sort(\"MoreParameters\")))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJTdHJpbmdDb25zdGFudENvbnRlbnRcIikpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4Myw4MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAzLDEwMyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjcsNjcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2Nyw2NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"\\\\iter-star(sort(\\\"StringConstantContent\\\"))\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(83,83)]),\\char-class([range(116,116)]),\\char-class([range(114,114)]),\\char-class([range(105,105)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(67,67)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(67,67)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJOb25Db21tYUV4cHJlc3Npb25cIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNzgsNzgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDY3LDY3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjksNjkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEyMCwxMjApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"sort(\\\"NonCommaExpression\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(78,78)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(67,67)]),\\char-class([range(111,111)]),\\char-class([range(109,109)]),\\char-class([range(109,109)]),\\char-class([range(97,97)]),\\char-class([range(69,69)]),\\char-class([range(120,120)]),\\char-class([range(112,112)]),\\char-class([range(114,114)]),\\char-class([range(101,101)]),\\char-class([range(115,115)]),\\char-class([range(115,115)]),\\char-class([range(105,105)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zZXBzKHNvcnQoXCJTdHJ1Y3REZWNsYXJhdG9yXCIpLFtsaXQoXCIsXCIpXSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkyLDkyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEyLDExMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODMsODMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNywxMTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2OCw2OCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTEsOTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTMsOTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"\\\\iter-seps(sort(\\\"StructDeclarator\\\"),[lit(\\\",\\\")])\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(101,101)]),\\char-class([range(112,112)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(83,83)]),\\char-class([range(116,116)]),\\char-class([range(114,114)]),\\char-class([range(117,117)]),\\char-class([range(99,99)]),\\char-class([range(116,116)]),\\char-class([range(68,68)]),\\char-class([range(101,101)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(91,91)]),\\char-class([range(108,108)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(44,44)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiYXJyYXlEZWNsYXJhdG9yIixzb3J0KCJQcm90b3R5cGVEZWNsYXJhdG9yIikpLFtsYWJlbCgicHJvdG9fZGVjbCIsc29ydCgiUHJvdG90eXBlRGVjbGFyYXRvciIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJbIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJleHAiLG9wdChzb3J0KCJFeHByZXNzaW9uIikpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJdIildLHt9KQ0000 = (IConstructor) _read("prod(label(\"arrayDeclarator\",sort(\"PrototypeDeclarator\")),[label(\"proto_decl\",sort(\"PrototypeDeclarator\")),layouts(\"LAYOUTLIST\"),lit(\"[\"),layouts(\"LAYOUTLIST\"),label(\"exp\",opt(sort(\"Expression\"))),layouts(\"LAYOUTLIST\"),lit(\"]\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsZXgoIk11bHRpTGluZUNvbW1lbnRCb2R5VG9rZW4iKSxbbGV4KCJBc3RlcmlzayIpXSx7fSk00 = (IConstructor) _read("prod(lex(\"MultiLineCommentBodyToken\"),[lex(\"Asterisk\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgibXVsdGlwbGljYXRpb25FeHByZXNzaW9uIixzb3J0KCJFeHByZXNzaW9uIikpLFtsYWJlbCgibGV4cCIsc29ydCgiRXhwcmVzc2lvbiIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIqIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJyZXhwIixzb3J0KCJFeHByZXNzaW9uIikpXSx7YXNzb2MobGVmdCgpKX0p = (IConstructor) _read("prod(label(\"multiplicationExpression\",sort(\"Expression\")),[label(\"lexp\",sort(\"Expression\")),layouts(\"LAYOUTLIST\"),lit(\"*\"),layouts(\"LAYOUTLIST\"),label(\"rexp\",sort(\"Expression\"))],{assoc(left())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJTdGF0ZW1lbnRcIikpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4Myw4MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"\\\\iter-star(sort(\\\"Statement\\\"))\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(83,83)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(109,109)]),\\char-class([range(101,101)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImF1dG8iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"auto\"),[\\char-class([range(97,97)]),\\char-class([range(117,117)]),\\char-class([range(116,116)]),\\char-class([range(111,111)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImlmIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDIsMTAyKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"if\"),[\\char-class([range(105,105)]),\\char-class([range(102,102)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIi8iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ3LDQ3KV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"/\"),[\\char-class([range(47,47)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJHbG9iYWxEZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJHbG9iYWxEZWNsYXJhdGlvblwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiR2xvYmFsRGVjbGFyYXRpb24iKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"GlobalDeclaration\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"GlobalDeclaration\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"GlobalDeclaration\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlw11IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg2Miw2MildKV0se30p = (IConstructor) _read("prod(lit(\"\\>\"),[\\char-class([range(62,62)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXIiKSxbXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiQWJzdHJhY3REZWNsYXJhdG9yIildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"PrototypeParameter\"),[\\iter-star-seps(sort(\"Specifier\"),[layouts(\"LAYOUTLIST\")]),layouts(\"LAYOUTLIST\"),sort(\"AbstractDeclarator\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJTdHJ1Y3REZWNsYXJhdGlvblwiKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkyLDkyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDgzLDgzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjgsNjgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"\\\\iter-star(sort(\\\"StructDeclaration\\\"))\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(83,83)]),\\char-class([range(116,116)]),\\char-class([range(114,114)]),\\char-class([range(117,117)]),\\char-class([range(99,99)]),\\char-class([range(116,116)]),\\char-class([range(68,68)]),\\char-class([range(101,101)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIml0ZXIoc29ydChcIlNwZWNpZmllclwiKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDgzLDgzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAyLDEwMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"iter(sort(\\\"Specifier\\\"))\"),[\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(83,83)]),\\char-class([range(112,112)]),\\char-class([range(101,101)]),\\char-class([range(99,99)]),\\char-class([range(105,105)]),\\char-class([range(102,102)]),\\char-class([range(105,105)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiY29tbWFFeHByZXNzaW9uIixzb3J0KCJFeHByZXNzaW9uIikpLFtzb3J0KCJFeHByZXNzaW9uIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiLCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000 = (IConstructor) _read("prod(label(\"commaExpression\",sort(\"Expression\")),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\",\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihvcHQoXGNoYXItY2xhc3MoW3JhbmdlKDQzLDQzKSxyYW5nZSg0NSw0NSldKSkp = (IConstructor) _read("regular(opt(\\char-class([range(43,43),range(45,45)])))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIk11bHRpTGluZUNvbW1lbnRCb2R5VG9rZW4iKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiTXVsdGlMaW5lQ29tbWVudEJvZHlUb2tlblwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIobGV4KCJNdWx0aUxpbmVDb21tZW50Qm9keVRva2VuIikpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",lex(\"MultiLineCommentBodyToken\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"MultiLineCommentBodyToken\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(lex(\"MultiLineCommentBodyToken\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIm9wdChzb3J0KFwiTW9yZVBhcmFtZXRlcnNcIikpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg3Nyw3NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODAsODApXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA5LDEwOSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"opt(sort(\\\"MoreParameters\\\"))\"),[\\char-class([range(111,111)]),\\char-class([range(112,112)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(77,77)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(101,101)]),\\char-class([range(80,80)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(109,109)]),\\char-class([range(101,101)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(115,115)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImVudW0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNywxMTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"enum\"),[\\char-class([range(101,101)]),\\char-class([range(110,110)]),\\char-class([range(117,117)]),\\char-class([range(109,109)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlw8IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg2MCw2MCldKV0se30p = (IConstructor) _read("prod(lit(\"\\<\"),[\\char-class([range(60,60)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNpemVvZiIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTIyLDEyMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAyLDEwMildKV0se30p = (IConstructor) _read("prod(lit(\"sizeof\"),[\\char-class([range(115,115)]),\\char-class([range(105,105)]),\\char-class([range(122,122)]),\\char-class([range(101,101)]),\\char-class([range(111,111)]),\\char-class([range(102,102)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJJbml0aWFsaXplciIpLFtzb3J0KCJOb25Db21tYUV4cHJlc3Npb24iKV0se30p = (IConstructor) _read("prod(sort(\"Initializer\"),[sort(\"NonCommaExpression\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQYXJhbWV0ZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc2Vwcyhzb3J0KFwiUGFyYW1ldGVyXCIpLFtsaXQoXCIsXCIpXSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXNlcHMoc29ydCgiUGFyYW1ldGVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Parameter\")),[\\char-class([range(0,0)]),lit(\"\\\\iter-seps(sort(\\\"Parameter\\\"),[lit(\\\",\\\")])\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-seps(sort(\"Parameter\"),[layouts(\"LAYOUTLIST\"),lit(\",\"),layouts(\"LAYOUTLIST\")])))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIuIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxleCgiSWRlbnRpZmllciIpXSx7fSk00 = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\".\"),layouts(\"LAYOUTLIST\"),lex(\"Identifier\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zdGFyKFxcY2hhci1jbGFzcyhbcmFuZ2UoNzYsNzYpLHJhbmdlKDg1LDg1KSxyYW5nZSgxMDgsMTA4KSxyYW5nZSgxMTcsMTE3KV0pKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoOTIsOTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ1LDQ1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDkyLDkyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA0LDEwNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ1LDQ1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5MSw5MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1NSw1NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTQsNTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1NSw1NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTQsNTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Niw1NildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTMsNTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Niw1NildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTMsNTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0OSw0OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDU2LDU2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDksNDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDQ4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Niw1NildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAzLDEwMyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ5LDQ5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0OSw0OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTUsNTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0OSw0OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDksNDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDU1LDU1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTMsOTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"\\\\iter-star(\\\\char-class([range(76,76),range(85,85),range(108,108),range(117,117)]))\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(40,40)]),\\char-class([range(92,92)]),\\char-class([range(99,99)]),\\char-class([range(104,104)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(115,115)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(91,91)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(55,55)]),\\char-class([range(54,54)]),\\char-class([range(44,44)]),\\char-class([range(55,55)]),\\char-class([range(54,54)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(56,56)]),\\char-class([range(53,53)]),\\char-class([range(44,44)]),\\char-class([range(56,56)]),\\char-class([range(53,53)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(49,49)]),\\char-class([range(48,48)]),\\char-class([range(56,56)]),\\char-class([range(44,44)]),\\char-class([range(49,49)]),\\char-class([range(48,48)]),\\char-class([range(56,56)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(49,49)]),\\char-class([range(49,49)]),\\char-class([range(55,55)]),\\char-class([range(44,44)]),\\char-class([range(49,49)]),\\char-class([range(49,49)]),\\char-class([range(55,55)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsZXgoIkNoYXJhY3RlckNvbnN0YW50Q29udGVudCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMSwzOCkscmFuZ2UoNDAsOTEpLHJhbmdlKDkzLDE2Nzc3MjE1KV0pXSx7fSk00 = (IConstructor) _read("prod(lex(\"CharacterConstantContent\"),[\\char-class([range(1,38),range(40,91),range(93,16777215)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJHbG9iYWxEZWNsYXJhdGlvblwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg3MSw3MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTgsOTgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2OCw2OCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"sort(\\\"GlobalDeclaration\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(71,71)]),\\char-class([range(108,108)]),\\char-class([range(111,111)]),\\char-class([range(98,98)]),\\char-class([range(97,97)]),\\char-class([range(108,108)]),\\char-class([range(68,68)]),\\char-class([range(101,101)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\")\"),[\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImdvdG8iKV0se30p = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"goto\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJicmVhayIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKV0se30p = (IConstructor) _read("prod(sort(\"Statement\"),[lit(\"break\"),layouts(\"LAYOUTLIST\"),lit(\";\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIn0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEyNSwxMjUpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"}\"),[\\char-class([range(125,125)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiUHJvdG90eXBlUGFyYW1ldGVyXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXIiKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"PrototypeParameter\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"PrototypeParameter\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"PrototypeParameter\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIis9IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg0Myw0MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjEsNjEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"+=\"),[\\char-class([range(43,43)]),\\char-class([range(61,61)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJQcm90b3R5cGVQYXJhbWV0ZXJzXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDgwLDgwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjEsMTIxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4MCw4MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"sort(\\\"PrototypeParameters\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(80,80)]),\\char-class([range(114,114)]),\\char-class([range(111,111)]),\\char-class([range(116,116)]),\\char-class([range(111,111)]),\\char-class([range(116,116)]),\\char-class([range(121,121)]),\\char-class([range(112,112)]),\\char-class([range(101,101)]),\\char-class([range(80,80)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(109,109)]),\\char-class([range(101,101)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(115,115)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkV4cG9uZW50IikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkV4cG9uZW50XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihsZXgoIkV4cG9uZW50IikpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",lex(\"Exponent\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"Exponent\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(lex(\"Exponent\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIl49IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5NCw5NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjEsNjEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"^=\"),[\\char-class([range(94,94)]),\\char-class([range(61,61)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJEZWNsYXJhdGlvblwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2OCw2OCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"sort(\\\"Declaration\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(68,68)]),\\char-class([range(101,101)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJNdWx0aUxpbmVDb21tZW50Qm9keVRva2VuXCIpKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoOTIsOTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ1LDQ1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNzcsNzcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNywxMTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDc2LDc2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2Nyw2NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA5LDEwOSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA5LDEwOSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjYsNjYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMCwxMDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEyMSwxMjEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDg0LDg0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDcsMTA3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"\\\\iter-star(sort(\\\"MultiLineCommentBodyToken\\\"))\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(77,77)]),\\char-class([range(117,117)]),\\char-class([range(108,108)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(76,76)]),\\char-class([range(105,105)]),\\char-class([range(110,110)]),\\char-class([range(101,101)]),\\char-class([range(67,67)]),\\char-class([range(111,111)]),\\char-class([range(109,109)]),\\char-class([range(109,109)]),\\char-class([range(101,101)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(66,66)]),\\char-class([range(111,111)]),\\char-class([range(100,100)]),\\char-class([range(121,121)]),\\char-class([range(84,84)]),\\char-class([range(111,111)]),\\char-class([range(107,107)]),\\char-class([range(101,101)]),\\char-class([range(110,110)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgic2l6ZW9mIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiKCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJUeXBlTmFtZSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKV0se30p = (IConstructor) _read("prod(sort(\"Expression\"),[lit(\"sizeof\"),layouts(\"LAYOUTLIST\"),lit(\"(\"),layouts(\"LAYOUTLIST\"),sort(\"TypeName\"),layouts(\"LAYOUTLIST\"),lit(\")\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIrKyIpXSx7fSk00 = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"++\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzZXEoW1xjaGFyLWNsYXNzKFtyYW5nZSg2NSw5MCkscmFuZ2UoOTUsOTUpLHJhbmdlKDk3LDEyMildKSxjb25kaXRpb25hbChcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NykscmFuZ2UoNjUsOTApLHJhbmdlKDk1LDk1KSxyYW5nZSg5NywxMjIpXSkpLHtcbm90LWZvbGxvdyhcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpLHJhbmdlKDY1LDkwKSxyYW5nZSg5NSw5NSkscmFuZ2UoOTcsMTIyKV0pKX0pXSkpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic2VxKFtcXGNoYXItY2xhc3MoW3JhbmdlKDY1LDkwKSxyYW5nZSg5NSw5NSkscmFuZ2UoOTcsMTIyKV0pLGNvbmRpdGlvbmFsKFxcaXRlci1zdGFyKFxcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpLHJhbmdlKDY1LDkwKSxyYW5nZSg5NSw5NSkscmFuZ2UoOTcsMTIyKV0pKSx7XFxub3QtZm9sbG93KFxcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpLHJhbmdlKDY1LDkwKSxyYW5nZSg5NSw5NSkscmFuZ2UoOTcsMTIyKV0pKX0pXSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNlcShbXGNoYXItY2xhc3MoW3JhbmdlKDY1LDkwKSxyYW5nZSg5NSw5NSkscmFuZ2UoOTcsMTIyKV0pLGNvbmRpdGlvbmFsKFxpdGVyLXN0YXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KSxyYW5nZSg2NSw5MCkscmFuZ2UoOTUsOTUpLHJhbmdlKDk3LDEyMildKSkse1xub3QtZm9sbG93KFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NykscmFuZ2UoNjUsOTApLHJhbmdlKDk1LDk1KSxyYW5nZSg5NywxMjIpXSkpfSldKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",seq([\\char-class([range(65,90),range(95,95),range(97,122)]),conditional(\\iter-star(\\char-class([range(48,57),range(65,90),range(95,95),range(97,122)])),{\\not-follow(\\char-class([range(48,57),range(65,90),range(95,95),range(97,122)]))})])),[\\char-class([range(0,0)]),lit(\"seq([\\\\char-class([range(65,90),range(95,95),range(97,122)]),conditional(\\\\iter-star(\\\\char-class([range(48,57),range(65,90),range(95,95),range(97,122)])),{\\\\not-follow(\\\\char-class([range(48,57),range(65,90),range(95,95),range(97,122)]))})])\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(seq([\\char-class([range(65,90),range(95,95),range(97,122)]),conditional(\\iter-star(\\char-class([range(48,57),range(65,90),range(95,95),range(97,122)])),{\\not-follow(\\char-class([range(48,57),range(65,90),range(95,95),range(97,122)]))})])))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIml0ZXIoXFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NykscmFuZ2UoNjUsNzApLHJhbmdlKDk3LDEwMildKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNCwxMDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTEsOTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTIsNTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDU2LDU2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTMsNTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDU1LDU1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTQsNTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDUzLDUzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTUsNTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDQ4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTcsNTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDU1LDU1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDksNDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDQ4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1MCw1MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDkzLDkzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"iter(\\\\char-class([range(48,57),range(65,70),range(97,102)]))\"),[\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(40,40)]),\\char-class([range(92,92)]),\\char-class([range(99,99)]),\\char-class([range(104,104)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(115,115)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(91,91)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(52,52)]),\\char-class([range(56,56)]),\\char-class([range(44,44)]),\\char-class([range(53,53)]),\\char-class([range(55,55)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(54,54)]),\\char-class([range(53,53)]),\\char-class([range(44,44)]),\\char-class([range(55,55)]),\\char-class([range(48,48)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(57,57)]),\\char-class([range(55,55)]),\\char-class([range(44,44)]),\\char-class([range(49,49)]),\\char-class([range(48,48)]),\\char-class([range(50,50)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcblx0ICAgICAgICB8ID0iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7YXNzb2MocmlnaHQoKSl9KQ0000 = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"\\n\\t        | =\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{assoc(right())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInVuc2lnbmVkIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDAsMTAwKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"unsigned\"),[\\char-class([range(117,117)]),\\char-class([range(110,110)]),\\char-class([range(115,115)]),\\char-class([range(105,105)]),\\char-class([range(103,103)]),\\char-class([range(110,110)]),\\char-class([range(101,101)]),\\char-class([range(100,100)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImRvIildLHt9KQ0000 = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"do\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJDb21tZW50XCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY3LDY3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"sort(\\\"Comment\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(67,67)]),\\char-class([range(111,111)]),\\char-class([range(109,109)]),\\char-class([range(109,109)]),\\char-class([range(101,101)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdHJ1Y3REZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJTdHJ1Y3REZWNsYXJhdGlvblwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJTdHJ1Y3REZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"StructDeclaration\")),[\\char-class([range(0,0)]),lit(\"\\\\iter-star(sort(\\\"StructDeclaration\\\"))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-star-seps(sort(\"StructDeclaration\"),[layouts(\"LAYOUTLIST\")])))})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihpdGVyKGxleCgiQ2hhcmFjdGVyQ29uc3RhbnRDb250ZW50IikpKQ0000 = (IConstructor) _read("regular(iter(lex(\"CharacterConstantContent\")))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgic3RvcmFnZUNsYXNzIixzb3J0KCJTcGVjaWZpZXIiKSksW3NvcnQoIlN0b3JhZ2VDbGFzcyIpXSx7fSk00 = (IConstructor) _read("prod(label(\"storageClass\",sort(\"Specifier\")),[sort(\"StorageClass\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIigiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"(\"),[\\char-class([range(40,40)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgicG9pbnRlckRlY2xhcmF0b3IiLHNvcnQoIkRlY2xhcmF0b3IiKSksW2xpdCgiKiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgicXVhbGlmaWVycyIsXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlR5cGVRdWFsaWZpZXIiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgiZGVjbCIsc29ydCgiRGVjbGFyYXRvciIpKV0se30p = (IConstructor) _read("prod(label(\"pointerDeclarator\",sort(\"Declarator\")),[lit(\"*\"),layouts(\"LAYOUTLIST\"),label(\"qualifiers\",\\iter-star-seps(sort(\"TypeQualifier\"),[layouts(\"LAYOUTLIST\")])),layouts(\"LAYOUTLIST\"),label(\"decl\",sort(\"Declarator\"))],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJJbml0RGVjbGFyYXRvciIpLFtsYWJlbCgiZGVjbCIsc29ydCgiRGVjbGFyYXRvciIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI9IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkluaXRpYWxpemVyIildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"InitDeclarator\"),[label(\"decl\",sort(\"Declarator\")),layouts(\"LAYOUTLIST\"),lit(\"=\"),layouts(\"LAYOUTLIST\"),sort(\"Initializer\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiZnVuY3Rpb25EZWNsYXJhdG9yIixzb3J0KCJQcm90b3R5cGVEZWNsYXJhdG9yIikpLFtsYWJlbCgicHJvdG9fZGVjbCIsc29ydCgiUHJvdG90eXBlRGVjbGFyYXRvciIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJwYXJhbXMiLG9wdChzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXJzIikpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIpIildLHt9KQ0000 = (IConstructor) _read("prod(label(\"functionDeclarator\",sort(\"PrototypeDeclarator\")),[label(\"proto_decl\",sort(\"PrototypeDeclarator\")),layouts(\"LAYOUTLIST\"),lit(\"(\"),layouts(\"LAYOUTLIST\"),label(\"params\",opt(sort(\"PrototypeParameters\"))),layouts(\"LAYOUTLIST\"),lit(\")\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJJbml0aWFsaXplciIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zZXBzKHNvcnQoXCJJbml0aWFsaXplclwiKSxbbGl0KFwiLFwiKV0pIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zZXBzKHNvcnQoIkluaXRpYWxpemVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Initializer\")),[\\char-class([range(0,0)]),lit(\"\\\\iter-seps(sort(\\\"Initializer\\\"),[lit(\\\",\\\")])\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-seps(sort(\"Initializer\"),[layouts(\"LAYOUTLIST\"),lit(\",\"),layouts(\"LAYOUTLIST\")])))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImJyZWFrIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5OCw5OCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNywxMDcpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"break\"),[\\char-class([range(98,98)]),\\char-class([range(114,114)]),\\char-class([range(101,101)]),\\char-class([range(97,97)]),\\char-class([range(107,107)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIiU9IiksW1xjaGFyLWNsYXNzKFtyYW5nZSgzNywzNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjEsNjEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"%=\"),[\\char-class([range(37,37)]),\\char-class([range(61,61)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgidHlwZVF1YWxpZmllciIsc29ydCgiU3BlY2lmaWVyIikpLFtzb3J0KCJUeXBlUXVhbGlmaWVyIildLHt9KQ0000 = (IConstructor) _read("prod(label(\"typeQualifier\",sort(\"Specifier\")),[sort(\"TypeQualifier\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ8IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se30p = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"|\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiY29tbWVudCIsbGV4KCJMQVlPVVQiKSksW2xleCgiQ29tbWVudCIpXSx7dGFnKCJjYXRlZ29yeSIoIkNvbW1lbnQiKSl9KQ0000 = (IConstructor) _read("prod(label(\"comment\",lex(\"LAYOUT\")),[lex(\"Comment\")],{tag(\"category\"(\"Comment\"))})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zZXBzKHNvcnQoIkluaXREZWNsYXJhdG9yIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSk00 = (IConstructor) _read("regular(\\iter-seps(sort(\"InitDeclarator\"),[layouts(\"LAYOUTLIST\"),lit(\",\"),layouts(\"LAYOUTLIST\")]))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkNvbW1lbnQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiQ29tbWVudFwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIobGV4KCJDb21tZW50IikpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",lex(\"Comment\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"Comment\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(lex(\"Comment\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsZXgoIkZsb2F0aW5nUG9pbnRDb25zdGFudCIpLFtpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksbGV4KCJFeHBvbmVudCIpLG9wdChcY2hhci1jbGFzcyhbcmFuZ2UoNzAsNzApLHJhbmdlKDc2LDc2KSxyYW5nZSgxMDIsMTAyKSxyYW5nZSgxMDgsMTA4KV0pKV0se30p = (IConstructor) _read("prod(lex(\"FloatingPointConstant\"),[iter(\\char-class([range(48,57)])),lex(\"Exponent\"),opt(\\char-class([range(70,70),range(76,76),range(102,102),range(108,108)]))],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIm9wdChsaXQoXCIsXCIpKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEyLDExMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"opt(lit(\\\",\\\"))\"),[\\char-class([range(111,111)]),\\char-class([range(112,112)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(108,108)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(44,44)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImNvbnRpbnVlIildLHt9KQ0000 = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"continue\")],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihvcHQoXGNoYXItY2xhc3MoW3JhbmdlKDc2LDc2KV0pKSk00 = (IConstructor) _read("regular(opt(\\char-class([range(76,76)])))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImRvdWJsZSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTAwLDEwMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE3LDExNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTgsOTgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"double\"),[\\char-class([range(100,100)]),\\char-class([range(111,111)]),\\char-class([range(117,117)]),\\char-class([range(98,98)]),\\char-class([range(108,108)]),\\char-class([range(101,101)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiaWRlbnRpZmllciIsc29ydCgiQWJzdHJhY3REZWNsYXJhdG9yIikpLFtzb3J0KCJBbm9ueW1vdXNJZGVudGlmaWVyIildLHt9KQ0000 = (IConstructor) _read("prod(label(\"identifier\",sort(\"AbstractDeclarator\")),[sort(\"AnonymousIdentifier\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFeHRlcm5hbERlY2xhcmF0aW9uIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiaXRlcihzb3J0KFwiRXh0ZXJuYWxEZWNsYXJhdGlvblwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXNlcHMoc29ydCgiRXh0ZXJuYWxEZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"ExternalDeclaration\")),[\\char-class([range(0,0)]),lit(\"iter(sort(\\\"ExternalDeclaration\\\"))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-seps(sort(\"ExternalDeclaration\"),[layouts(\"LAYOUTLIST\")])))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJEZWNsYXJhdGlvblwiKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkyLDkyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY4LDY4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"\\\\iter-star(sort(\\\"Declaration\\\"))\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(68,68)]),\\char-class([range(101,101)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zZXBzKHNvcnQoIkluaXRpYWxpemVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSk00 = (IConstructor) _read("regular(\\iter-seps(sort(\"Initializer\"),[layouts(\"LAYOUTLIST\"),lit(\",\"),layouts(\"LAYOUTLIST\")]))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIvPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"/=\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{assoc(right())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJQcm90b3R5cGVQYXJhbWV0ZXJcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODAsODApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEyMSwxMjEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDgwLDgwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"sort(\\\"PrototypeParameter\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(80,80)]),\\char-class([range(114,114)]),\\char-class([range(111,111)]),\\char-class([range(116,116)]),\\char-class([range(111,111)]),\\char-class([range(116,116)]),\\char-class([range(121,121)]),\\char-class([range(112,112)]),\\char-class([range(101,101)]),\\char-class([range(80,80)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(109,109)]),\\char-class([range(101,101)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIi0tIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"--\"),[\\char-class([range(45,45)]),\\char-class([range(45,45)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImZsb2F0IiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMDIsMTAyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKV0se30p = (IConstructor) _read("prod(lit(\"float\"),[\\char-class([range(102,102)]),\\char-class([range(108,108)]),\\char-class([range(111,111)]),\\char-class([range(97,97)]),\\char-class([range(116,116)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zdGFyKFxcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpLHJhbmdlKDY1LDkwKSxyYW5nZSg5NSw5NSkscmFuZ2UoOTcsMTIyKV0pKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoOTIsOTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ1LDQ1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDkyLDkyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA0LDEwNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ1LDQ1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5MSw5MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Miw1MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTYsNTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Myw1MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTUsNTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1NCw1NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTMsNTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Nyw1NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Nyw1NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTMsNTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Nyw1NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTMsNTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Nyw1NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTUsNTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0OSw0OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTAsNTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDUwLDUwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTMsOTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"\\\\iter-star(\\\\char-class([range(48,57),range(65,90),range(95,95),range(97,122)]))\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(40,40)]),\\char-class([range(92,92)]),\\char-class([range(99,99)]),\\char-class([range(104,104)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(115,115)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(91,91)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(52,52)]),\\char-class([range(56,56)]),\\char-class([range(44,44)]),\\char-class([range(53,53)]),\\char-class([range(55,55)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(54,54)]),\\char-class([range(53,53)]),\\char-class([range(44,44)]),\\char-class([range(57,57)]),\\char-class([range(48,48)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(57,57)]),\\char-class([range(53,53)]),\\char-class([range(44,44)]),\\char-class([range(57,57)]),\\char-class([range(53,53)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(57,57)]),\\char-class([range(55,55)]),\\char-class([range(44,44)]),\\char-class([range(49,49)]),\\char-class([range(50,50)]),\\char-class([range(50,50)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI22IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI6IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKHJpZ2h0KCkpfSk00 = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"?\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\":\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{assoc(right())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xleCgiQ2hhcmFjdGVyQ29uc3RhbnQiKV0se3RhZygiY2F0ZWdvcnkiKCJDb25zdGFudCIpKX0p = (IConstructor) _read("prod(sort(\"Expression\"),[lex(\"CharacterConstant\")],{tag(\"category\"(\"Constant\"))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInZvbGF0aWxlIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTgsMTE4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKV0se30p = (IConstructor) _read("prod(lit(\"volatile\"),[\\char-class([range(118,118)]),\\char-class([range(111,111)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(108,108)]),\\char-class([range(101,101)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIk11bHRpTGluZUNvbW1lbnRCb2R5VG9rZW4iKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc3Rhcihzb3J0KFwiTXVsdGlMaW5lQ29tbWVudEJvZHlUb2tlblwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXN0YXIobGV4KCJNdWx0aUxpbmVDb21tZW50Qm9keVRva2VuIikpKSl9KQ0000 = (IConstructor) _read("prod(label(\"$MetaHole\",lex(\"MultiLineCommentBodyToken\")),[\\char-class([range(0,0)]),lit(\"\\\\iter-star(sort(\\\"MultiLineCommentBodyToken\\\"))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-star(lex(\"MultiLineCommentBodyToken\"))))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiYnJhY2tldCIsc29ydCgiRXhwcmVzc2lvbiIpKSxbbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIpIildLHticmFja2V0KCl9KQ0000 = (IConstructor) _read("prod(label(\"bracket\",sort(\"Expression\")),[lit(\"(\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\")\")],{bracket()})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJJbml0aWFsaXplciIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJJbml0aWFsaXplclwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiSW5pdGlhbGl6ZXIiKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Initializer\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"Initializer\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"Initializer\")))})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RhdGVtZW50IiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pKQ0000 = (IConstructor) _read("regular(\\iter-star-seps(sort(\"Statement\"),[layouts(\"LAYOUTLIST\")]))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJUcmFuc2xhdGlvblVuaXQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiVHJhbnNsYXRpb25Vbml0XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJUcmFuc2xhdGlvblVuaXQiKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"TranslationUnit\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"TranslationUnit\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"TranslationUnit\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImZvciIpXSx7fSk00 = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"for\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImxvbmciKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"long\"),[\\char-class([range(108,108)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(103,103)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgic2l6ZU9mRXhwcmVzc2lvbiIsc29ydCgiRXhwcmVzc2lvbiIpKSxbbGl0KCJzaXplb2YiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGFiZWwoImV4cCIsc29ydCgiRXhwcmVzc2lvbiIpKV0se30p = (IConstructor) _read("prod(label(\"sizeOfExpression\",sort(\"Expression\")),[lit(\"sizeof\"),layouts(\"LAYOUTLIST\"),label(\"exp\",sort(\"Expression\"))],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkNoYXJhY3RlckNvbnN0YW50Q29udGVudCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJDaGFyYWN0ZXJDb25zdGFudENvbnRlbnRcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGxleCgiQ2hhcmFjdGVyQ29uc3RhbnRDb250ZW50IikpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",lex(\"CharacterConstantContent\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"CharacterConstantContent\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(lex(\"CharacterConstantContent\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsZXgoIlN0cmluZ0NvbnN0YW50Q29udGVudCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMSwzMykscmFuZ2UoMzUsOTEpLHJhbmdlKDkzLDE2Nzc3MjE1KV0pXSx7fSk00 = (IConstructor) _read("prod(lex(\"StringConstantContent\"),[\\char-class([range(1,33),range(35,91),range(93,16777215)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsZXgoIkNvbW1lbnQiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ3LDQ3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0Miw0MildKSxcaXRlci1zdGFyKGxleCgiTXVsdGlMaW5lQ29tbWVudEJvZHlUb2tlbiIpKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDIsNDIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ3LDQ3KV0pXSx7fSk00 = (IConstructor) _read("prod(lex(\"Comment\"),[\\char-class([range(47,47)]),\\char-class([range(42,42)]),\\iter-star(lex(\"MultiLineCommentBodyToken\")),\\char-class([range(42,42)]),\\char-class([range(47,47)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImJyZWFrIildLHt9KQ0000 = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"break\")],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihvcHQoc29ydCgiRGVjbGFyYXRvciIpKSk00 = (IConstructor) _read("regular(opt(sort(\"Declarator\")))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImRvIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMDAsMTAwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"do\"),[\\char-class([range(100,100)]),\\char-class([range(111,111)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJUeXBlUXVhbGlmaWVyIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlR5cGVRdWFsaWZpZXJcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlR5cGVRdWFsaWZpZXIiKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"TypeQualifier\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"TypeQualifier\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"TypeQualifier\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJDaGFyYWN0ZXJDb25zdGFudENvbnRlbnRcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjcsNjcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNCwxMDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY3LDY3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjcsNjcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"sort(\\\"CharacterConstantContent\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(67,67)]),\\char-class([range(104,104)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(99,99)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(67,67)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(67,67)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJTdG9yYWdlQ2xhc3MiKSxbbGl0KCJzdGF0aWMiKV0se30p = (IConstructor) _read("prod(sort(\"StorageClass\"),[lit(\"static\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCI7IildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"Statement\"),[lit(\";\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJJbml0RGVjbGFyYXRvciIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJJbml0RGVjbGFyYXRvclwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiSW5pdERlY2xhcmF0b3IiKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"InitDeclarator\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"InitDeclarator\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"InitDeclarator\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIj8iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDYzLDYzKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"?\"),[\\char-class([range(63,63)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIm9wdChzb3J0KFwiRGVjbGFyYXRvclwiKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY4LDY4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"opt(sort(\\\"Declarator\\\"))\"),[\\char-class([range(111,111)]),\\char-class([range(112,112)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(68,68)]),\\char-class([range(101,101)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIi89IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg0Nyw0NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjEsNjEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"/=\"),[\\char-class([range(47,47)]),\\char-class([range(61,61)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIklkZW50aWZpZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiSWRlbnRpZmllclwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIobGV4KCJJZGVudGlmaWVyIikpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",lex(\"Identifier\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"Identifier\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(lex(\"Identifier\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJjb250aW51ZSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKV0se30p = (IConstructor) _read("prod(sort(\"Statement\"),[lit(\"continue\"),layouts(\"LAYOUTLIST\"),lit(\";\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJBbm9ueW1vdXNJZGVudGlmaWVyIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkFub255bW91c0lkZW50aWZpZXJcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIkFub255bW91c0lkZW50aWZpZXIiKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"AnonymousIdentifier\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"AnonymousIdentifier\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"AnonymousIdentifier\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiaW50Iixzb3J0KCJUeXBlU3BlY2lmaWVyIikpLFtsaXQoImludCIpXSx7fSk00 = (IConstructor) _read("prod(label(\"int\",sort(\"TypeSpecifier\")),[lit(\"int\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiaWRlbnRpZmllciIsc29ydCgiRGVjbGFyYXRvciIpKSxbbGV4KCJJZGVudGlmaWVyIildLHt9KQ0000 = (IConstructor) _read("prod(label(\"identifier\",sort(\"Declarator\")),[lex(\"Identifier\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiYnJhY2tldCIsc29ydCgiUHJvdG90eXBlRGVjbGFyYXRvciIpKSxbbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJhYnNfZGVjbCIsc29ydCgiQWJzdHJhY3REZWNsYXJhdG9yIikpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKV0se2JyYWNrZXQoKX0p = (IConstructor) _read("prod(label(\"bracket\",sort(\"PrototypeDeclarator\")),[lit(\"(\"),layouts(\"LAYOUTLIST\"),label(\"abs_decl\",sort(\"AbstractDeclarator\")),layouts(\"LAYOUTLIST\"),lit(\")\")],{bracket()})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiZGVmYXVsdEZ1bmN0aW9uUHJvdG90eXBlIixzb3J0KCJGdW5jdGlvblByb3RvdHlwZSIpKSxbbGFiZWwoInNwZWNzIixcaXRlci1zdGFyLXNlcHMoc29ydCgiU3BlY2lmaWVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGFiZWwoImRlY2wiLHNvcnQoIlByb3RvdHlwZURlY2xhcmF0b3IiKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOyIpXSx7fSk00 = (IConstructor) _read("prod(label(\"defaultFunctionPrototype\",sort(\"FunctionPrototype\")),[label(\"specs\",\\iter-star-seps(sort(\"Specifier\"),[layouts(\"LAYOUTLIST\")])),layouts(\"LAYOUTLIST\"),label(\"decl\",sort(\"PrototypeDeclarator\")),layouts(\"LAYOUTLIST\"),lit(\";\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixcY2hhci1jbGFzcyhbcmFuZ2UoMSw5KSxyYW5nZSgxMSwxNjc3NzIxNSldKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc3RhcihcXGNoYXItY2xhc3MoW3JhbmdlKDEsOSkscmFuZ2UoMTEsMTY3NzcyMTUpXSkpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSgxLDkpLHJhbmdlKDExLDE2Nzc3MjE1KV0pKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",\\char-class([range(1,9),range(11,16777215)])),[\\char-class([range(0,0)]),lit(\"\\\\iter-star(\\\\char-class([range(1,9),range(11,16777215)]))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-star(\\char-class([range(1,9),range(11,16777215)]))))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsZXgoIkNoYXJhY3RlckNvbnN0YW50Q29udGVudCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoOTIsOTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEsMTY3NzcyMTUpXSldLHt9KQ0000 = (IConstructor) _read("prod(lex(\"CharacterConstantContent\"),[\\char-class([range(92,92)]),\\char-class([range(1,16777215)])],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NykscmFuZ2UoNjUsOTApLHJhbmdlKDk1LDk1KSxyYW5nZSg5NywxMjIpXSkpKQ0000 = (IConstructor) _read("regular(\\iter-star(\\char-class([range(48,57),range(65,90),range(95,95),range(97,122)])))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFbnVtZXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiXFxpdGVyLXNlcHMoc29ydChcIkVudW1lcmF0b3JcIiksW2xpdChcIixcIildKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc2Vwcyhzb3J0KCJFbnVtZXJhdG9yIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Enumerator\")),[\\char-class([range(0,0)]),lit(\"\\\\iter-seps(sort(\\\"Enumerator\\\"),[lit(\\\",\\\")])\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-seps(sort(\"Enumerator\"),[layouts(\"LAYOUTLIST\"),lit(\",\"),layouts(\"LAYOUTLIST\")])))})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zZXBzKHNvcnQoIkVudW1lcmF0b3IiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiLCIpLGxheW91dHMoIkxBWU9VVExJU1QiKV0pKQ0000 = (IConstructor) _read("regular(\\iter-seps(sort(\"Enumerator\"),[layouts(\"LAYOUTLIST\"),lit(\",\"),layouts(\"LAYOUTLIST\")]))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIm9wdChcXGNoYXItY2xhc3MoW3JhbmdlKDc2LDc2KV0pKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEyLDExMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDkyLDkyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA0LDEwNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ1LDQ1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5MSw5MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1NSw1NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTQsNTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1NSw1NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTQsNTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Myw5MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"opt(\\\\char-class([range(76,76)]))\"),[\\char-class([range(111,111)]),\\char-class([range(112,112)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(92,92)]),\\char-class([range(99,99)]),\\char-class([range(104,104)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(115,115)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(91,91)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(55,55)]),\\char-class([range(54,54)]),\\char-class([range(44,44)]),\\char-class([range(55,55)]),\\char-class([range(54,54)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHRlcm5hbERlY2xhcmF0aW9uIiksW3NvcnQoIkZ1bmN0aW9uUHJvdG90eXBlIildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"ExternalDeclaration\"),[sort(\"FunctionPrototype\")],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihvcHQoXGNoYXItY2xhc3MoW3JhbmdlKDcwLDcwKSxyYW5nZSg3Niw3NikscmFuZ2UoMTAyLDEwMikscmFuZ2UoMTA4LDEwOCldKSkp = (IConstructor) _read("regular(opt(\\char-class([range(70,70),range(76,76),range(102,102),range(108,108)])))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIl4iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDk0LDk0KV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"^\"),[\\char-class([range(94,94)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFeHByZXNzaW9uIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgib3B0KHNvcnQoXCJFeHByZXNzaW9uXCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIob3B0KHNvcnQoIkV4cHJlc3Npb24iKSkpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Expression\")),[\\char-class([range(0,0)]),lit(\"opt(sort(\\\"Expression\\\"))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(opt(sort(\"Expression\"))))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJeIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se30p = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"^\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkV4cG9uZW50IikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgib3B0KHNvcnQoXCJFeHBvbmVudFwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKG9wdChsZXgoIkV4cG9uZW50IikpKSl9KQ0000 = (IConstructor) _read("prod(label(\"$MetaHole\",lex(\"Exponent\")),[\\char-class([range(0,0)]),lit(\"opt(sort(\\\"Exponent\\\"))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(opt(lex(\"Exponent\"))))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIi1cPiIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDYyLDYyKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"-\\>\"),[\\char-class([range(45,45)]),\\char-class([range(62,62)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIiwiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\",\"),[\\char-class([range(44,44)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJNb3JlUGFyYW1ldGVyc1wiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg3Nyw3NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODAsODApXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA5LDEwOSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"sort(\\\"MoreParameters\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(77,77)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(101,101)]),\\char-class([range(80,80)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(109,109)]),\\char-class([range(101,101)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(115,115)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJTdG9yYWdlQ2xhc3MiKSxbbGl0KCJyZWdpc3RlciIpXSx7fSk00 = (IConstructor) _read("prod(sort(\"StorageClass\"),[lit(\"register\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJBYnN0cmFjdERlY2xhcmF0b3JcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjUsNjUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk4LDk4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY4LDY4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"sort(\\\"AbstractDeclarator\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(65,65)]),\\char-class([range(98,98)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(99,99)]),\\char-class([range(116,116)]),\\char-class([range(68,68)]),\\char-class([range(101,101)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCImPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"&=\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{assoc(right())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJFeHByZXNzaW9uXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY5LDY5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjAsMTIwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"sort(\\\"Expression\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(69,69)]),\\char-class([range(120,120)]),\\char-class([range(112,112)]),\\char-class([range(114,114)]),\\char-class([range(101,101)]),\\char-class([range(115,115)]),\\char-class([range(115,115)]),\\char-class([range(105,105)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zZXBzKHNvcnQoXCJJbml0aWFsaXplclwiKSxbbGl0KFwiLFwiKV0pIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDczLDczKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTIyLDEyMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTEsOTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTMsOTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"\\\\iter-seps(sort(\\\"Initializer\\\"),[lit(\\\",\\\")])\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(101,101)]),\\char-class([range(112,112)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(73,73)]),\\char-class([range(110,110)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(97,97)]),\\char-class([range(108,108)]),\\char-class([range(105,105)]),\\char-class([range(122,122)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(91,91)]),\\char-class([range(108,108)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(44,44)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJbIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJdIildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"[\"),layouts(\"LAYOUTLIST\"),sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"]\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImdvdG8iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"goto\"),[\\char-class([range(103,103)]),\\char-class([range(111,111)]),\\char-class([range(116,116)]),\\char-class([range(111,111)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlw11XD49IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg2Miw2MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjIsNjIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDYxLDYxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"\\>\\>=\"),[\\char-class([range(62,62)]),\\char-class([range(62,62)]),\\char-class([range(61,61)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJUeXBlUXVhbGlmaWVyIiksW2xpdCgiY29uc3QiKV0se30p = (IConstructor) _read("prod(sort(\"TypeQualifier\"),[lit(\"const\")],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zdGFyKGxleCgiTXVsdGlMaW5lQ29tbWVudEJvZHlUb2tlbiIpKSk00 = (IConstructor) _read("regular(\\iter-star(lex(\"MultiLineCommentBodyToken\")))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJBbm9ueW1vdXNJZGVudGlmaWVyIiksW10se30p = (IConstructor) _read("prod(sort(\"AnonymousIdentifier\"),[],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgidW5pb24iLHNvcnQoIlR5cGVTcGVjaWZpZXIiKSksW2xpdCgidW5pb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGV4KCJJZGVudGlmaWVyIildLHt9KQ0000 = (IConstructor) _read("prod(label(\"union\",sort(\"TypeSpecifier\")),[lit(\"union\"),layouts(\"LAYOUTLIST\"),lex(\"Identifier\")],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zZXBzKHNvcnQoIlN0cnVjdERlY2xhcmF0b3IiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiLCIpLGxheW91dHMoIkxBWU9VVExJU1QiKV0pKQ0000 = (IConstructor) _read("regular(\\iter-seps(sort(\"StructDeclarator\"),[layouts(\"LAYOUTLIST\"),lit(\",\"),layouts(\"LAYOUTLIST\")]))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zZXBzKHNvcnQoXCJJbml0RGVjbGFyYXRvclwiKSxbbGl0KFwiLFwiKV0pIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDczLDczKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2OCw2OCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTEsOTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTMsOTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"\\\\iter-seps(sort(\\\"InitDeclarator\\\"),[lit(\\\",\\\")])\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(101,101)]),\\char-class([range(112,112)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(73,73)]),\\char-class([range(110,110)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(68,68)]),\\char-class([range(101,101)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(91,91)]),\\char-class([range(108,108)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(44,44)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2NvbmRpdGlvbmFsKGxpdCgiLS0iKSx7XG5vdC1wcmVjZWRlKFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSl9KSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7fSk00 = (IConstructor) _read("prod(sort(\"Expression\"),[conditional(lit(\"--\"),{\\not-precede(\\char-class([range(45,45)]))}),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdHJ1Y3REZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJTdHJ1Y3REZWNsYXJhdGlvblwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiU3RydWN0RGVjbGFyYXRpb24iKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"StructDeclaration\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"StructDeclaration\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"StructDeclaration\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIisiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQzLDQzKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"+\"),[\\char-class([range(43,43)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCItLSIpXSx7fSk00 = (IConstructor) _read("prod(sort(\"Expression\"),[sort(\"Expression\"),layouts(\"LAYOUTLIST\"),lit(\"--\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIiE9IiksW1xjaGFyLWNsYXNzKFtyYW5nZSgzMywzMyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjEsNjEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"!=\"),[\\char-class([range(33,33)]),\\char-class([range(61,61)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIlN0cmluZ0NvbnN0YW50Q29udGVudCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJTdHJpbmdDb25zdGFudENvbnRlbnRcIikpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zdGFyKGxleCgiU3RyaW5nQ29uc3RhbnRDb250ZW50IikpKSl9KQ0000 = (IConstructor) _read("prod(label(\"$MetaHole\",lex(\"StringConstantContent\")),[\\char-class([range(0,0)]),lit(\"\\\\iter-star(sort(\\\"StringConstantContent\\\"))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-star(lex(\"StringConstantContent\"))))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJNb3JlUGFyYW1ldGVycyIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIm9wdChzb3J0KFwiTW9yZVBhcmFtZXRlcnNcIikpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihvcHQoc29ydCgiTW9yZVBhcmFtZXRlcnMiKSkpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"MoreParameters\")),[\\char-class([range(0,0)]),lit(\"opt(sort(\\\"MoreParameters\\\"))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(opt(sort(\"MoreParameters\"))))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixcY2hhci1jbGFzcyhbcmFuZ2UoNzYsNzYpXSkpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgib3B0KFxcY2hhci1jbGFzcyhbcmFuZ2UoNzYsNzYpXSkpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihvcHQoXGNoYXItY2xhc3MoW3JhbmdlKDc2LDc2KV0pKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",\\char-class([range(76,76)])),[\\char-class([range(0,0)]),lit(\"opt(\\\\char-class([range(76,76)]))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(opt(\\char-class([range(76,76)]))))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgic3RydWN0RGVjbCIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGl0KCJzdHJ1Y3QiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGV4KCJJZGVudGlmaWVyIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgieyIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RydWN0RGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgifSIpXSx7fSk00 = (IConstructor) _read("prod(label(\"structDecl\",sort(\"TypeSpecifier\")),[lit(\"struct\"),layouts(\"LAYOUTLIST\"),lex(\"Identifier\"),layouts(\"LAYOUTLIST\"),lit(\"{\"),layouts(\"LAYOUTLIST\"),\\iter-star-seps(sort(\"StructDeclaration\"),[layouts(\"LAYOUTLIST\")]),layouts(\"LAYOUTLIST\"),lit(\"}\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxuXHQgICAgICAgIHwgPSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTAsMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDksOSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzIsMzIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDMyLDMyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzMiwzMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzIsMzIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDMyLDMyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzMiwzMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzIsMzIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDMyLDMyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjQsMTI0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzMiwzMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjEsNjEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"\\n\\t        | =\"),[\\char-class([range(10,10)]),\\char-class([range(9,9)]),\\char-class([range(32,32)]),\\char-class([range(32,32)]),\\char-class([range(32,32)]),\\char-class([range(32,32)]),\\char-class([range(32,32)]),\\char-class([range(32,32)]),\\char-class([range(32,32)]),\\char-class([range(32,32)]),\\char-class([range(124,124)]),\\char-class([range(32,32)]),\\char-class([range(61,61)])],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zZXBzKHNvcnQoIlByb3RvdHlwZVBhcmFtZXRlciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIsIiksbGF5b3V0cygiTEFZT1VUTElTVCIpXSkp = (IConstructor) _read("regular(\\iter-seps(sort(\"PrototypeParameter\"),[layouts(\"LAYOUTLIST\"),lit(\",\"),layouts(\"LAYOUTLIST\")]))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixcY2hhci1jbGFzcyhbcmFuZ2UoNzAsNzApLHJhbmdlKDc2LDc2KSxyYW5nZSgxMDIsMTAyKSxyYW5nZSgxMDgsMTA4KV0pKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIm9wdChcXGNoYXItY2xhc3MoW3JhbmdlKDcwLDcwKSxyYW5nZSg3Niw3NikscmFuZ2UoMTAyLDEwMikscmFuZ2UoMTA4LDEwOCldKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKG9wdChcY2hhci1jbGFzcyhbcmFuZ2UoNzAsNzApLHJhbmdlKDc2LDc2KSxyYW5nZSgxMDIsMTAyKSxyYW5nZSgxMDgsMTA4KV0pKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",\\char-class([range(70,70),range(76,76),range(102,102),range(108,108)])),[\\char-class([range(0,0)]),lit(\"opt(\\\\char-class([range(70,70),range(76,76),range(102,102),range(108,108)]))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(opt(\\char-class([range(70,70),range(76,76),range(102,102),range(108,108)]))))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2NvbmRpdGlvbmFsKGxpdCgiKysiKSx7XG5vdC1wcmVjZWRlKFxjaGFyLWNsYXNzKFtyYW5nZSg0Myw0MyldKSl9KSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7fSk00 = (IConstructor) _read("prod(sort(\"Expression\"),[conditional(lit(\"++\"),{\\not-precede(\\char-class([range(43,43)]))}),layouts(\"LAYOUTLIST\"),sort(\"Expression\")],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zdGFyKGxleCgiU3RyaW5nQ29uc3RhbnRDb250ZW50IikpKQ0000 = (IConstructor) _read("regular(\\iter-star(lex(\"StringConstantContent\")))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiYXJyYXlEZWNsYXJhdG9yIixzb3J0KCJEZWNsYXJhdG9yIikpLFtsYWJlbCgiZGVjbCIsc29ydCgiRGVjbGFyYXRvciIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJbIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJleHAiLG9wdChzb3J0KCJFeHByZXNzaW9uIikpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJdIildLHt9KQ0000 = (IConstructor) _read("prod(label(\"arrayDeclarator\",sort(\"Declarator\")),[label(\"decl\",sort(\"Declarator\")),layouts(\"LAYOUTLIST\"),lit(\"[\"),layouts(\"LAYOUTLIST\"),label(\"exp\",opt(sort(\"Expression\"))),layouts(\"LAYOUTLIST\"),lit(\"]\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIl0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkzLDkzKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"]\"),[\\char-class([range(93,93)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInJldHVybiIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE3LDExNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKV0se30p = (IConstructor) _read("prod(lit(\"return\"),[\\char-class([range(114,114)]),\\char-class([range(101,101)]),\\char-class([range(116,116)]),\\char-class([range(117,117)]),\\char-class([range(114,114)]),\\char-class([range(110,110)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJEZWNsYXJhdG9yXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY4LDY4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"sort(\\\"Declarator\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(68,68)]),\\char-class([range(101,101)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInNob3J0IildLHt9KQ0000 = (IConstructor) _read("prod(keywords(\"Keyword\"),[lit(\"short\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIml0ZXIoc29ydChcIkV4dGVybmFsRGVjbGFyYXRpb25cIikpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2OSw2OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTIwLDEyMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY4LDY4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"iter(sort(\\\"ExternalDeclaration\\\"))\"),[\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(69,69)]),\\char-class([range(120,120)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(110,110)]),\\char-class([range(97,97)]),\\char-class([range(108,108)]),\\char-class([range(68,68)]),\\char-class([range(101,101)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
    
  // Item declarations
	
	
  protected static class Expression {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI9IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKHJpZ2h0KCkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(411, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(413, 3, "layouts_LAYOUTLIST", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(412, 2, cHJvZChsaXQoIj0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDYxLDYxKV0pXSx7fSk00, new int[] {61}, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(414, 4, "Expression", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(410, 0, "Expression", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI9IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKHJpZ2h0KCkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPj0iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7YXNzb2MobGVmdCgpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(333, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(335, 3, "layouts_LAYOUTLIST", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(334, 2, cHJvZChsaXQoIlw11PSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoNjIsNjIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDYxLDYxKV0pXSx7fSk00, new int[] {62,61}, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(336, 4, "Expression", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(332, 0, "Expression", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPj0iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7YXNzb2MobGVmdCgpKX0p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCItXD4iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGV4KCJJZGVudGlmaWVyIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new NonTerminalStackNode<IConstructor>(169, 3, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(167, 1, "layouts_LAYOUTLIST", null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(170, 4, "Identifier", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(168, 2, cHJvZChsaXQoIi1cPiIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDYyLDYyKV0pXSx7fSk00, new int[] {45,62}, null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(166, 0, "Expression", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCItXD4iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGV4KCJJZGVudGlmaWVyIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIqPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new NonTerminalStackNode<IConstructor>(431, 3, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(429, 1, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(428, 0, "Expression", null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(432, 4, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(430, 2, cHJvZChsaXQoIio9IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg0Miw0MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjEsNjEpXSldLHt9KQ0000, new int[] {42,61}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIqPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJePSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new NonTerminalStackNode<IConstructor>(444, 4, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(442, 2, cHJvZChsaXQoIl49IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5NCw5NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjEsNjEpXSldLHt9KQ0000, new int[] {94,61}, null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(440, 0, "Expression", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(443, 3, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(441, 1, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJePSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIuIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxleCgiSWRlbnRpZmllciIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new NonTerminalStackNode<IConstructor>(193, 4, "Identifier", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(191, 2, cHJvZChsaXQoIi4iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ2LDQ2KV0pXSx7fSk00, new int[] {46}, null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(189, 0, "Expression", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(192, 3, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(190, 1, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIuIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxleCgiSWRlbnRpZmllciIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ8IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(381, 0, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(383, 2, cHJvZChsaXQoInwiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEyNCwxMjQpXSldLHt9KQ0000, new int[] {124}, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(385, 4, "Expression", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(382, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(384, 3, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ8IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2NvbmRpdGlvbmFsKGxpdCgiKysiKSx7XG5vdC1wcmVjZWRlKFxjaGFyLWNsYXNzKFtyYW5nZSg0Myw0MyldKSl9KSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[0] = new LiteralStackNode<IConstructor>(251, 0, cHJvZChsaXQoIisrIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg0Myw0MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDMsNDMpXSldLHt9KQ0000, new int[] {43,43}, new IEnterFilter[] {new CharPrecedeRestriction(new int[][]{{43,43}})}, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(253, 2, "Expression", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(252, 1, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2NvbmRpdGlvbmFsKGxpdCgiKysiKSx7XG5vdC1wcmVjZWRlKFxjaGFyLWNsYXNzKFtyYW5nZSg0Myw0MyldKSl9KSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgifiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(234, 1, "layouts_LAYOUTLIST", null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(235, 2, "Expression", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(233, 0, cHJvZChsaXQoIn4iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEyNiwxMjYpXSldLHt9KQ0000, new int[] {126}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgifiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xleCgiRmxvYXRpbmdQb2ludENvbnN0YW50IildLHt0YWcoImNhdGVnb3J5IigiQ29uc3RhbnQiKSl9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(164, 0, "FloatingPointConstant", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xleCgiRmxvYXRpbmdQb2ludENvbnN0YW50IildLHt0YWcoImNhdGVnb3J5IigiQ29uc3RhbnQiKSl9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI9PSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhsZWZ0KCkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(358, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(360, 3, "layouts_LAYOUTLIST", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(359, 2, cHJvZChsaXQoIj09IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg2MSw2MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjEsNjEpXSldLHt9KQ0000, new int[] {61,61}, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(361, 4, "Expression", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(357, 0, "Expression", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI9PSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhsZWZ0KCkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xleCgiSW50ZWdlckNvbnN0YW50IildLHt0YWcoImNhdGVnb3J5IigiQ29uc3RhbnQiKSl9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(207, 0, "IntegerConstant", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xleCgiSW50ZWdlckNvbnN0YW50IildLHt0YWcoImNhdGVnb3J5IigiQ29uc3RhbnQiKSl9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xleCgiU3RyaW5nQ29uc3RhbnQiKV0se3RhZygiY2F0ZWdvcnkiKCJDb25zdGFudCIpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(209, 0, "StringConstant", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xleCgiU3RyaW5nQ29uc3RhbnQiKV0se3RhZygiY2F0ZWdvcnkiKCJDb25zdGFudCIpKX0p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ8fCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new NonTerminalStackNode<IConstructor>(396, 3, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(394, 1, "layouts_LAYOUTLIST", null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(397, 4, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(395, 2, cHJvZChsaXQoInx8IiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMjQsMTI0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjQsMTI0KV0pXSx7fSk00, new int[] {124,124}, null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(393, 0, "Expression", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ8fCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPD0iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7YXNzb2MobGVmdCgpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new NonTerminalStackNode<IConstructor>(341, 3, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(339, 1, "layouts_LAYOUTLIST", null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(342, 4, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(340, 2, cHJvZChsaXQoIlw8PSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoNjAsNjApXSksXGNoYXItY2xhc3MoW3JhbmdlKDYxLDYxKV0pXSx7fSk00, new int[] {60,61}, null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(338, 0, "Expression", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPD0iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7YXNzb2MobGVmdCgpKX0p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPFw8IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKGxlZnQoKSl9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new NonTerminalStackNode<IConstructor>(322, 3, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(320, 1, "layouts_LAYOUTLIST", null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(323, 4, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(321, 2, cHJvZChsaXQoIlw8XDwiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDYwLDYwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2MCw2MCldKV0se30p, new int[] {60,60}, null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(319, 0, "Expression", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPFw8IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKGxlZnQoKSl9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFeHByZXNzaW9uIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkV4cHJlc3Npb25cIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIkV4cHJlc3Npb24iKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new LiteralStackNode<IConstructor>(155, 1, cHJvZChsaXQoInNvcnQoXCJFeHByZXNzaW9uXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY5LDY5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjAsMTIwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000, new int[] {115,111,114,116,40,34,69,120,112,114,101,115,115,105,111,110,34,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(158, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(157, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[0] = new CharStackNode<IConstructor>(154, 0, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(156, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(159, 4, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFeHByZXNzaW9uIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkV4cHJlc3Npb25cIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIkV4cHJlc3Npb24iKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPlw11PSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(417, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(419, 3, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(416, 0, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(418, 2, cHJvZChsaXQoIlw11XD49IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg2Miw2MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjIsNjIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDYxLDYxKV0pXSx7fSk00, new int[] {62,62,61}, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(420, 4, "Expression", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPlw11PSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiLSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(256, 1, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(255, 0, cHJvZChsaXQoIi0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ1LDQ1KV0pXSx7fSk00, new int[] {45}, null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(257, 2, "Expression", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiLSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiKyIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(260, 1, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(259, 0, cHJvZChsaXQoIisiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQzLDQzKV0pXSx7fSk00, new int[] {43}, null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(261, 2, "Expression", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiKyIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiKiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(264, 1, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(263, 0, cHJvZChsaXQoIioiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQyLDQyKV0pXSx7fSk00, new int[] {42}, null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(265, 2, "Expression", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiKiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIrPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(423, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(425, 3, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(422, 0, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(424, 2, cHJvZChsaXQoIis9IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg0Myw0MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjEsNjEpXSldLHt9KQ0000, new int[] {43,61}, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(426, 4, "Expression", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIrPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiKCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJUeXBlTmFtZSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[7];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(268, 1, "layouts_LAYOUTLIST", null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(272, 5, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(270, 3, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(267, 0, cHJvZChsaXQoIigiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pXSx7fSk00, new int[] {40}, null, null);
      tmp[6] = new NonTerminalStackNode<IConstructor>(273, 6, "Expression", null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(269, 2, "TypeName", null, null);
      tmp[4] = new LiteralStackNode<IConstructor>(271, 4, cHJvZChsaXQoIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {41}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiKCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJUeXBlTmFtZSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiISIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(276, 1, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(275, 0, cHJvZChsaXQoIiEiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDMzLDMzKV0pXSx7fSk00, new int[] {33}, null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(277, 2, "Expression", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiISIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiJiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(280, 1, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(279, 0, cHJvZChsaXQoIiYiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDM4LDM4KV0pXSx7fSk00, new int[] {38}, null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(281, 2, "Expression", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiJiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCImJiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new NonTerminalStackNode<IConstructor>(390, 3, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(388, 1, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(387, 0, "Expression", null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(391, 4, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(389, 2, cHJvZChsaXQoIiYmIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgzOCwzOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzgsMzgpXSldLHt9KQ0000, new int[] {38,38}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCImJiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPlw11IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKGxlZnQoKSl9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new NonTerminalStackNode<IConstructor>(328, 3, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(326, 1, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(325, 0, "Expression", null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(329, 4, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(327, 2, cHJvZChsaXQoIlw11XD4iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDYyLDYyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2Miw2MildKV0se30p, new int[] {62,62}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPlw11IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKGxlZnQoKSl9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgidmFyaWFibGUiLHNvcnQoIkV4cHJlc3Npb24iKSksW2xleCgiSWRlbnRpZmllciIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(173, 0, "Identifier", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgidmFyaWFibGUiLHNvcnQoIkV4cHJlc3Npb24iKSksW2xleCgiSWRlbnRpZmllciIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIlPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[2] = new LiteralStackNode<IConstructor>(466, 2, cHJvZChsaXQoIiU9IiksW1xjaGFyLWNsYXNzKFtyYW5nZSgzNywzNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjEsNjEpXSldLHt9KQ0000, new int[] {37,61}, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(468, 4, "Expression", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(464, 0, "Expression", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(465, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(467, 3, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIlPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPFw8PSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[2] = new LiteralStackNode<IConstructor>(472, 2, cHJvZChsaXQoIlw8XDw9IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg2MCw2MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjAsNjApXSksXGNoYXItY2xhc3MoW3JhbmdlKDYxLDYxKV0pXSx7fSk00, new int[] {60,60,61}, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(474, 4, "Expression", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(470, 0, "Expression", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(471, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(473, 3, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPFw8PSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xleCgiSGV4YWRlY2ltYWxDb25zdGFudCIpXSx7dGFnKCJjYXRlZ29yeSIoIkNvbnN0YW50IikpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(175, 0, "HexadecimalConstant", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xleCgiSGV4YWRlY2ltYWxDb25zdGFudCIpXSx7dGFnKCJjYXRlZ29yeSIoIkNvbnN0YW50IikpfSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCItPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[2] = new LiteralStackNode<IConstructor>(436, 2, cHJvZChsaXQoIi09IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjEsNjEpXSldLHt9KQ0000, new int[] {45,61}, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(438, 4, "Expression", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(434, 0, "Expression", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(435, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(437, 3, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCItPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIhPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhsZWZ0KCkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[2] = new LiteralStackNode<IConstructor>(365, 2, cHJvZChsaXQoIiE9IiksW1xjaGFyLWNsYXNzKFtyYW5nZSgzMywzMyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjEsNjEpXSldLHt9KQ0000, new int[] {33,61}, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(367, 4, "Expression", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(363, 0, "Expression", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(364, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(366, 3, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIhPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhsZWZ0KCkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhsZWZ0KCkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[2] = new LiteralStackNode<IConstructor>(346, 2, cHJvZChsaXQoIlw11IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg2Miw2MildKV0se30p, new int[] {62}, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(348, 4, "Expression", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(344, 0, "Expression", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(345, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(347, 3, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhsZWZ0KCkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhsZWZ0KCkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[2] = new LiteralStackNode<IConstructor>(352, 2, cHJvZChsaXQoIlw8IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg2MCw2MCldKV0se30p, new int[] {60}, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(354, 4, "Expression", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(350, 0, "Expression", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(351, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(353, 3, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhsZWZ0KCkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCImIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[2] = new LiteralStackNode<IConstructor>(371, 2, cHJvZChsaXQoIiYiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDM4LDM4KV0pXSx7fSk00, new int[] {38}, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(373, 4, "Expression", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(369, 0, "Expression", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(370, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(372, 3, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCImIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIlIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKGxlZnQoKSl9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[2] = new LiteralStackNode<IConstructor>(286, 2, cHJvZChsaXQoIiUiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDM3LDM3KV0pXSx7fSk00, new int[] {37}, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(288, 4, "Expression", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(284, 0, "Expression", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(285, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(287, 3, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIlIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKGxlZnQoKSl9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJOb25Db21tYUV4cHJlc3Npb24iKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiLCIpLGxheW91dHMoIkxBWU9VVExJU1QiKV0pLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[7];
      
      tmp[2] = new LiteralStackNode<IConstructor>(179, 2, cHJvZChsaXQoIigiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pXSx7fSk00, new int[] {40}, null, null);
      tmp[6] = new LiteralStackNode<IConstructor>(187, 6, cHJvZChsaXQoIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {41}, null, null);
      tmp[4] = new SeparatedListStackNode<IConstructor>(185, 4, cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiTm9uQ29tbWFFeHByZXNzaW9uIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSk00, new NonTerminalStackNode<IConstructor>(181, 0, "NonCommaExpression", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(182, 1, "layouts_LAYOUTLIST", null, null), new LiteralStackNode<IConstructor>(183, 2, cHJvZChsaXQoIiwiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pXSx7fSk00, new int[] {44}, null, null), new NonTerminalStackNode<IConstructor>(184, 3, "layouts_LAYOUTLIST", null, null)}, false, null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(177, 0, "Expression", null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(186, 5, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(178, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(180, 3, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJOb25Db21tYUV4cHJlc3Npb24iKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiLCIpLGxheW91dHMoIkxBWU9VVExJU1QiKV0pLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIrIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKGxlZnQoKSl9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[2] = new LiteralStackNode<IConstructor>(308, 2, cHJvZChsaXQoIisiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQzLDQzKV0pXSx7fSk00, new int[] {43}, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(310, 4, "Expression", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(306, 0, "Expression", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(307, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(309, 3, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIrIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKGxlZnQoKSl9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIvIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKGxlZnQoKSl9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[2] = new LiteralStackNode<IConstructor>(292, 2, cHJvZChsaXQoIi8iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ3LDQ3KV0pXSx7fSk00, new int[] {47}, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(294, 4, "Expression", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(290, 0, "Expression", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(291, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(293, 3, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIvIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKGxlZnQoKSl9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCItIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKGxlZnQoKSl9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[2] = new LiteralStackNode<IConstructor>(314, 2, cHJvZChsaXQoIi0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ1LDQ1KV0pXSx7fSk00, new int[] {45}, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(316, 4, "Expression", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(312, 0, "Expression", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(313, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(315, 3, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCItIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKGxlZnQoKSl9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgibXVsdGlwbGljYXRpb25FeHByZXNzaW9uIixzb3J0KCJFeHByZXNzaW9uIikpLFtsYWJlbCgibGV4cCIsc29ydCgiRXhwcmVzc2lvbiIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIqIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJyZXhwIixzb3J0KCJFeHByZXNzaW9uIikpXSx7YXNzb2MobGVmdCgpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new NonTerminalStackNode<IConstructor>(302, 4, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(300, 2, cHJvZChsaXQoIioiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQyLDQyKV0pXSx7fSk00, new int[] {42}, null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(297, 0, "Expression", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(301, 3, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(299, 1, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgibXVsdGlwbGljYXRpb25FeHByZXNzaW9uIixzb3J0KCJFeHByZXNzaW9uIikpLFtsYWJlbCgibGV4cCIsc29ydCgiRXhwcmVzc2lvbiIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIqIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJyZXhwIixzb3J0KCJFeHByZXNzaW9uIikpXSx7YXNzb2MobGVmdCgpKX0p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiY29tbWFFeHByZXNzaW9uIixzb3J0KCJFeHByZXNzaW9uIikpLFtzb3J0KCJFeHByZXNzaW9uIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiLCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new NonTerminalStackNode<IConstructor>(481, 4, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(479, 2, cHJvZChsaXQoIiwiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pXSx7fSk00, new int[] {44}, null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(477, 0, "Expression", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(480, 3, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(478, 1, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiY29tbWFFeHByZXNzaW9uIixzb3J0KCJFeHByZXNzaW9uIikpLFtzb3J0KCJFeHByZXNzaW9uIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiLCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgic2l6ZW9mIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiKCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJUeXBlTmFtZSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[7];
      
      tmp[0] = new LiteralStackNode<IConstructor>(211, 0, cHJvZChsaXQoInNpemVvZiIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTIyLDEyMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAyLDEwMildKV0se30p, new int[] {115,105,122,101,111,102}, null, null);
      tmp[6] = new LiteralStackNode<IConstructor>(217, 6, cHJvZChsaXQoIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {41}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(213, 2, cHJvZChsaXQoIigiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pXSx7fSk00, new int[] {40}, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(215, 4, "TypeName", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(212, 1, "layouts_LAYOUTLIST", null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(216, 5, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(214, 3, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgic2l6ZW9mIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiKCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJUeXBlTmFtZSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcblx0ICAgICAgICB8ID0iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7YXNzb2MocmlnaHQoKSl9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(446, 0, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(448, 2, cHJvZChsaXQoIlxuXHQgICAgICAgIHwgPSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTAsMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDksOSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzIsMzIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDMyLDMyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzMiwzMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzIsMzIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDMyLDMyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzMiwzMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzIsMzIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDMyLDMyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjQsMTI0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzMiwzMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjEsNjEpXSldLHt9KQ0000, new int[] {10,9,32,32,32,32,32,32,32,32,124,32,61}, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(450, 4, "Expression", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(447, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(449, 3, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcblx0ICAgICAgICB8ID0iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7YXNzb2MocmlnaHQoKSl9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIrKyIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(219, 0, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(221, 2, cHJvZChsaXQoIisrIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg0Myw0MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDMsNDMpXSldLHt9KQ0000, new int[] {43,43}, null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(220, 1, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIrKyIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIvPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(452, 0, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(454, 2, cHJvZChsaXQoIi89IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg0Nyw0NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjEsNjEpXSldLHt9KQ0000, new int[] {47,61}, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(456, 4, "Expression", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(453, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(455, 3, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIvPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiYnJhY2tldCIsc29ydCgiRXhwcmVzc2lvbiIpKSxbbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIpIildLHticmFja2V0KCl9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new LiteralStackNode<IConstructor>(224, 0, cHJvZChsaXQoIigiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pXSx7fSk00, new int[] {40}, null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(226, 2, "Expression", null, null);
      tmp[4] = new LiteralStackNode<IConstructor>(228, 4, cHJvZChsaXQoIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {41}, null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(225, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(227, 3, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiYnJhY2tldCIsc29ydCgiRXhwcmVzc2lvbiIpKSxbbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIpIildLHticmFja2V0KCl9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI22IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI6IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKHJpZ2h0KCkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[9];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(399, 0, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(401, 2, cHJvZChsaXQoIj8iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDYzLDYzKV0pXSx7fSk00, new int[] {63}, null, null);
      tmp[6] = new LiteralStackNode<IConstructor>(405, 6, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(403, 4, "Expression", null, null);
      tmp[8] = new NonTerminalStackNode<IConstructor>(407, 8, "Expression", null, null);
      tmp[7] = new NonTerminalStackNode<IConstructor>(406, 7, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(400, 1, "layouts_LAYOUTLIST", null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(404, 5, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(402, 3, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI22IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI6IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKHJpZ2h0KCkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xleCgiQ2hhcmFjdGVyQ29uc3RhbnQiKV0se3RhZygiY2F0ZWdvcnkiKCJDb25zdGFudCIpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(230, 0, "CharacterConstant", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xleCgiQ2hhcmFjdGVyQ29uc3RhbnQiKV0se3RhZygiY2F0ZWdvcnkiKCJDb25zdGFudCIpKX0p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgic2l6ZU9mRXhwcmVzc2lvbiIsc29ydCgiRXhwcmVzc2lvbiIpKSxbbGl0KCJzaXplb2YiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGFiZWwoImV4cCIsc29ydCgiRXhwcmVzc2lvbiIpKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[0] = new LiteralStackNode<IConstructor>(238, 0, cHJvZChsaXQoInNpemVvZiIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTIyLDEyMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAyLDEwMildKV0se30p, new int[] {115,105,122,101,111,102}, null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(240, 2, "Expression", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(239, 1, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgic2l6ZU9mRXhwcmVzc2lvbiIsc29ydCgiRXhwcmVzc2lvbiIpKSxbbGl0KCJzaXplb2YiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGFiZWwoImV4cCIsc29ydCgiRXhwcmVzc2lvbiIpKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCImPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(458, 0, "Expression", null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(462, 4, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(460, 2, cHJvZChsaXQoIiY9IiksW1xjaGFyLWNsYXNzKFtyYW5nZSgzOCwzOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjEsNjEpXSldLHt9KQ0000, new int[] {38,61}, null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(461, 3, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(459, 1, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCImPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFeHByZXNzaW9uIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgib3B0KHNvcnQoXCJFeHByZXNzaW9uXCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIob3B0KHNvcnQoIkV4cHJlc3Npb24iKSkpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new CharStackNode<IConstructor>(484, 0, new int[][]{{0,0}}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(489, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(486, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(488, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(487, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(485, 1, cHJvZChsaXQoIm9wdChzb3J0KFwiRXhwcmVzc2lvblwiKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY5LDY5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjAsMTIwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {111,112,116,40,115,111,114,116,40,34,69,120,112,114,101,115,115,105,111,110,34,41,41}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFeHByZXNzaW9uIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgib3B0KHNvcnQoXCJFeHByZXNzaW9uXCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIob3B0KHNvcnQoIkV4cHJlc3Npb24iKSkpKX0p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJeIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(375, 0, "Expression", null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(379, 4, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(377, 2, cHJvZChsaXQoIl4iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDk0LDk0KV0pXSx7fSk00, new int[] {94}, null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(378, 3, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(376, 1, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJeIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJbIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJdIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[7];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(195, 0, "Expression", null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(199, 4, "Expression", null, null);
      tmp[6] = new LiteralStackNode<IConstructor>(201, 6, cHJvZChsaXQoIl0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkzLDkzKV0pXSx7fSk00, new int[] {93}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(197, 2, cHJvZChsaXQoIlsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkxLDkxKV0pXSx7fSk00, new int[] {91}, null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(198, 3, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(196, 1, "layouts_LAYOUTLIST", null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(200, 5, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJbIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJdIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2NvbmRpdGlvbmFsKGxpdCgiLS0iKSx7XG5vdC1wcmVjZWRlKFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSl9KSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[0] = new LiteralStackNode<IConstructor>(245, 0, cHJvZChsaXQoIi0tIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSldLHt9KQ0000, new int[] {45,45}, new IEnterFilter[] {new CharPrecedeRestriction(new int[][]{{45,45}})}, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(247, 2, "Expression", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(246, 1, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2NvbmRpdGlvbmFsKGxpdCgiLS0iKSx7XG5vdC1wcmVjZWRlKFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSl9KSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCItLSIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(203, 0, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(205, 2, cHJvZChsaXQoIi0tIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSldLHt9KQ0000, new int[] {45,45}, null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(204, 1, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCItLSIpXSx7fSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI9IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKHJpZ2h0KCkpfSk00(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPj0iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7YXNzb2MobGVmdCgpKX0p(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCItXD4iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGV4KCJJZGVudGlmaWVyIildLHt9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIqPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJePSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIuIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxleCgiSWRlbnRpZmllciIpXSx7fSk00(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ8IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se30p(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2NvbmRpdGlvbmFsKGxpdCgiKysiKSx7XG5vdC1wcmVjZWRlKFxjaGFyLWNsYXNzKFtyYW5nZSg0Myw0MyldKSl9KSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7fSk00(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgifiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xleCgiRmxvYXRpbmdQb2ludENvbnN0YW50IildLHt0YWcoImNhdGVnb3J5IigiQ29uc3RhbnQiKSl9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI9PSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhsZWZ0KCkpfSk00(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xleCgiSW50ZWdlckNvbnN0YW50IildLHt0YWcoImNhdGVnb3J5IigiQ29uc3RhbnQiKSl9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xleCgiU3RyaW5nQ29uc3RhbnQiKV0se3RhZygiY2F0ZWdvcnkiKCJDb25zdGFudCIpKX0p(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ8fCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPD0iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7YXNzb2MobGVmdCgpKX0p(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPFw8IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKGxlZnQoKSl9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFeHByZXNzaW9uIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkV4cHJlc3Npb25cIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIkV4cHJlc3Npb24iKSkpfSk00(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPlw11PSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiLSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiKyIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiKiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIrPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiKCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJUeXBlTmFtZSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7fSk00(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiISIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiJiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCImJiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPlw11IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKGxlZnQoKSl9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgidmFyaWFibGUiLHNvcnQoIkV4cHJlc3Npb24iKSksW2xleCgiSWRlbnRpZmllciIpXSx7fSk00(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIlPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPFw8PSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xleCgiSGV4YWRlY2ltYWxDb25zdGFudCIpXSx7dGFnKCJjYXRlZ29yeSIoIkNvbnN0YW50IikpfSk00(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCItPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIhPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhsZWZ0KCkpfSk00(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhsZWZ0KCkpfSk00(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcPCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhsZWZ0KCkpfSk00(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCImIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se30p(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIlIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKGxlZnQoKSl9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJOb25Db21tYUV4cHJlc3Npb24iKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiLCIpLGxheW91dHMoIkxBWU9VVExJU1QiKV0pLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKV0se30p(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIrIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKGxlZnQoKSl9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIvIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKGxlZnQoKSl9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCItIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKGxlZnQoKSl9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgibXVsdGlwbGljYXRpb25FeHByZXNzaW9uIixzb3J0KCJFeHByZXNzaW9uIikpLFtsYWJlbCgibGV4cCIsc29ydCgiRXhwcmVzc2lvbiIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIqIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJyZXhwIixzb3J0KCJFeHByZXNzaW9uIikpXSx7YXNzb2MobGVmdCgpKX0p(builder);
      
        _init_cHJvZChsYWJlbCgiY29tbWFFeHByZXNzaW9uIixzb3J0KCJFeHByZXNzaW9uIikpLFtzb3J0KCJFeHByZXNzaW9uIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiLCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHt9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgic2l6ZW9mIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiKCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJUeXBlTmFtZSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKV0se30p(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJcblx0ICAgICAgICB8ID0iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7YXNzb2MocmlnaHQoKSl9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIrKyIpXSx7fSk00(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIvPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p(builder);
      
        _init_cHJvZChsYWJlbCgiYnJhY2tldCIsc29ydCgiRXhwcmVzc2lvbiIpKSxbbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIpIildLHticmFja2V0KCl9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI22IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI6IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se2Fzc29jKHJpZ2h0KCkpfSk00(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xleCgiQ2hhcmFjdGVyQ29uc3RhbnQiKV0se3RhZygiY2F0ZWdvcnkiKCJDb25zdGFudCIpKX0p(builder);
      
        _init_cHJvZChsYWJlbCgic2l6ZU9mRXhwcmVzc2lvbiIsc29ydCgiRXhwcmVzc2lvbiIpKSxbbGl0KCJzaXplb2YiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGFiZWwoImV4cCIsc29ydCgiRXhwcmVzc2lvbiIpKV0se30p(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCImPSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJFeHByZXNzaW9uIildLHthc3NvYyhyaWdodCgpKX0p(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFeHByZXNzaW9uIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgib3B0KHNvcnQoXCJFeHByZXNzaW9uXCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIob3B0KHNvcnQoIkV4cHJlc3Npb24iKSkpKX0p(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJeIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKV0se30p(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJbIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJdIildLHt9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2NvbmRpdGlvbmFsKGxpdCgiLS0iKSx7XG5vdC1wcmVjZWRlKFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSl9KSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7fSk00(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW3NvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCItLSIpXSx7fSk00(builder);
      
    }
  }
	
  protected static class layouts_$default$ {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYXlvdXRzKCIkZGVmYXVsdCQiKSxbXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new EpsilonStackNode<IConstructor>(520, 0);
      builder.addAlternative(CParser.cHJvZChsYXlvdXRzKCIkZGVmYXVsdCQiKSxbXSx7fSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYXlvdXRzKCIkZGVmYXVsdCQiKSxbXSx7fSk00(builder);
      
    }
  }
	
  protected static class Asterisk {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsZXgoIkFzdGVyaXNrIiksW2NvbmRpdGlvbmFsKFxjaGFyLWNsYXNzKFtyYW5nZSg0Miw0MildKSx7XG5vdC1mb2xsb3coXGNoYXItY2xhc3MoW3JhbmdlKDQ3LDQ3KV0pKX0pXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new CharStackNode<IConstructor>(636, 0, new int[][]{{42,42}}, null, new ICompletionFilter[] {new CharFollowRestriction(new int[][]{{47,47}})});
      builder.addAlternative(CParser.cHJvZChsZXgoIkFzdGVyaXNrIiksW2NvbmRpdGlvbmFsKFxjaGFyLWNsYXNzKFtyYW5nZSg0Miw0MildKSx7XG5vdC1mb2xsb3coXGNoYXItY2xhc3MoW3JhbmdlKDQ3LDQ3KV0pKX0pXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkFzdGVyaXNrIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkFzdGVyaXNrXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihsZXgoIkFzdGVyaXNrIikpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new CharStackNode<IConstructor>(644, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(641, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(639, 0, new int[][]{{0,0}}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(643, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(642, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(640, 1, cHJvZChsaXQoInNvcnQoXCJBc3Rlcmlza1wiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2NSw2NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA3LDEwNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {115,111,114,116,40,34,65,115,116,101,114,105,115,107,34,41}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkFzdGVyaXNrIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkFzdGVyaXNrXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihsZXgoIkFzdGVyaXNrIikpKX0p, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsZXgoIkFzdGVyaXNrIiksW2NvbmRpdGlvbmFsKFxjaGFyLWNsYXNzKFtyYW5nZSg0Miw0MildKSx7XG5vdC1mb2xsb3coXGNoYXItY2xhc3MoW3JhbmdlKDQ3LDQ3KV0pKX0pXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkFzdGVyaXNrIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkFzdGVyaXNrXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihsZXgoIkFzdGVyaXNrIikpKX0p(builder);
      
    }
  }
	
  protected static class Declaration {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJEZWNsYXJhdGlvblwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJEZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new ListStackNode<IConstructor>(654, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(653, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(651, 1, cHJvZChsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJEZWNsYXJhdGlvblwiKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkyLDkyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY4LDY4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {92,105,116,101,114,45,115,116,97,114,40,115,111,114,116,40,34,68,101,99,108,97,114,97,116,105,111,110,34,41,41}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(655, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(652, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(650, 0, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJEZWNsYXJhdGlvblwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJEZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiZGVjbGFyYXRpb25XaXRob3V0SW5pdERlY2xzIixzb3J0KCJEZWNsYXJhdGlvbiIpKSxbbGFiZWwoInNwZWNzIixcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOyIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(665, 1, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new SeparatedListStackNode<IConstructor>(663, 0, cmVndWxhcihcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSk00, new NonTerminalStackNode<IConstructor>(661, 0, "Specifier", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(662, 1, "layouts_LAYOUTLIST", null, null)}, true, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(666, 2, cHJvZChsaXQoIjsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU5LDU5KV0pXSx7fSk00, new int[] {59}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiZGVjbGFyYXRpb25XaXRob3V0SW5pdERlY2xzIixzb3J0KCJEZWNsYXJhdGlvbiIpKSxbbGFiZWwoInNwZWNzIixcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOyIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJEZWNsYXJhdGlvblwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiRGVjbGFyYXRpb24iKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new LiteralStackNode<IConstructor>(670, 1, cHJvZChsaXQoInNvcnQoXCJEZWNsYXJhdGlvblwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2OCw2OCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {115,111,114,116,40,34,68,101,99,108,97,114,97,116,105,111,110,34,41}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(669, 0, new int[][]{{0,0}}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(674, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(671, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(673, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(672, 0, new int[][]{{48,57}}, null, null), true, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJEZWNsYXJhdGlvblwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiRGVjbGFyYXRpb24iKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiZGVjbGFyYXRpb25XaXRoSW5pdERlY2xzIixzb3J0KCJEZWNsYXJhdGlvbiIpKSxbbGFiZWwoInNwZWNzIixcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJpbml0RGVjbGFyYXRvcnMiLFxpdGVyLXNlcHMoc29ydCgiSW5pdERlY2xhcmF0b3IiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiLCIpLGxheW91dHMoIkxBWU9VVExJU1QiKV0pKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI7IildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[2] = new SeparatedListStackNode<IConstructor>(687, 2, cmVndWxhcihcaXRlci1zZXBzKHNvcnQoIkluaXREZWNsYXJhdG9yIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSk00, new NonTerminalStackNode<IConstructor>(683, 0, "InitDeclarator", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(684, 1, "layouts_LAYOUTLIST", null, null), new LiteralStackNode<IConstructor>(685, 2, cHJvZChsaXQoIiwiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pXSx7fSk00, new int[] {44}, null, null), new NonTerminalStackNode<IConstructor>(686, 3, "layouts_LAYOUTLIST", null, null)}, true, null, null);
      tmp[4] = new LiteralStackNode<IConstructor>(690, 4, cHJvZChsaXQoIjsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU5LDU5KV0pXSx7fSk00, new int[] {59}, null, null);
      tmp[0] = new SeparatedListStackNode<IConstructor>(680, 0, cmVndWxhcihcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSk00, new NonTerminalStackNode<IConstructor>(678, 0, "Specifier", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(679, 1, "layouts_LAYOUTLIST", null, null)}, true, null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(682, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(689, 3, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiZGVjbGFyYXRpb25XaXRoSW5pdERlY2xzIixzb3J0KCJEZWNsYXJhdGlvbiIpKSxbbGFiZWwoInNwZWNzIixcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJpbml0RGVjbGFyYXRvcnMiLFxpdGVyLXNlcHMoc29ydCgiSW5pdERlY2xhcmF0b3IiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiLCIpLGxheW91dHMoIkxBWU9VVExJU1QiKV0pKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI7IildLHt9KQ0000, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJEZWNsYXJhdGlvblwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJEZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(builder);
      
        _init_cHJvZChsYWJlbCgiZGVjbGFyYXRpb25XaXRob3V0SW5pdERlY2xzIixzb3J0KCJEZWNsYXJhdGlvbiIpKSxbbGFiZWwoInNwZWNzIixcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOyIpXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJEZWNsYXJhdGlvblwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiRGVjbGFyYXRpb24iKSkpfSk00(builder);
      
        _init_cHJvZChsYWJlbCgiZGVjbGFyYXRpb25XaXRoSW5pdERlY2xzIixzb3J0KCJEZWNsYXJhdGlvbiIpKSxbbGFiZWwoInNwZWNzIixcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJpbml0RGVjbGFyYXRvcnMiLFxpdGVyLXNlcHMoc29ydCgiSW5pdERlY2xhcmF0b3IiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiLCIpLGxheW91dHMoIkxBWU9VVExJU1QiKV0pKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI7IildLHt9KQ0000(builder);
      
    }
  }
	
  protected static class StorageClass {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgidHlwZURlZiIsc29ydCgiU3RvcmFnZUNsYXNzIikpLFtsaXQoInR5cGVkZWYiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(808, 0, cHJvZChsaXQoInR5cGVkZWYiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEyMSwxMjEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMCwxMDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMiwxMDIpXSldLHt9KQ0000, new int[] {116,121,112,101,100,101,102}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgidHlwZURlZiIsc29ydCgiU3RvcmFnZUNsYXNzIikpLFtsaXQoInR5cGVkZWYiKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJTdG9yYWdlQ2xhc3MiKSxbbGl0KCJleHRlcm4iKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(810, 0, cHJvZChsaXQoImV4dGVybiIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTIwLDEyMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKV0se30p, new int[] {101,120,116,101,114,110}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJTdG9yYWdlQ2xhc3MiKSxbbGl0KCJleHRlcm4iKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJTdG9yYWdlQ2xhc3MiKSxbbGl0KCJzdGF0aWMiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(812, 0, cHJvZChsaXQoInN0YXRpYyIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pXSx7fSk00, new int[] {115,116,97,116,105,99}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJTdG9yYWdlQ2xhc3MiKSxbbGl0KCJzdGF0aWMiKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJTdG9yYWdlQ2xhc3MiKSxbbGl0KCJyZWdpc3RlciIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(814, 0, cHJvZChsaXQoInJlZ2lzdGVyIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pXSx7fSk00, new int[] {114,101,103,105,115,116,101,114}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJTdG9yYWdlQ2xhc3MiKSxbbGl0KCJyZWdpc3RlciIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdG9yYWdlQ2xhc3MiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiU3RvcmFnZUNsYXNzXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJTdG9yYWdlQ2xhc3MiKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new LiteralStackNode<IConstructor>(818, 1, cHJvZChsaXQoInNvcnQoXCJTdG9yYWdlQ2xhc3NcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODMsODMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2Nyw2NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {115,111,114,116,40,34,83,116,111,114,97,103,101,67,108,97,115,115,34,41}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(822, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(819, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(821, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(820, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[0] = new CharStackNode<IConstructor>(817, 0, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdG9yYWdlQ2xhc3MiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiU3RvcmFnZUNsYXNzXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJTdG9yYWdlQ2xhc3MiKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJTdG9yYWdlQ2xhc3MiKSxbbGl0KCJhdXRvIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(825, 0, cHJvZChsaXQoImF1dG8iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pXSx7fSk00, new int[] {97,117,116,111}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJTdG9yYWdlQ2xhc3MiKSxbbGl0KCJhdXRvIildLHt9KQ0000, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgidHlwZURlZiIsc29ydCgiU3RvcmFnZUNsYXNzIikpLFtsaXQoInR5cGVkZWYiKV0se30p(builder);
      
        _init_cHJvZChzb3J0KCJTdG9yYWdlQ2xhc3MiKSxbbGl0KCJleHRlcm4iKV0se30p(builder);
      
        _init_cHJvZChzb3J0KCJTdG9yYWdlQ2xhc3MiKSxbbGl0KCJzdGF0aWMiKV0se30p(builder);
      
        _init_cHJvZChzb3J0KCJTdG9yYWdlQ2xhc3MiKSxbbGl0KCJyZWdpc3RlciIpXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdG9yYWdlQ2xhc3MiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiU3RvcmFnZUNsYXNzXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJTdG9yYWdlQ2xhc3MiKSkpfSk00(builder);
      
        _init_cHJvZChzb3J0KCJTdG9yYWdlQ2xhc3MiKSxbbGl0KCJhdXRvIildLHt9KQ0000(builder);
      
    }
  }
	
  protected static class StringConstant {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIlN0cmluZ0NvbnN0YW50IikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlN0cmluZ0NvbnN0YW50XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihsZXgoIlN0cmluZ0NvbnN0YW50IikpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new ListStackNode<IConstructor>(834, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(833, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(831, 1, cHJvZChsaXQoInNvcnQoXCJTdHJpbmdDb25zdGFudFwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4Myw4MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAzLDEwMyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjcsNjcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000, new int[] {115,111,114,116,40,34,83,116,114,105,110,103,67,111,110,115,116,97,110,116,34,41}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(835, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(832, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(830, 0, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIlN0cmluZ0NvbnN0YW50IikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlN0cmluZ0NvbnN0YW50XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihsZXgoIlN0cmluZ0NvbnN0YW50IikpKX0p, tmp);
	}
    protected static final void _init_cHJvZChsZXgoIlN0cmluZ0NvbnN0YW50IiksW29wdChcY2hhci1jbGFzcyhbcmFuZ2UoNzYsNzYpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcaXRlci1zdGFyKGxleCgiU3RyaW5nQ29uc3RhbnRDb250ZW50IikpLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[4];
      
      tmp[2] = new ListStackNode<IConstructor>(842, 2, cmVndWxhcihcaXRlci1zdGFyKGxleCgiU3RyaW5nQ29uc3RhbnRDb250ZW50IikpKQ0000, new NonTerminalStackNode<IConstructor>(841, 0, "StringConstantContent", null, null), false, null, null);
      tmp[0] = new OptionalStackNode<IConstructor>(839, 0, cmVndWxhcihvcHQoXGNoYXItY2xhc3MoW3JhbmdlKDc2LDc2KV0pKSk00, new CharStackNode<IConstructor>(838, 0, new int[][]{{76,76}}, null, null), null, null);
      tmp[1] = new CharStackNode<IConstructor>(840, 1, new int[][]{{34,34}}, null, null);
      tmp[3] = new CharStackNode<IConstructor>(843, 3, new int[][]{{34,34}}, null, null);
      builder.addAlternative(CParser.cHJvZChsZXgoIlN0cmluZ0NvbnN0YW50IiksW29wdChcY2hhci1jbGFzcyhbcmFuZ2UoNzYsNzYpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcaXRlci1zdGFyKGxleCgiU3RyaW5nQ29uc3RhbnRDb250ZW50IikpLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKV0se30p, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIlN0cmluZ0NvbnN0YW50IikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlN0cmluZ0NvbnN0YW50XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihsZXgoIlN0cmluZ0NvbnN0YW50IikpKX0p(builder);
      
        _init_cHJvZChsZXgoIlN0cmluZ0NvbnN0YW50IiksW29wdChcY2hhci1jbGFzcyhbcmFuZ2UoNzYsNzYpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcaXRlci1zdGFyKGxleCgiU3RyaW5nQ29uc3RhbnRDb250ZW50IikpLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKV0se30p(builder);
      
    }
  }
	
  protected static class MoreParameters {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJNb3JlUGFyYW1ldGVycyIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJNb3JlUGFyYW1ldGVyc1wiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiTW9yZVBhcmFtZXRlcnMiKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new LiteralStackNode<IConstructor>(924, 1, cHJvZChsaXQoInNvcnQoXCJNb3JlUGFyYW1ldGVyc1wiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg3Nyw3NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODAsODApXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA5LDEwOSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {115,111,114,116,40,34,77,111,114,101,80,97,114,97,109,101,116,101,114,115,34,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(927, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(926, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(925, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(928, 4, new int[][]{{0,0}}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(923, 0, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJNb3JlUGFyYW1ldGVycyIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJNb3JlUGFyYW1ldGVyc1wiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiTW9yZVBhcmFtZXRlcnMiKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJNb3JlUGFyYW1ldGVycyIpLFtsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIuLi4iKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(932, 1, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(931, 0, cHJvZChsaXQoIiwiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pXSx7fSk00, new int[] {44}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(933, 2, cHJvZChsaXQoIi4uLiIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoNDYsNDYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ2LDQ2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0Niw0NildKV0se30p, new int[] {46,46,46}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJNb3JlUGFyYW1ldGVycyIpLFtsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIuLi4iKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJNb3JlUGFyYW1ldGVycyIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIm9wdChzb3J0KFwiTW9yZVBhcmFtZXRlcnNcIikpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihvcHQoc29ydCgiTW9yZVBhcmFtZXRlcnMiKSkpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new CharStackNode<IConstructor>(936, 0, new int[][]{{0,0}}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(941, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(938, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(940, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(939, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(937, 1, cHJvZChsaXQoIm9wdChzb3J0KFwiTW9yZVBhcmFtZXRlcnNcIikpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg3Nyw3NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODAsODApXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA5LDEwOSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {111,112,116,40,115,111,114,116,40,34,77,111,114,101,80,97,114,97,109,101,116,101,114,115,34,41,41}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJNb3JlUGFyYW1ldGVycyIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIm9wdChzb3J0KFwiTW9yZVBhcmFtZXRlcnNcIikpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihvcHQoc29ydCgiTW9yZVBhcmFtZXRlcnMiKSkpKX0p, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJNb3JlUGFyYW1ldGVycyIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJNb3JlUGFyYW1ldGVyc1wiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiTW9yZVBhcmFtZXRlcnMiKSkpfSk00(builder);
      
        _init_cHJvZChzb3J0KCJNb3JlUGFyYW1ldGVycyIpLFtsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIuLi4iKV0se30p(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJNb3JlUGFyYW1ldGVycyIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIm9wdChzb3J0KFwiTW9yZVBhcmFtZXRlcnNcIikpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihvcHQoc29ydCgiTW9yZVBhcmFtZXRlcnMiKSkpKX0p(builder);
      
    }
  }
	
  protected static class Specifier {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgidHlwZVNwZWNpZmllciIsc29ydCgiU3BlY2lmaWVyIikpLFtzb3J0KCJUeXBlU3BlY2lmaWVyIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(1043, 0, "TypeSpecifier", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgidHlwZVNwZWNpZmllciIsc29ydCgiU3BlY2lmaWVyIikpLFtzb3J0KCJUeXBlU3BlY2lmaWVyIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTcGVjaWZpZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJpdGVyKHNvcnQoXCJTcGVjaWZpZXJcIikpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new LiteralStackNode<IConstructor>(1047, 1, cHJvZChsaXQoIml0ZXIoc29ydChcIlNwZWNpZmllclwiKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDgzLDgzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAyLDEwMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {105,116,101,114,40,115,111,114,116,40,34,83,112,101,99,105,102,105,101,114,34,41,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(1050, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(1049, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[0] = new CharStackNode<IConstructor>(1046, 0, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(1048, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(1051, 4, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTcGVjaWZpZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJpdGVyKHNvcnQoXCJTcGVjaWZpZXJcIikpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTcGVjaWZpZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiU3BlY2lmaWVyXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJTcGVjaWZpZXIiKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new LiteralStackNode<IConstructor>(1058, 1, cHJvZChsaXQoInNvcnQoXCJTcGVjaWZpZXJcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODMsODMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDIsMTAyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000, new int[] {115,111,114,116,40,34,83,112,101,99,105,102,105,101,114,34,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(1061, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(1060, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[0] = new CharStackNode<IConstructor>(1057, 0, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(1059, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(1062, 4, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTcGVjaWZpZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiU3BlY2lmaWVyXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJTcGVjaWZpZXIiKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTcGVjaWZpZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc3Rhcihzb3J0KFwiU3BlY2lmaWVyXCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[2] = new LiteralStackNode<IConstructor>(1068, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(1066, 0, new int[][]{{0,0}}, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(1067, 1, cHJvZChsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJTcGVjaWZpZXJcIikpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4Myw4MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEyLDExMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMiwxMDIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000, new int[] {92,105,116,101,114,45,115,116,97,114,40,115,111,114,116,40,34,83,112,101,99,105,102,105,101,114,34,41,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(1070, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(1069, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[4] = new CharStackNode<IConstructor>(1071, 4, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTcGVjaWZpZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc3Rhcihzb3J0KFwiU3BlY2lmaWVyXCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgidHlwZVF1YWxpZmllciIsc29ydCgiU3BlY2lmaWVyIikpLFtzb3J0KCJUeXBlUXVhbGlmaWVyIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(1077, 0, "TypeQualifier", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgidHlwZVF1YWxpZmllciIsc29ydCgiU3BlY2lmaWVyIikpLFtzb3J0KCJUeXBlUXVhbGlmaWVyIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgic3RvcmFnZUNsYXNzIixzb3J0KCJTcGVjaWZpZXIiKSksW3NvcnQoIlN0b3JhZ2VDbGFzcyIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(1080, 0, "StorageClass", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgic3RvcmFnZUNsYXNzIixzb3J0KCJTcGVjaWZpZXIiKSksW3NvcnQoIlN0b3JhZ2VDbGFzcyIpXSx7fSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgidHlwZVNwZWNpZmllciIsc29ydCgiU3BlY2lmaWVyIikpLFtzb3J0KCJUeXBlU3BlY2lmaWVyIildLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTcGVjaWZpZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJpdGVyKHNvcnQoXCJTcGVjaWZpZXJcIikpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTcGVjaWZpZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiU3BlY2lmaWVyXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJTcGVjaWZpZXIiKSkpfSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTcGVjaWZpZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc3Rhcihzb3J0KFwiU3BlY2lmaWVyXCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(builder);
      
        _init_cHJvZChsYWJlbCgidHlwZVF1YWxpZmllciIsc29ydCgiU3BlY2lmaWVyIikpLFtzb3J0KCJUeXBlUXVhbGlmaWVyIildLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgic3RvcmFnZUNsYXNzIixzb3J0KCJTcGVjaWZpZXIiKSksW3NvcnQoIlN0b3JhZ2VDbGFzcyIpXSx7fSk00(builder);
      
    }
  }
	
  protected static class Declarator {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiYnJhY2tldCIsc29ydCgiRGVjbGFyYXRvciIpKSxbbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJkZWNsIixzb3J0KCJEZWNsYXJhdG9yIikpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKV0se2JyYWNrZXQoKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(1184, 1, "layouts_LAYOUTLIST", null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(1185, 2, "Declarator", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(1187, 3, "layouts_LAYOUTLIST", null, null);
      tmp[4] = new LiteralStackNode<IConstructor>(1188, 4, cHJvZChsaXQoIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {41}, null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(1183, 0, cHJvZChsaXQoIigiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pXSx7fSk00, new int[] {40}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiYnJhY2tldCIsc29ydCgiRGVjbGFyYXRvciIpKSxbbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJkZWNsIixzb3J0KCJEZWNsYXJhdG9yIikpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKV0se2JyYWNrZXQoKX0p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiZnVuY3Rpb25EZWNsYXJhdG9yIixzb3J0KCJEZWNsYXJhdG9yIikpLFtsYWJlbCgiZGVjbCIsc29ydCgiRGVjbGFyYXRvciIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJwYXJhbXMiLG9wdChzb3J0KCJQYXJhbWV0ZXJzIikpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIpIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[7];
      
      tmp[3] = new NonTerminalStackNode<IConstructor>(1195, 3, "layouts_LAYOUTLIST", null, null);
      tmp[4] = new OptionalStackNode<IConstructor>(1197, 4, cmVndWxhcihvcHQoc29ydCgiUGFyYW1ldGVycyIpKSk00, new NonTerminalStackNode<IConstructor>(1196, 0, "Parameters", null, null), null, null);
      tmp[6] = new LiteralStackNode<IConstructor>(1200, 6, cHJvZChsaXQoIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {41}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(1194, 2, cHJvZChsaXQoIigiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pXSx7fSk00, new int[] {40}, null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(1191, 0, "Declarator", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(1193, 1, "layouts_LAYOUTLIST", null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(1199, 5, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiZnVuY3Rpb25EZWNsYXJhdG9yIixzb3J0KCJEZWNsYXJhdG9yIikpLFtsYWJlbCgiZGVjbCIsc29ydCgiRGVjbGFyYXRvciIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJwYXJhbXMiLG9wdChzb3J0KCJQYXJhbWV0ZXJzIikpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIpIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkRlY2xhcmF0b3JcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIkRlY2xhcmF0b3IiKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new LiteralStackNode<IConstructor>(1230, 1, cHJvZChsaXQoInNvcnQoXCJEZWNsYXJhdG9yXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY4LDY4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000, new int[] {115,111,114,116,40,34,68,101,99,108,97,114,97,116,111,114,34,41}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(1231, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(1233, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(1232, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[0] = new CharStackNode<IConstructor>(1229, 0, new int[][]{{0,0}}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(1234, 4, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkRlY2xhcmF0b3JcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIkRlY2xhcmF0b3IiKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgib3B0KHNvcnQoXCJEZWNsYXJhdG9yXCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIob3B0KHNvcnQoIkRlY2xhcmF0b3IiKSkpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new ListStackNode<IConstructor>(1242, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(1241, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[0] = new CharStackNode<IConstructor>(1238, 0, new int[][]{{0,0}}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(1243, 4, new int[][]{{0,0}}, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(1239, 1, cHJvZChsaXQoIm9wdChzb3J0KFwiRGVjbGFyYXRvclwiKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY4LDY4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {111,112,116,40,115,111,114,116,40,34,68,101,99,108,97,114,97,116,111,114,34,41,41}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(1240, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgib3B0KHNvcnQoXCJEZWNsYXJhdG9yXCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIob3B0KHNvcnQoIkRlY2xhcmF0b3IiKSkpKX0p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgicG9pbnRlckRlY2xhcmF0b3IiLHNvcnQoIkRlY2xhcmF0b3IiKSksW2xpdCgiKiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgicXVhbGlmaWVycyIsXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlR5cGVRdWFsaWZpZXIiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgiZGVjbCIsc29ydCgiRGVjbGFyYXRvciIpKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new LiteralStackNode<IConstructor>(1218, 0, cHJvZChsaXQoIioiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQyLDQyKV0pXSx7fSk00, new int[] {42}, null, null);
      tmp[2] = new SeparatedListStackNode<IConstructor>(1222, 2, cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiVHlwZVF1YWxpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSk00, new NonTerminalStackNode<IConstructor>(1220, 0, "TypeQualifier", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(1221, 1, "layouts_LAYOUTLIST", null, null)}, false, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(1225, 4, "Declarator", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(1219, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(1224, 3, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgicG9pbnRlckRlY2xhcmF0b3IiLHNvcnQoIkRlY2xhcmF0b3IiKSksW2xpdCgiKiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgicXVhbGlmaWVycyIsXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlR5cGVRdWFsaWZpZXIiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgiZGVjbCIsc29ydCgiRGVjbGFyYXRvciIpKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiaWRlbnRpZmllciIsc29ydCgiRGVjbGFyYXRvciIpKSxbbGV4KCJJZGVudGlmaWVyIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(1203, 0, "Identifier", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiaWRlbnRpZmllciIsc29ydCgiRGVjbGFyYXRvciIpKSxbbGV4KCJJZGVudGlmaWVyIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiYXJyYXlEZWNsYXJhdG9yIixzb3J0KCJEZWNsYXJhdG9yIikpLFtsYWJlbCgiZGVjbCIsc29ydCgiRGVjbGFyYXRvciIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJbIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJleHAiLG9wdChzb3J0KCJFeHByZXNzaW9uIikpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJdIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[7];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(1206, 0, "Declarator", null, null);
      tmp[4] = new OptionalStackNode<IConstructor>(1212, 4, cmVndWxhcihvcHQoc29ydCgiRXhwcmVzc2lvbiIpKSk00, new NonTerminalStackNode<IConstructor>(1211, 0, "Expression", null, null), null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(1209, 2, cHJvZChsaXQoIlsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkxLDkxKV0pXSx7fSk00, new int[] {91}, null, null);
      tmp[6] = new LiteralStackNode<IConstructor>(1215, 6, cHJvZChsaXQoIl0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkzLDkzKV0pXSx7fSk00, new int[] {93}, null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(1210, 3, "layouts_LAYOUTLIST", null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(1214, 5, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(1208, 1, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiYXJyYXlEZWNsYXJhdG9yIixzb3J0KCJEZWNsYXJhdG9yIikpLFtsYWJlbCgiZGVjbCIsc29ydCgiRGVjbGFyYXRvciIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJbIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJleHAiLG9wdChzb3J0KCJFeHByZXNzaW9uIikpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJdIildLHt9KQ0000, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiYnJhY2tldCIsc29ydCgiRGVjbGFyYXRvciIpKSxbbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJkZWNsIixzb3J0KCJEZWNsYXJhdG9yIikpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKV0se2JyYWNrZXQoKX0p(builder);
      
        _init_cHJvZChsYWJlbCgiZnVuY3Rpb25EZWNsYXJhdG9yIixzb3J0KCJEZWNsYXJhdG9yIikpLFtsYWJlbCgiZGVjbCIsc29ydCgiRGVjbGFyYXRvciIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJwYXJhbXMiLG9wdChzb3J0KCJQYXJhbWV0ZXJzIikpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIpIildLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkRlY2xhcmF0b3JcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIkRlY2xhcmF0b3IiKSkpfSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgib3B0KHNvcnQoXCJEZWNsYXJhdG9yXCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIob3B0KHNvcnQoIkRlY2xhcmF0b3IiKSkpKX0p(builder);
      
        _init_cHJvZChsYWJlbCgicG9pbnRlckRlY2xhcmF0b3IiLHNvcnQoIkRlY2xhcmF0b3IiKSksW2xpdCgiKiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgicXVhbGlmaWVycyIsXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlR5cGVRdWFsaWZpZXIiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgiZGVjbCIsc29ydCgiRGVjbGFyYXRvciIpKV0se30p(builder);
      
        _init_cHJvZChsYWJlbCgiaWRlbnRpZmllciIsc29ydCgiRGVjbGFyYXRvciIpKSxbbGV4KCJJZGVudGlmaWVyIildLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiYXJyYXlEZWNsYXJhdG9yIixzb3J0KCJEZWNsYXJhdG9yIikpLFtsYWJlbCgiZGVjbCIsc29ydCgiRGVjbGFyYXRvciIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJbIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJleHAiLG9wdChzb3J0KCJFeHByZXNzaW9uIikpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJdIildLHt9KQ0000(builder);
      
    }
  }
	
  protected static class TypeQualifier {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChzb3J0KCJUeXBlUXVhbGlmaWVyIiksW2xpdCgidm9sYXRpbGUiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(1307, 0, cHJvZChsaXQoInZvbGF0aWxlIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTgsMTE4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKV0se30p, new int[] {118,111,108,97,116,105,108,101}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJUeXBlUXVhbGlmaWVyIiksW2xpdCgidm9sYXRpbGUiKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJUeXBlUXVhbGlmaWVyIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiXFxpdGVyLXN0YXIoc29ydChcIlR5cGVRdWFsaWZpZXJcIikpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zdGFyLXNlcHMoc29ydCgiVHlwZVF1YWxpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[2] = new LiteralStackNode<IConstructor>(1312, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(1315, 4, new int[][]{{0,0}}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(1310, 0, new int[][]{{0,0}}, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(1311, 1, cHJvZChsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJUeXBlUXVhbGlmaWVyXCIpKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoOTIsOTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ1LDQ1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODQsODQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEyMSwxMjEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDgxLDgxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAyLDEwMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {92,105,116,101,114,45,115,116,97,114,40,115,111,114,116,40,34,84,121,112,101,81,117,97,108,105,102,105,101,114,34,41,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(1314, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(1313, 0, new int[][]{{48,57}}, null, null), true, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJUeXBlUXVhbGlmaWVyIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiXFxpdGVyLXN0YXIoc29ydChcIlR5cGVRdWFsaWZpZXJcIikpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zdGFyLXNlcHMoc29ydCgiVHlwZVF1YWxpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJUeXBlUXVhbGlmaWVyIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlR5cGVRdWFsaWZpZXJcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlR5cGVRdWFsaWZpZXIiKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new CharStackNode<IConstructor>(1321, 0, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(1323, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(1326, 4, new int[][]{{0,0}}, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(1322, 1, cHJvZChsaXQoInNvcnQoXCJUeXBlUXVhbGlmaWVyXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDg0LDg0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjEsMTIxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4MSw4MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE3LDExNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMiwxMDIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {115,111,114,116,40,34,84,121,112,101,81,117,97,108,105,102,105,101,114,34,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(1325, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(1324, 0, new int[][]{{48,57}}, null, null), true, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJUeXBlUXVhbGlmaWVyIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlR5cGVRdWFsaWZpZXJcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlR5cGVRdWFsaWZpZXIiKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJUeXBlUXVhbGlmaWVyIiksW2xpdCgiY29uc3QiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(1329, 0, cHJvZChsaXQoImNvbnN0IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKV0se30p, new int[] {99,111,110,115,116}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJUeXBlUXVhbGlmaWVyIiksW2xpdCgiY29uc3QiKV0se30p, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChzb3J0KCJUeXBlUXVhbGlmaWVyIiksW2xpdCgidm9sYXRpbGUiKV0se30p(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJUeXBlUXVhbGlmaWVyIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiXFxpdGVyLXN0YXIoc29ydChcIlR5cGVRdWFsaWZpZXJcIikpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zdGFyLXNlcHMoc29ydCgiVHlwZVF1YWxpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJUeXBlUXVhbGlmaWVyIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlR5cGVRdWFsaWZpZXJcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlR5cGVRdWFsaWZpZXIiKSkpfSk00(builder);
      
        _init_cHJvZChzb3J0KCJUeXBlUXVhbGlmaWVyIiksW2xpdCgiY29uc3QiKV0se30p(builder);
      
    }
  }
	
  protected static class AbstractDeclarator {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiYnJhY2tldCIsc29ydCgiQWJzdHJhY3REZWNsYXJhdG9yIikpLFtsaXQoIigiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGFiZWwoImRlY2wiLHNvcnQoIkFic3RyYWN0RGVjbGFyYXRvciIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIpIildLHticmFja2V0KCl9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new NonTerminalStackNode<IConstructor>(1437, 3, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(1434, 1, "layouts_LAYOUTLIST", null, null);
      tmp[4] = new LiteralStackNode<IConstructor>(1438, 4, cHJvZChsaXQoIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {41}, null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(1435, 2, "AbstractDeclarator", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(1433, 0, cHJvZChsaXQoIigiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pXSx7fSk00, new int[] {40}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiYnJhY2tldCIsc29ydCgiQWJzdHJhY3REZWNsYXJhdG9yIikpLFtsaXQoIigiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGFiZWwoImRlY2wiLHNvcnQoIkFic3RyYWN0RGVjbGFyYXRvciIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIpIildLHticmFja2V0KCl9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiYXJyYXlEZWNsYXJhdG9yIixzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSksW2xhYmVsKCJkZWNsIixzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiWyIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgiZXhwIixvcHQoc29ydCgiRXhwcmVzc2lvbiIpKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiXSIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[7];
      
      tmp[4] = new OptionalStackNode<IConstructor>(1447, 4, cmVndWxhcihvcHQoc29ydCgiRXhwcmVzc2lvbiIpKSk00, new NonTerminalStackNode<IConstructor>(1446, 0, "Expression", null, null), null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(1443, 1, "layouts_LAYOUTLIST", null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(1449, 5, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(1445, 3, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(1441, 0, "AbstractDeclarator", null, null);
      tmp[6] = new LiteralStackNode<IConstructor>(1450, 6, cHJvZChsaXQoIl0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkzLDkzKV0pXSx7fSk00, new int[] {93}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(1444, 2, cHJvZChsaXQoIlsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkxLDkxKV0pXSx7fSk00, new int[] {91}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiYXJyYXlEZWNsYXJhdG9yIixzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSksW2xhYmVsKCJkZWNsIixzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiWyIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgiZXhwIixvcHQoc29ydCgiRXhwcmVzc2lvbiIpKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiXSIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgicG9pbnRlckRlY2xhcmF0b3IiLHNvcnQoIkFic3RyYWN0RGVjbGFyYXRvciIpKSxbbGl0KCIqIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJxdWFsaWZpZXJzIixcaXRlci1zdGFyLXNlcHMoc29ydCgiVHlwZVF1YWxpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJkZWNsIixzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSldLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new LiteralStackNode<IConstructor>(1468, 0, cHJvZChsaXQoIioiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQyLDQyKV0pXSx7fSk00, new int[] {42}, null, null);
      tmp[2] = new SeparatedListStackNode<IConstructor>(1472, 2, cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiVHlwZVF1YWxpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSk00, new NonTerminalStackNode<IConstructor>(1470, 0, "TypeQualifier", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(1471, 1, "layouts_LAYOUTLIST", null, null)}, false, null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(1474, 3, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(1469, 1, "layouts_LAYOUTLIST", null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(1475, 4, "AbstractDeclarator", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgicG9pbnRlckRlY2xhcmF0b3IiLHNvcnQoIkFic3RyYWN0RGVjbGFyYXRvciIpKSxbbGl0KCIqIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJxdWFsaWZpZXJzIixcaXRlci1zdGFyLXNlcHMoc29ydCgiVHlwZVF1YWxpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJkZWNsIixzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSldLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiQWJzdHJhY3REZWNsYXJhdG9yXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new ListStackNode<IConstructor>(1483, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(1482, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(1480, 1, cHJvZChsaXQoInNvcnQoXCJBYnN0cmFjdERlY2xhcmF0b3JcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjUsNjUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk4LDk4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY4LDY4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000, new int[] {115,111,114,116,40,34,65,98,115,116,114,97,99,116,68,101,99,108,97,114,97,116,111,114,34,41}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(1479, 0, new int[][]{{0,0}}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(1484, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(1481, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiQWJzdHJhY3REZWNsYXJhdG9yXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiZnVuY3Rpb25EZWNsYXJhdG9yIixzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSksW2xhYmVsKCJkZWNsIixzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiKCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgicGFyYW1zIixvcHQoc29ydCgiUGFyYW1ldGVycyIpKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiKSIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[7];
      
      tmp[2] = new LiteralStackNode<IConstructor>(1456, 2, cHJvZChsaXQoIigiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pXSx7fSk00, new int[] {40}, null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(1453, 0, "AbstractDeclarator", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(1457, 3, "layouts_LAYOUTLIST", null, null);
      tmp[6] = new LiteralStackNode<IConstructor>(1462, 6, cHJvZChsaXQoIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {41}, null, null);
      tmp[4] = new OptionalStackNode<IConstructor>(1459, 4, cmVndWxhcihvcHQoc29ydCgiUGFyYW1ldGVycyIpKSk00, new NonTerminalStackNode<IConstructor>(1458, 0, "Parameters", null, null), null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(1461, 5, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(1455, 1, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiZnVuY3Rpb25EZWNsYXJhdG9yIixzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSksW2xhYmVsKCJkZWNsIixzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiKCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgicGFyYW1zIixvcHQoc29ydCgiUGFyYW1ldGVycyIpKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiKSIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiaWRlbnRpZmllciIsc29ydCgiQWJzdHJhY3REZWNsYXJhdG9yIikpLFtzb3J0KCJBbm9ueW1vdXNJZGVudGlmaWVyIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(1465, 0, "AnonymousIdentifier", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiaWRlbnRpZmllciIsc29ydCgiQWJzdHJhY3REZWNsYXJhdG9yIikpLFtzb3J0KCJBbm9ueW1vdXNJZGVudGlmaWVyIildLHt9KQ0000, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiYnJhY2tldCIsc29ydCgiQWJzdHJhY3REZWNsYXJhdG9yIikpLFtsaXQoIigiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGFiZWwoImRlY2wiLHNvcnQoIkFic3RyYWN0RGVjbGFyYXRvciIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIpIildLHticmFja2V0KCl9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiYXJyYXlEZWNsYXJhdG9yIixzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSksW2xhYmVsKCJkZWNsIixzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiWyIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgiZXhwIixvcHQoc29ydCgiRXhwcmVzc2lvbiIpKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiXSIpXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgicG9pbnRlckRlY2xhcmF0b3IiLHNvcnQoIkFic3RyYWN0RGVjbGFyYXRvciIpKSxbbGl0KCIqIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJxdWFsaWZpZXJzIixcaXRlci1zdGFyLXNlcHMoc29ydCgiVHlwZVF1YWxpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJkZWNsIixzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSldLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiQWJzdHJhY3REZWNsYXJhdG9yXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSkpfSk00(builder);
      
        _init_cHJvZChsYWJlbCgiZnVuY3Rpb25EZWNsYXJhdG9yIixzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSksW2xhYmVsKCJkZWNsIixzb3J0KCJBYnN0cmFjdERlY2xhcmF0b3IiKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiKCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgicGFyYW1zIixvcHQoc29ydCgiUGFyYW1ldGVycyIpKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiKSIpXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgiaWRlbnRpZmllciIsc29ydCgiQWJzdHJhY3REZWNsYXJhdG9yIikpLFtzb3J0KCJBbm9ueW1vdXNJZGVudGlmaWVyIildLHt9KQ0000(builder);
      
    }
  }
	
  protected static class PrototypeDeclarator {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiZnVuY3Rpb25EZWNsYXJhdG9yIixzb3J0KCJQcm90b3R5cGVEZWNsYXJhdG9yIikpLFtsYWJlbCgicHJvdG9fZGVjbCIsc29ydCgiUHJvdG90eXBlRGVjbGFyYXRvciIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJwYXJhbXMiLG9wdChzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXJzIikpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIpIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[7];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(1507, 0, "PrototypeDeclarator", null, null);
      tmp[6] = new LiteralStackNode<IConstructor>(1516, 6, cHJvZChsaXQoIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {41}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(1510, 2, cHJvZChsaXQoIigiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pXSx7fSk00, new int[] {40}, null, null);
      tmp[4] = new OptionalStackNode<IConstructor>(1513, 4, cmVndWxhcihvcHQoc29ydCgiUHJvdG90eXBlUGFyYW1ldGVycyIpKSk00, new NonTerminalStackNode<IConstructor>(1512, 0, "PrototypeParameters", null, null), null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(1509, 1, "layouts_LAYOUTLIST", null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(1515, 5, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(1511, 3, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiZnVuY3Rpb25EZWNsYXJhdG9yIixzb3J0KCJQcm90b3R5cGVEZWNsYXJhdG9yIikpLFtsYWJlbCgicHJvdG9fZGVjbCIsc29ydCgiUHJvdG90eXBlRGVjbGFyYXRvciIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJwYXJhbXMiLG9wdChzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXJzIikpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIpIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiYnJhY2tldCIsc29ydCgiUHJvdG90eXBlRGVjbGFyYXRvciIpKSxbbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJhYnNfZGVjbCIsc29ydCgiQWJzdHJhY3REZWNsYXJhdG9yIikpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKV0se2JyYWNrZXQoKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(1520, 1, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(1519, 0, cHJvZChsaXQoIigiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pXSx7fSk00, new int[] {40}, null, null);
      tmp[4] = new LiteralStackNode<IConstructor>(1524, 4, cHJvZChsaXQoIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {41}, null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(1521, 2, "AbstractDeclarator", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(1523, 3, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiYnJhY2tldCIsc29ydCgiUHJvdG90eXBlRGVjbGFyYXRvciIpKSxbbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJhYnNfZGVjbCIsc29ydCgiQWJzdHJhY3REZWNsYXJhdG9yIikpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKV0se2JyYWNrZXQoKX0p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiaWRlbnRpZmllciIsc29ydCgiUHJvdG90eXBlRGVjbGFyYXRvciIpKSxbbGV4KCJJZGVudGlmaWVyIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(1492, 0, "Identifier", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiaWRlbnRpZmllciIsc29ydCgiUHJvdG90eXBlRGVjbGFyYXRvciIpKSxbbGV4KCJJZGVudGlmaWVyIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgicG9pbnRlckRlY2xhcmF0b3IiLHNvcnQoIlByb3RvdHlwZURlY2xhcmF0b3IiKSksW2xpdCgiKiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgicXVhbGlmaWVycyIsXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlR5cGVRdWFsaWZpZXIiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgiZGVjbCIsc29ydCgiUHJvdG90eXBlRGVjbGFyYXRvciIpKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(1528, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(1533, 3, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(1527, 0, cHJvZChsaXQoIioiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQyLDQyKV0pXSx7fSk00, new int[] {42}, null, null);
      tmp[2] = new SeparatedListStackNode<IConstructor>(1531, 2, cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiVHlwZVF1YWxpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSk00, new NonTerminalStackNode<IConstructor>(1529, 0, "TypeQualifier", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(1530, 1, "layouts_LAYOUTLIST", null, null)}, false, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(1534, 4, "PrototypeDeclarator", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgicG9pbnRlckRlY2xhcmF0b3IiLHNvcnQoIlByb3RvdHlwZURlY2xhcmF0b3IiKSksW2xpdCgiKiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgicXVhbGlmaWVycyIsXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlR5cGVRdWFsaWZpZXIiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgiZGVjbCIsc29ydCgiUHJvdG90eXBlRGVjbGFyYXRvciIpKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQcm90b3R5cGVEZWNsYXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlByb3RvdHlwZURlY2xhcmF0b3JcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlByb3RvdHlwZURlY2xhcmF0b3IiKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new CharStackNode<IConstructor>(1543, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(1540, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(1538, 0, new int[][]{{0,0}}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(1542, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(1541, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(1539, 1, cHJvZChsaXQoInNvcnQoXCJQcm90b3R5cGVEZWNsYXJhdG9yXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDgwLDgwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjEsMTIxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2OCw2OCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {115,111,114,116,40,34,80,114,111,116,111,116,121,112,101,68,101,99,108,97,114,97,116,111,114,34,41}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQcm90b3R5cGVEZWNsYXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlByb3RvdHlwZURlY2xhcmF0b3JcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlByb3RvdHlwZURlY2xhcmF0b3IiKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiYXJyYXlEZWNsYXJhdG9yIixzb3J0KCJQcm90b3R5cGVEZWNsYXJhdG9yIikpLFtsYWJlbCgicHJvdG9fZGVjbCIsc29ydCgiUHJvdG90eXBlRGVjbGFyYXRvciIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJbIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJleHAiLG9wdChzb3J0KCJFeHByZXNzaW9uIikpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJdIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[7];
      
      tmp[6] = new LiteralStackNode<IConstructor>(1504, 6, cHJvZChsaXQoIl0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkzLDkzKV0pXSx7fSk00, new int[] {93}, null, null);
      tmp[4] = new OptionalStackNode<IConstructor>(1501, 4, cmVndWxhcihvcHQoc29ydCgiRXhwcmVzc2lvbiIpKSk00, new NonTerminalStackNode<IConstructor>(1500, 0, "Expression", null, null), null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(1498, 2, cHJvZChsaXQoIlsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkxLDkxKV0pXSx7fSk00, new int[] {91}, null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(1495, 0, "PrototypeDeclarator", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(1499, 3, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(1497, 1, "layouts_LAYOUTLIST", null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(1503, 5, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiYXJyYXlEZWNsYXJhdG9yIixzb3J0KCJQcm90b3R5cGVEZWNsYXJhdG9yIikpLFtsYWJlbCgicHJvdG9fZGVjbCIsc29ydCgiUHJvdG90eXBlRGVjbGFyYXRvciIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJbIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJleHAiLG9wdChzb3J0KCJFeHByZXNzaW9uIikpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJdIildLHt9KQ0000, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiZnVuY3Rpb25EZWNsYXJhdG9yIixzb3J0KCJQcm90b3R5cGVEZWNsYXJhdG9yIikpLFtsYWJlbCgicHJvdG9fZGVjbCIsc29ydCgiUHJvdG90eXBlRGVjbGFyYXRvciIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJwYXJhbXMiLG9wdChzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXJzIikpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIpIildLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiYnJhY2tldCIsc29ydCgiUHJvdG90eXBlRGVjbGFyYXRvciIpKSxbbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJhYnNfZGVjbCIsc29ydCgiQWJzdHJhY3REZWNsYXJhdG9yIikpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKV0se2JyYWNrZXQoKX0p(builder);
      
        _init_cHJvZChsYWJlbCgiaWRlbnRpZmllciIsc29ydCgiUHJvdG90eXBlRGVjbGFyYXRvciIpKSxbbGV4KCJJZGVudGlmaWVyIildLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgicG9pbnRlckRlY2xhcmF0b3IiLHNvcnQoIlByb3RvdHlwZURlY2xhcmF0b3IiKSksW2xpdCgiKiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgicXVhbGlmaWVycyIsXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlR5cGVRdWFsaWZpZXIiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgiZGVjbCIsc29ydCgiUHJvdG90eXBlRGVjbGFyYXRvciIpKV0se30p(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQcm90b3R5cGVEZWNsYXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlByb3RvdHlwZURlY2xhcmF0b3JcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlByb3RvdHlwZURlY2xhcmF0b3IiKSkpfSk00(builder);
      
        _init_cHJvZChsYWJlbCgiYXJyYXlEZWNsYXJhdG9yIixzb3J0KCJQcm90b3R5cGVEZWNsYXJhdG9yIikpLFtsYWJlbCgicHJvdG9fZGVjbCIsc29ydCgiUHJvdG90eXBlRGVjbGFyYXRvciIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJbIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJleHAiLG9wdChzb3J0KCJFeHByZXNzaW9uIikpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJdIildLHt9KQ0000(builder);
      
    }
  }
	
  protected static class TranslationUnit {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChzb3J0KCJUcmFuc2xhdGlvblVuaXQiKSxbXGl0ZXItc2Vwcyhzb3J0KCJFeHRlcm5hbERlY2xhcmF0aW9uIiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new SeparatedListStackNode<IConstructor>(1640, 0, cmVndWxhcihcaXRlci1zZXBzKHNvcnQoIkV4dGVybmFsRGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkp, new NonTerminalStackNode<IConstructor>(1638, 0, "ExternalDeclaration", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(1639, 1, "layouts_LAYOUTLIST", null, null)}, true, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJUcmFuc2xhdGlvblVuaXQiKSxbXGl0ZXItc2Vwcyhzb3J0KCJFeHRlcm5hbERlY2xhcmF0aW9uIiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJUcmFuc2xhdGlvblVuaXQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiVHJhbnNsYXRpb25Vbml0XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJUcmFuc2xhdGlvblVuaXQiKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new CharStackNode<IConstructor>(1643, 0, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(1645, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(1648, 4, new int[][]{{0,0}}, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(1644, 1, cHJvZChsaXQoInNvcnQoXCJUcmFuc2xhdGlvblVuaXRcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODQsODQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODUsODUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {115,111,114,116,40,34,84,114,97,110,115,108,97,116,105,111,110,85,110,105,116,34,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(1647, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(1646, 0, new int[][]{{48,57}}, null, null), true, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJUcmFuc2xhdGlvblVuaXQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiVHJhbnNsYXRpb25Vbml0XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJUcmFuc2xhdGlvblVuaXQiKSkpfSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChzb3J0KCJUcmFuc2xhdGlvblVuaXQiKSxbXGl0ZXItc2Vwcyhzb3J0KCJFeHRlcm5hbERlY2xhcmF0aW9uIiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJUcmFuc2xhdGlvblVuaXQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiVHJhbnNsYXRpb25Vbml0XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJUcmFuc2xhdGlvblVuaXQiKSkpfSk00(builder);
      
    }
  }
	
  protected static class layouts_LAYOUTLIST {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYXlvdXRzKCJMQVlPVVRMSVNUIiksW2NvbmRpdGlvbmFsKFxpdGVyLXN0YXIobGV4KCJMQVlPVVQiKSkse1xub3QtZm9sbG93KFxjaGFyLWNsYXNzKFtyYW5nZSg5LDEwKSxyYW5nZSgxMywxMykscmFuZ2UoMzIsMzIpXSkpfSldLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new ListStackNode<IConstructor>(2073, 0, cmVndWxhcihcaXRlci1zdGFyKGxleCgiTEFZT1VUIikpKQ0000, new NonTerminalStackNode<IConstructor>(2070, 0, "LAYOUT", null, null), false, null, new ICompletionFilter[] {new CharFollowRestriction(new int[][]{{9,10},{13,13},{32,32}})});
      builder.addAlternative(CParser.cHJvZChsYXlvdXRzKCJMQVlPVVRMSVNUIiksW2NvbmRpdGlvbmFsKFxpdGVyLXN0YXIobGV4KCJMQVlPVVQiKSkse1xub3QtZm9sbG93KFxjaGFyLWNsYXNzKFtyYW5nZSg5LDEwKSxyYW5nZSgxMywxMykscmFuZ2UoMzIsMzIpXSkpfSldLHt9KQ0000, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYXlvdXRzKCJMQVlPVVRMSVNUIiksW2NvbmRpdGlvbmFsKFxpdGVyLXN0YXIobGV4KCJMQVlPVVQiKSkse1xub3QtZm9sbG93KFxjaGFyLWNsYXNzKFtyYW5nZSg5LDEwKSxyYW5nZSgxMywxMykscmFuZ2UoMzIsMzIpXSkpfSldLHt9KQ0000(builder);
      
    }
  }
	
  protected static class Comment {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsZXgoIkNvbW1lbnQiKSxbbGl0KCIvLyIpLFxpdGVyLXN0YXIoXGNoYXItY2xhc3MoW3JhbmdlKDEsOSkscmFuZ2UoMTEsMTY3NzcyMTUpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgxMCwxMCldKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[2] = new CharStackNode<IConstructor>(2109, 2, new int[][]{{10,10}}, null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(2106, 0, cHJvZChsaXQoIi8vIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg0Nyw0NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDcsNDcpXSldLHt9KQ0000, new int[] {47,47}, null, null);
      tmp[1] = new ListStackNode<IConstructor>(2108, 1, cmVndWxhcihcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSgxLDkpLHJhbmdlKDExLDE2Nzc3MjE1KV0pKSk00, new CharStackNode<IConstructor>(2107, 0, new int[][]{{1,9},{11,16777215}}, null, null), false, null, null);
      builder.addAlternative(CParser.cHJvZChsZXgoIkNvbW1lbnQiKSxbbGl0KCIvLyIpLFxpdGVyLXN0YXIoXGNoYXItY2xhc3MoW3JhbmdlKDEsOSkscmFuZ2UoMTEsMTY3NzcyMTUpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgxMCwxMCldKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkNvbW1lbnQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiQ29tbWVudFwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIobGV4KCJDb21tZW50IikpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new CharStackNode<IConstructor>(2112, 0, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(2114, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(2117, 4, new int[][]{{0,0}}, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(2113, 1, cHJvZChsaXQoInNvcnQoXCJDb21tZW50XCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY3LDY3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000, new int[] {115,111,114,116,40,34,67,111,109,109,101,110,116,34,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(2116, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(2115, 0, new int[][]{{48,57}}, null, null), true, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkNvbW1lbnQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiQ29tbWVudFwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIobGV4KCJDb21tZW50IikpKX0p, tmp);
	}
    protected static final void _init_cHJvZChsZXgoIkNvbW1lbnQiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ3LDQ3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0Miw0MildKSxcaXRlci1zdGFyKGxleCgiTXVsdGlMaW5lQ29tbWVudEJvZHlUb2tlbiIpKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDIsNDIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ3LDQ3KV0pXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new CharStackNode<IConstructor>(2120, 0, new int[][]{{47,47}}, null, null);
      tmp[2] = new ListStackNode<IConstructor>(2123, 2, cmVndWxhcihcaXRlci1zdGFyKGxleCgiTXVsdGlMaW5lQ29tbWVudEJvZHlUb2tlbiIpKSk00, new NonTerminalStackNode<IConstructor>(2122, 0, "MultiLineCommentBodyToken", null, null), false, null, null);
      tmp[4] = new CharStackNode<IConstructor>(2125, 4, new int[][]{{47,47}}, null, null);
      tmp[1] = new CharStackNode<IConstructor>(2121, 1, new int[][]{{42,42}}, null, null);
      tmp[3] = new CharStackNode<IConstructor>(2124, 3, new int[][]{{42,42}}, null, null);
      builder.addAlternative(CParser.cHJvZChsZXgoIkNvbW1lbnQiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ3LDQ3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0Miw0MildKSxcaXRlci1zdGFyKGxleCgiTXVsdGlMaW5lQ29tbWVudEJvZHlUb2tlbiIpKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDIsNDIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ3LDQ3KV0pXSx7fSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsZXgoIkNvbW1lbnQiKSxbbGl0KCIvLyIpLFxpdGVyLXN0YXIoXGNoYXItY2xhc3MoW3JhbmdlKDEsOSkscmFuZ2UoMTEsMTY3NzcyMTUpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgxMCwxMCldKV0se30p(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkNvbW1lbnQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiQ29tbWVudFwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIobGV4KCJDb21tZW50IikpKX0p(builder);
      
        _init_cHJvZChsZXgoIkNvbW1lbnQiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ3LDQ3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0Miw0MildKSxcaXRlci1zdGFyKGxleCgiTXVsdGlMaW5lQ29tbWVudEJvZHlUb2tlbiIpKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDIsNDIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ3LDQ3KV0pXSx7fSk00(builder);
      
    }
  }
	
  protected static class GlobalDeclaration {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiZ2xvYmFsRGVjbGFyYXRpb25XaXRoSW5pdERlY2xzIixzb3J0KCJHbG9iYWxEZWNsYXJhdGlvbiIpKSxbbGFiZWwoInNwZWNzMCIsXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJpbml0RGVjbGFyYXRvcnMiLFxpdGVyLXNlcHMoc29ydCgiSW5pdERlY2xhcmF0b3IiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiLCIpLGxheW91dHMoIkxBWU9VVExJU1QiKV0pKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI7IildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(2134, 1, "layouts_LAYOUTLIST", null, null);
      tmp[4] = new LiteralStackNode<IConstructor>(2142, 4, cHJvZChsaXQoIjsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU5LDU5KV0pXSx7fSk00, new int[] {59}, null, null);
      tmp[2] = new SeparatedListStackNode<IConstructor>(2139, 2, cmVndWxhcihcaXRlci1zZXBzKHNvcnQoIkluaXREZWNsYXJhdG9yIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSk00, new NonTerminalStackNode<IConstructor>(2135, 0, "InitDeclarator", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(2136, 1, "layouts_LAYOUTLIST", null, null), new LiteralStackNode<IConstructor>(2137, 2, cHJvZChsaXQoIiwiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pXSx7fSk00, new int[] {44}, null, null), new NonTerminalStackNode<IConstructor>(2138, 3, "layouts_LAYOUTLIST", null, null)}, true, null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(2141, 3, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new SeparatedListStackNode<IConstructor>(2132, 0, cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiU3BlY2lmaWVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pKQ0000, new NonTerminalStackNode<IConstructor>(2130, 0, "Specifier", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(2131, 1, "layouts_LAYOUTLIST", null, null)}, false, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiZ2xvYmFsRGVjbGFyYXRpb25XaXRoSW5pdERlY2xzIixzb3J0KCJHbG9iYWxEZWNsYXJhdGlvbiIpKSxbbGFiZWwoInNwZWNzMCIsXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJpbml0RGVjbGFyYXRvcnMiLFxpdGVyLXNlcHMoc29ydCgiSW5pdERlY2xhcmF0b3IiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiLCIpLGxheW91dHMoIkxBWU9VVExJU1QiKV0pKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI7IildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiZ2xvYmFsRGVjbGFyYXRpb25XaXRob3V0SW5pdERlY2xzIixzb3J0KCJHbG9iYWxEZWNsYXJhdGlvbiIpKSxbbGFiZWwoInNwZWNzMSIsXGl0ZXItc2Vwcyhzb3J0KCJTcGVjaWZpZXIiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(2149, 1, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new SeparatedListStackNode<IConstructor>(2147, 0, cmVndWxhcihcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSk00, new NonTerminalStackNode<IConstructor>(2145, 0, "Specifier", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(2146, 1, "layouts_LAYOUTLIST", null, null)}, true, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(2150, 2, cHJvZChsaXQoIjsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU5LDU5KV0pXSx7fSk00, new int[] {59}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiZ2xvYmFsRGVjbGFyYXRpb25XaXRob3V0SW5pdERlY2xzIixzb3J0KCJHbG9iYWxEZWNsYXJhdGlvbiIpKSxbbGFiZWwoInNwZWNzMSIsXGl0ZXItc2Vwcyhzb3J0KCJTcGVjaWZpZXIiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJHbG9iYWxEZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJHbG9iYWxEZWNsYXJhdGlvblwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiR2xvYmFsRGVjbGFyYXRpb24iKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new CharStackNode<IConstructor>(2158, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(2155, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(2154, 1, cHJvZChsaXQoInNvcnQoXCJHbG9iYWxEZWNsYXJhdGlvblwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg3MSw3MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTgsOTgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2OCw2OCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {115,111,114,116,40,34,71,108,111,98,97,108,68,101,99,108,97,114,97,116,105,111,110,34,41}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(2153, 0, new int[][]{{0,0}}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(2157, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(2156, 0, new int[][]{{48,57}}, null, null), true, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJHbG9iYWxEZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJHbG9iYWxEZWNsYXJhdGlvblwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiR2xvYmFsRGVjbGFyYXRpb24iKSkpfSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiZ2xvYmFsRGVjbGFyYXRpb25XaXRoSW5pdERlY2xzIixzb3J0KCJHbG9iYWxEZWNsYXJhdGlvbiIpKSxbbGFiZWwoInNwZWNzMCIsXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxhYmVsKCJpbml0RGVjbGFyYXRvcnMiLFxpdGVyLXNlcHMoc29ydCgiSW5pdERlY2xhcmF0b3IiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiLCIpLGxheW91dHMoIkxBWU9VVExJU1QiKV0pKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI7IildLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiZ2xvYmFsRGVjbGFyYXRpb25XaXRob3V0SW5pdERlY2xzIixzb3J0KCJHbG9iYWxEZWNsYXJhdGlvbiIpKSxbbGFiZWwoInNwZWNzMSIsXGl0ZXItc2Vwcyhzb3J0KCJTcGVjaWZpZXIiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKV0se30p(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJHbG9iYWxEZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJHbG9iYWxEZWNsYXJhdGlvblwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiR2xvYmFsRGVjbGFyYXRpb24iKSkpfSk00(builder);
      
    }
  }
	
  protected static class AnonymousIdentifier {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJBbm9ueW1vdXNJZGVudGlmaWVyIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkFub255bW91c0lkZW50aWZpZXJcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIkFub255bW91c0lkZW50aWZpZXIiKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new CharStackNode<IConstructor>(2227, 0, new int[][]{{0,0}}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(2232, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(2229, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(2231, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(2230, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(2228, 1, cHJvZChsaXQoInNvcnQoXCJBbm9ueW1vdXNJZGVudGlmaWVyXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY1LDY1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjEsMTIxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg3Myw3MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAwLDEwMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAyLDEwMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {115,111,114,116,40,34,65,110,111,110,121,109,111,117,115,73,100,101,110,116,105,102,105,101,114,34,41}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJBbm9ueW1vdXNJZGVudGlmaWVyIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkFub255bW91c0lkZW50aWZpZXJcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIkFub255bW91c0lkZW50aWZpZXIiKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJBbm9ueW1vdXNJZGVudGlmaWVyIiksW10se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new EpsilonStackNode<IConstructor>(2234, 0);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJBbm9ueW1vdXNJZGVudGlmaWVyIiksW10se30p, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJBbm9ueW1vdXNJZGVudGlmaWVyIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkFub255bW91c0lkZW50aWZpZXJcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIkFub255bW91c0lkZW50aWZpZXIiKSkpfSk00(builder);
      
        _init_cHJvZChzb3J0KCJBbm9ueW1vdXNJZGVudGlmaWVyIiksW10se30p(builder);
      
    }
  }
	
  protected static class Parameter {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChzb3J0KCJQYXJhbWV0ZXIiKSxbXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRGVjbGFyYXRvciIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[2] = new NonTerminalStackNode<IConstructor>(2330, 2, "Declarator", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(2329, 1, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new SeparatedListStackNode<IConstructor>(2328, 0, cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiU3BlY2lmaWVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pKQ0000, new NonTerminalStackNode<IConstructor>(2326, 0, "Specifier", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(2327, 1, "layouts_LAYOUTLIST", null, null)}, false, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJQYXJhbWV0ZXIiKSxbXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRGVjbGFyYXRvciIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQYXJhbWV0ZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiUGFyYW1ldGVyXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJQYXJhbWV0ZXIiKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new CharStackNode<IConstructor>(2338, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(2335, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(2337, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(2336, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[0] = new CharStackNode<IConstructor>(2333, 0, new int[][]{{0,0}}, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(2334, 1, cHJvZChsaXQoInNvcnQoXCJQYXJhbWV0ZXJcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODAsODApXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA5LDEwOSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {115,111,114,116,40,34,80,97,114,97,109,101,116,101,114,34,41}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQYXJhbWV0ZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiUGFyYW1ldGVyXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJQYXJhbWV0ZXIiKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQYXJhbWV0ZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc2Vwcyhzb3J0KFwiUGFyYW1ldGVyXCIpLFtsaXQoXCIsXCIpXSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXNlcHMoc29ydCgiUGFyYW1ldGVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new CharStackNode<IConstructor>(2347, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(2344, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(2342, 0, new int[][]{{0,0}}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(2346, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(2345, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(2343, 1, cHJvZChsaXQoIlxcaXRlci1zZXBzKHNvcnQoXCJQYXJhbWV0ZXJcIiksW2xpdChcIixcIildKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoOTIsOTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ1LDQ1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4MCw4MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5MSw5MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Myw5MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000, new int[] {92,105,116,101,114,45,115,101,112,115,40,115,111,114,116,40,34,80,97,114,97,109,101,116,101,114,34,41,44,91,108,105,116,40,34,44,34,41,93,41}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQYXJhbWV0ZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc2Vwcyhzb3J0KFwiUGFyYW1ldGVyXCIpLFtsaXQoXCIsXCIpXSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXNlcHMoc29ydCgiUGFyYW1ldGVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChzb3J0KCJQYXJhbWV0ZXIiKSxbXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRGVjbGFyYXRvciIpXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQYXJhbWV0ZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiUGFyYW1ldGVyXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJQYXJhbWV0ZXIiKSkpfSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQYXJhbWV0ZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc2Vwcyhzb3J0KFwiUGFyYW1ldGVyXCIpLFtsaXQoXCIsXCIpXSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXNlcHMoc29ydCgiUGFyYW1ldGVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(builder);
      
    }
  }
	
  protected static class Keyword {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImV4dGVybiIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2356, 0, cHJvZChsaXQoImV4dGVybiIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTIwLDEyMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKV0se30p, new int[] {101,120,116,101,114,110}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImV4dGVybiIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImludCIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2358, 0, cHJvZChsaXQoImludCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKV0se30p, new int[] {105,110,116}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImludCIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInNpZ25lZCIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2360, 0, cHJvZChsaXQoInNpZ25lZCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAzLDEwMyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAwLDEwMCldKV0se30p, new int[] {115,105,103,110,101,100}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInNpZ25lZCIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImNoYXIiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2362, 0, cHJvZChsaXQoImNoYXIiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDQsMTA0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKV0se30p, new int[] {99,104,97,114}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImNoYXIiKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImNvbnN0IildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2364, 0, cHJvZChsaXQoImNvbnN0IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKV0se30p, new int[] {99,111,110,115,116}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImNvbnN0IildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInR5cGVkZWYiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2366, 0, cHJvZChsaXQoInR5cGVkZWYiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEyMSwxMjEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMCwxMDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMiwxMDIpXSldLHt9KQ0000, new int[] {116,121,112,101,100,101,102}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInR5cGVkZWYiKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInJlZ2lzdGVyIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2368, 0, cHJvZChsaXQoInJlZ2lzdGVyIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pXSx7fSk00, new int[] {114,101,103,105,115,116,101,114}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInJlZ2lzdGVyIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInVuaW9uIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2370, 0, cHJvZChsaXQoInVuaW9uIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pXSx7fSk00, new int[] {117,110,105,111,110}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInVuaW9uIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInVuc2lnbmVkIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2372, 0, cHJvZChsaXQoInVuc2lnbmVkIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDAsMTAwKV0pXSx7fSk00, new int[] {117,110,115,105,103,110,101,100}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInVuc2lnbmVkIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImF1dG8iKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2374, 0, cHJvZChsaXQoImF1dG8iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pXSx7fSk00, new int[] {97,117,116,111}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImF1dG8iKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImdvdG8iKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2376, 0, cHJvZChsaXQoImdvdG8iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSldLHt9KQ0000, new int[] {103,111,116,111}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImdvdG8iKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImRvIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2378, 0, cHJvZChsaXQoImRvIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMDAsMTAwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pXSx7fSk00, new int[] {100,111}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImRvIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImNvbnRpbnVlIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2380, 0, cHJvZChsaXQoImNvbnRpbnVlIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE3LDExNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKV0se30p, new int[] {99,111,110,116,105,110,117,101}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImNvbnRpbnVlIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImZvciIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2382, 0, cHJvZChsaXQoImZvciIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTAyLDEwMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKV0se30p, new int[] {102,111,114}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImZvciIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImJyZWFrIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2384, 0, cHJvZChsaXQoImJyZWFrIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5OCw5OCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNywxMDcpXSldLHt9KQ0000, new int[] {98,114,101,97,107}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImJyZWFrIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInNob3J0IildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2386, 0, cHJvZChsaXQoInNob3J0IiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDQsMTA0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pXSx7fSk00, new int[] {115,104,111,114,116}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInNob3J0IildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImRvdWJsZSIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2388, 0, cHJvZChsaXQoImRvdWJsZSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTAwLDEwMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE3LDExNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTgsOTgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSldLHt9KQ0000, new int[] {100,111,117,98,108,101}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImRvdWJsZSIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInN0cnVjdCIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2390, 0, cHJvZChsaXQoInN0cnVjdCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE3LDExNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSldLHt9KQ0000, new int[] {115,116,114,117,99,116}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInN0cnVjdCIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImNhc2UiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2392, 0, cHJvZChsaXQoImNhc2UiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKV0se30p, new int[] {99,97,115,101}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImNhc2UiKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoIndoaWxlIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2394, 0, cHJvZChsaXQoIndoaWxlIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTksMTE5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDQsMTA0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pXSx7fSk00, new int[] {119,104,105,108,101}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoIndoaWxlIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInN3aXRjaCIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2396, 0, cHJvZChsaXQoInN3aXRjaCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE5LDExOSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNCwxMDQpXSldLHt9KQ0000, new int[] {115,119,105,116,99,104}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInN3aXRjaCIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImRlZmF1bHQiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2398, 0, cHJvZChsaXQoImRlZmF1bHQiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwMCwxMDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMiwxMDIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pXSx7fSk00, new int[] {100,101,102,97,117,108,116}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImRlZmF1bHQiKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImZsb2F0IildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2400, 0, cHJvZChsaXQoImZsb2F0IiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMDIsMTAyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKV0se30p, new int[] {102,108,111,97,116}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImZsb2F0IildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImxvbmciKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2402, 0, cHJvZChsaXQoImxvbmciKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSldLHt9KQ0000, new int[] {108,111,110,103}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImxvbmciKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInN0YXRpYyIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2404, 0, cHJvZChsaXQoInN0YXRpYyIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pXSx7fSk00, new int[] {115,116,97,116,105,99}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInN0YXRpYyIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInNpemVvZiIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2406, 0, cHJvZChsaXQoInNpemVvZiIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTIyLDEyMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAyLDEwMildKV0se30p, new int[] {115,105,122,101,111,102}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInNpemVvZiIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInZvbGF0aWxlIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2408, 0, cHJvZChsaXQoInZvbGF0aWxlIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTgsMTE4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKV0se30p, new int[] {118,111,108,97,116,105,108,101}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInZvbGF0aWxlIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInZvaWQiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2410, 0, cHJvZChsaXQoInZvaWQiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExOCwxMTgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMCwxMDApXSldLHt9KQ0000, new int[] {118,111,105,100}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInZvaWQiKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImVudW0iKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2412, 0, cHJvZChsaXQoImVudW0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNywxMTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSldLHt9KQ0000, new int[] {101,110,117,109}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImVudW0iKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImlmIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2414, 0, cHJvZChsaXQoImlmIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDIsMTAyKV0pXSx7fSk00, new int[] {105,102}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImlmIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInJldHVybiIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2416, 0, cHJvZChsaXQoInJldHVybiIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE3LDExNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKV0se30p, new int[] {114,101,116,117,114,110}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInJldHVybiIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImVsc2UiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2418, 0, cHJvZChsaXQoImVsc2UiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSldLHt9KQ0000, new int[] {101,108,115,101}, null, null);
      builder.addAlternative(CParser.cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImVsc2UiKV0se30p, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImV4dGVybiIpXSx7fSk00(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImludCIpXSx7fSk00(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInNpZ25lZCIpXSx7fSk00(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImNoYXIiKV0se30p(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImNvbnN0IildLHt9KQ0000(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInR5cGVkZWYiKV0se30p(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInJlZ2lzdGVyIildLHt9KQ0000(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInVuaW9uIildLHt9KQ0000(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInVuc2lnbmVkIildLHt9KQ0000(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImF1dG8iKV0se30p(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImdvdG8iKV0se30p(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImRvIildLHt9KQ0000(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImNvbnRpbnVlIildLHt9KQ0000(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImZvciIpXSx7fSk00(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImJyZWFrIildLHt9KQ0000(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInNob3J0IildLHt9KQ0000(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImRvdWJsZSIpXSx7fSk00(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInN0cnVjdCIpXSx7fSk00(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImNhc2UiKV0se30p(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoIndoaWxlIildLHt9KQ0000(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInN3aXRjaCIpXSx7fSk00(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImRlZmF1bHQiKV0se30p(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImZsb2F0IildLHt9KQ0000(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImxvbmciKV0se30p(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInN0YXRpYyIpXSx7fSk00(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInNpemVvZiIpXSx7fSk00(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInZvbGF0aWxlIildLHt9KQ0000(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInZvaWQiKV0se30p(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImVudW0iKV0se30p(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImlmIildLHt9KQ0000(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoInJldHVybiIpXSx7fSk00(builder);
      
        _init_cHJvZChrZXl3b3JkcygiS2V5d29yZCIpLFtsaXQoImVsc2UiKV0se30p(builder);
      
    }
  }
	
  protected static class FunctionDefinition {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJGdW5jdGlvbkRlZmluaXRpb24iKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiRnVuY3Rpb25EZWZpbml0aW9uXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJGdW5jdGlvbkRlZmluaXRpb24iKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new ListStackNode<IConstructor>(2784, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(2783, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[0] = new CharStackNode<IConstructor>(2780, 0, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(2782, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(2781, 1, cHJvZChsaXQoInNvcnQoXCJGdW5jdGlvbkRlZmluaXRpb25cIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNzAsNzApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNywxMTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2OCw2OCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAyLDEwMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {115,111,114,116,40,34,70,117,110,99,116,105,111,110,68,101,102,105,110,105,116,105,111,110,34,41}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(2785, 4, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJGdW5jdGlvbkRlZmluaXRpb24iKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiRnVuY3Rpb25EZWZpbml0aW9uXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJGdW5jdGlvbkRlZmluaXRpb24iKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiZGVmYXVsdEZ1bmN0aW9uRGVmaW5pdGlvbiIsc29ydCgiRnVuY3Rpb25EZWZpbml0aW9uIikpLFtsYWJlbCgic3BlY3MiLFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJTcGVjaWZpZXIiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJEZWNsYXJhdG9yIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJEZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ7IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJEZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0YXRlbWVudCIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ9IildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[13];
      
      tmp[12] = new LiteralStackNode<IConstructor>(2810, 12, cHJvZChsaXQoIn0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEyNSwxMjUpXSldLHt9KQ0000, new int[] {125}, null, null);
      tmp[4] = new SeparatedListStackNode<IConstructor>(2798, 4, cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiRGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkp, new NonTerminalStackNode<IConstructor>(2796, 0, "Declaration", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(2797, 1, "layouts_LAYOUTLIST", null, null)}, false, null, null);
      tmp[6] = new LiteralStackNode<IConstructor>(2800, 6, cHJvZChsaXQoInsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEyMywxMjMpXSldLHt9KQ0000, new int[] {123}, null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(2794, 2, "Declarator", null, null);
      tmp[7] = new NonTerminalStackNode<IConstructor>(2801, 7, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new SeparatedListStackNode<IConstructor>(2791, 0, cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiU3BlY2lmaWVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pKQ0000, new NonTerminalStackNode<IConstructor>(2789, 0, "Specifier", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(2790, 1, "layouts_LAYOUTLIST", null, null)}, false, null, null);
      tmp[10] = new SeparatedListStackNode<IConstructor>(2808, 10, cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RhdGVtZW50IiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pKQ0000, new NonTerminalStackNode<IConstructor>(2806, 0, "Statement", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(2807, 1, "layouts_LAYOUTLIST", null, null)}, false, null, null);
      tmp[9] = new NonTerminalStackNode<IConstructor>(2805, 9, "layouts_LAYOUTLIST", null, null);
      tmp[11] = new NonTerminalStackNode<IConstructor>(2809, 11, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(2795, 3, "layouts_LAYOUTLIST", null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(2799, 5, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(2793, 1, "layouts_LAYOUTLIST", null, null);
      tmp[8] = new SeparatedListStackNode<IConstructor>(2804, 8, cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiRGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkp, new NonTerminalStackNode<IConstructor>(2802, 0, "Declaration", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(2803, 1, "layouts_LAYOUTLIST", null, null)}, false, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiZGVmYXVsdEZ1bmN0aW9uRGVmaW5pdGlvbiIsc29ydCgiRnVuY3Rpb25EZWZpbml0aW9uIikpLFtsYWJlbCgic3BlY3MiLFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJTcGVjaWZpZXIiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJEZWNsYXJhdG9yIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJEZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ7IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJEZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0YXRlbWVudCIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ9IildLHt9KQ0000, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJGdW5jdGlvbkRlZmluaXRpb24iKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiRnVuY3Rpb25EZWZpbml0aW9uXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJGdW5jdGlvbkRlZmluaXRpb24iKSkpfSk00(builder);
      
        _init_cHJvZChsYWJlbCgiZGVmYXVsdEZ1bmN0aW9uRGVmaW5pdGlvbiIsc29ydCgiRnVuY3Rpb25EZWZpbml0aW9uIikpLFtsYWJlbCgic3BlY3MiLFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJTcGVjaWZpZXIiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJEZWNsYXJhdG9yIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJEZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ7IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJEZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0YXRlbWVudCIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ9IildLHt9KQ0000(builder);
      
    }
  }
	
  protected static class Parameters {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQYXJhbWV0ZXJzIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgib3B0KHNvcnQoXCJQYXJhbWV0ZXJzXCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIob3B0KHNvcnQoIlBhcmFtZXRlcnMiKSkpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new LiteralStackNode<IConstructor>(2907, 1, cHJvZChsaXQoIm9wdChzb3J0KFwiUGFyYW1ldGVyc1wiKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDgwLDgwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000, new int[] {111,112,116,40,115,111,114,116,40,34,80,97,114,97,109,101,116,101,114,115,34,41,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(2910, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(2909, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(2908, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(2911, 4, new int[][]{{0,0}}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(2906, 0, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQYXJhbWV0ZXJzIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgib3B0KHNvcnQoXCJQYXJhbWV0ZXJzXCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIob3B0KHNvcnQoIlBhcmFtZXRlcnMiKSkpKX0p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJQYXJhbWV0ZXJzIiksW1xpdGVyLXNlcHMoc29ydCgiUGFyYW1ldGVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksb3B0KHNvcnQoIk1vcmVQYXJhbWV0ZXJzIikpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(2920, 1, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new SeparatedListStackNode<IConstructor>(2919, 0, cmVndWxhcihcaXRlci1zZXBzKHNvcnQoIlBhcmFtZXRlciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIsIiksbGF5b3V0cygiTEFZT1VUTElTVCIpXSkp, new NonTerminalStackNode<IConstructor>(2915, 0, "Parameter", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(2916, 1, "layouts_LAYOUTLIST", null, null), new LiteralStackNode<IConstructor>(2917, 2, cHJvZChsaXQoIiwiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pXSx7fSk00, new int[] {44}, null, null), new NonTerminalStackNode<IConstructor>(2918, 3, "layouts_LAYOUTLIST", null, null)}, true, null, null);
      tmp[2] = new OptionalStackNode<IConstructor>(2922, 2, cmVndWxhcihvcHQoc29ydCgiTW9yZVBhcmFtZXRlcnMiKSkp, new NonTerminalStackNode<IConstructor>(2921, 0, "MoreParameters", null, null), null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJQYXJhbWV0ZXJzIiksW1xpdGVyLXNlcHMoc29ydCgiUGFyYW1ldGVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksb3B0KHNvcnQoIk1vcmVQYXJhbWV0ZXJzIikpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQYXJhbWV0ZXJzIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlBhcmFtZXRlcnNcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlBhcmFtZXRlcnMiKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new ListStackNode<IConstructor>(2929, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(2928, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(2926, 1, cHJvZChsaXQoInNvcnQoXCJQYXJhbWV0ZXJzXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDgwLDgwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {115,111,114,116,40,34,80,97,114,97,109,101,116,101,114,115,34,41}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(2925, 0, new int[][]{{0,0}}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(2930, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(2927, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQYXJhbWV0ZXJzIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlBhcmFtZXRlcnNcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlBhcmFtZXRlcnMiKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJQYXJhbWV0ZXJzIiksW2xpdCgidm9pZCIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(2933, 0, cHJvZChsaXQoInZvaWQiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExOCwxMTgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMCwxMDApXSldLHt9KQ0000, new int[] {118,111,105,100}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJQYXJhbWV0ZXJzIiksW2xpdCgidm9pZCIpXSx7fSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQYXJhbWV0ZXJzIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgib3B0KHNvcnQoXCJQYXJhbWV0ZXJzXCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIob3B0KHNvcnQoIlBhcmFtZXRlcnMiKSkpKX0p(builder);
      
        _init_cHJvZChzb3J0KCJQYXJhbWV0ZXJzIiksW1xpdGVyLXNlcHMoc29ydCgiUGFyYW1ldGVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksb3B0KHNvcnQoIk1vcmVQYXJhbWV0ZXJzIikpXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQYXJhbWV0ZXJzIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlBhcmFtZXRlcnNcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlBhcmFtZXRlcnMiKSkpfSk00(builder);
      
        _init_cHJvZChzb3J0KCJQYXJhbWV0ZXJzIiksW2xpdCgidm9pZCIpXSx7fSk00(builder);
      
    }
  }
	
  protected static class IntegerConstant {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsZXgoIkludGVnZXJDb25zdGFudCIpLFtpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksY29uZGl0aW9uYWwoXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoNzYsNzYpLHJhbmdlKDg1LDg1KSxyYW5nZSgxMDgsMTA4KSxyYW5nZSgxMTcsMTE3KV0pKSx7XG5vdC1mb2xsb3coXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKX0pXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[2];
      
      tmp[1] = new ListStackNode<IConstructor>(3027, 1, cmVndWxhcihcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSg3Niw3NikscmFuZ2UoODUsODUpLHJhbmdlKDEwOCwxMDgpLHJhbmdlKDExNywxMTcpXSkpKQ0000, new CharStackNode<IConstructor>(3024, 0, new int[][]{{76,76},{85,85},{108,108},{117,117}}, null, null), false, null, new ICompletionFilter[] {new CharFollowRestriction(new int[][]{{48,57}})});
      tmp[0] = new ListStackNode<IConstructor>(3023, 0, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(3022, 0, new int[][]{{48,57}}, null, null), true, null, null);
      builder.addAlternative(CParser.cHJvZChsZXgoIkludGVnZXJDb25zdGFudCIpLFtpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksY29uZGl0aW9uYWwoXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoNzYsNzYpLHJhbmdlKDg1LDg1KSxyYW5nZSgxMDgsMTA4KSxyYW5nZSgxMTcsMTE3KV0pKSx7XG5vdC1mb2xsb3coXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKX0pXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkludGVnZXJDb25zdGFudCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJJbnRlZ2VyQ29uc3RhbnRcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGxleCgiSW50ZWdlckNvbnN0YW50IikpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new LiteralStackNode<IConstructor>(3031, 1, cHJvZChsaXQoInNvcnQoXCJJbnRlZ2VyQ29uc3RhbnRcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNzMsNzMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY3LDY3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {115,111,114,116,40,34,73,110,116,101,103,101,114,67,111,110,115,116,97,110,116,34,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(3034, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(3033, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[0] = new CharStackNode<IConstructor>(3030, 0, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3032, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(3035, 4, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkludGVnZXJDb25zdGFudCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJJbnRlZ2VyQ29uc3RhbnRcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGxleCgiSW50ZWdlckNvbnN0YW50IikpKX0p, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsZXgoIkludGVnZXJDb25zdGFudCIpLFtpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksY29uZGl0aW9uYWwoXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoNzYsNzYpLHJhbmdlKDg1LDg1KSxyYW5nZSgxMDgsMTA4KSxyYW5nZSgxMTcsMTE3KV0pKSx7XG5vdC1mb2xsb3coXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKX0pXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkludGVnZXJDb25zdGFudCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJJbnRlZ2VyQ29uc3RhbnRcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGxleCgiSW50ZWdlckNvbnN0YW50IikpKX0p(builder);
      
    }
  }
	
  protected static class FunctionPrototype {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJGdW5jdGlvblByb3RvdHlwZSIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJGdW5jdGlvblByb3RvdHlwZVwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiRnVuY3Rpb25Qcm90b3R5cGUiKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new CharStackNode<IConstructor>(3046, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3043, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(3041, 0, new int[][]{{0,0}}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(3045, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(3044, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(3042, 1, cHJvZChsaXQoInNvcnQoXCJGdW5jdGlvblByb3RvdHlwZVwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg3MCw3MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE3LDExNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDgwLDgwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjEsMTIxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000, new int[] {115,111,114,116,40,34,70,117,110,99,116,105,111,110,80,114,111,116,111,116,121,112,101,34,41}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJGdW5jdGlvblByb3RvdHlwZSIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJGdW5jdGlvblByb3RvdHlwZVwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiRnVuY3Rpb25Qcm90b3R5cGUiKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiZGVmYXVsdEZ1bmN0aW9uUHJvdG90eXBlIixzb3J0KCJGdW5jdGlvblByb3RvdHlwZSIpKSxbbGFiZWwoInNwZWNzIixcaXRlci1zdGFyLXNlcHMoc29ydCgiU3BlY2lmaWVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGFiZWwoImRlY2wiLHNvcnQoIlByb3RvdHlwZURlY2xhcmF0b3IiKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOyIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new SeparatedListStackNode<IConstructor>(3052, 0, cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiU3BlY2lmaWVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pKQ0000, new NonTerminalStackNode<IConstructor>(3050, 0, "Specifier", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(3051, 1, "layouts_LAYOUTLIST", null, null)}, false, null, null);
      tmp[4] = new LiteralStackNode<IConstructor>(3058, 4, cHJvZChsaXQoIjsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU5LDU5KV0pXSx7fSk00, new int[] {59}, null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(3055, 2, "PrototypeDeclarator", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(3057, 3, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(3054, 1, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiZGVmYXVsdEZ1bmN0aW9uUHJvdG90eXBlIixzb3J0KCJGdW5jdGlvblByb3RvdHlwZSIpKSxbbGFiZWwoInNwZWNzIixcaXRlci1zdGFyLXNlcHMoc29ydCgiU3BlY2lmaWVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGFiZWwoImRlY2wiLHNvcnQoIlByb3RvdHlwZURlY2xhcmF0b3IiKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOyIpXSx7fSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJGdW5jdGlvblByb3RvdHlwZSIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJGdW5jdGlvblByb3RvdHlwZVwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiRnVuY3Rpb25Qcm90b3R5cGUiKSkpfSk00(builder);
      
        _init_cHJvZChsYWJlbCgiZGVmYXVsdEZ1bmN0aW9uUHJvdG90eXBlIixzb3J0KCJGdW5jdGlvblByb3RvdHlwZSIpKSxbbGFiZWwoInNwZWNzIixcaXRlci1zdGFyLXNlcHMoc29ydCgiU3BlY2lmaWVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGFiZWwoImRlY2wiLHNvcnQoIlByb3RvdHlwZURlY2xhcmF0b3IiKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOyIpXSx7fSk00(builder);
      
    }
  }
	
  protected static class MultiLineCommentBodyToken {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsZXgoIk11bHRpTGluZUNvbW1lbnRCb2R5VG9rZW4iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEsNDEpLHJhbmdlKDQzLDE2Nzc3MjE1KV0pXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new CharStackNode<IConstructor>(3122, 0, new int[][]{{1,41},{43,16777215}}, null, null);
      builder.addAlternative(CParser.cHJvZChsZXgoIk11bHRpTGluZUNvbW1lbnRCb2R5VG9rZW4iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEsNDEpLHJhbmdlKDQzLDE2Nzc3MjE1KV0pXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsZXgoIk11bHRpTGluZUNvbW1lbnRCb2R5VG9rZW4iKSxbbGV4KCJBc3RlcmlzayIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(3124, 0, "Asterisk", null, null);
      builder.addAlternative(CParser.cHJvZChsZXgoIk11bHRpTGluZUNvbW1lbnRCb2R5VG9rZW4iKSxbbGV4KCJBc3RlcmlzayIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIk11bHRpTGluZUNvbW1lbnRCb2R5VG9rZW4iKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiTXVsdGlMaW5lQ29tbWVudEJvZHlUb2tlblwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIobGV4KCJNdWx0aUxpbmVDb21tZW50Qm9keVRva2VuIikpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new CharStackNode<IConstructor>(3132, 4, new int[][]{{0,0}}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(3131, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(3130, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(3128, 1, cHJvZChsaXQoInNvcnQoXCJNdWx0aUxpbmVDb21tZW50Qm9keVRva2VuXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDc3LDc3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg3Niw3NildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjcsNjcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY2LDY2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDAsMTAwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjEsMTIxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4NCw4NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA3LDEwNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {115,111,114,116,40,34,77,117,108,116,105,76,105,110,101,67,111,109,109,101,110,116,66,111,100,121,84,111,107,101,110,34,41}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3129, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(3127, 0, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIk11bHRpTGluZUNvbW1lbnRCb2R5VG9rZW4iKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiTXVsdGlMaW5lQ29tbWVudEJvZHlUb2tlblwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIobGV4KCJNdWx0aUxpbmVDb21tZW50Qm9keVRva2VuIikpKX0p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIk11bHRpTGluZUNvbW1lbnRCb2R5VG9rZW4iKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc3Rhcihzb3J0KFwiTXVsdGlMaW5lQ29tbWVudEJvZHlUb2tlblwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXN0YXIobGV4KCJNdWx0aUxpbmVDb21tZW50Qm9keVRva2VuIikpKSl9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new CharStackNode<IConstructor>(3141, 4, new int[][]{{0,0}}, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(3137, 1, cHJvZChsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJNdWx0aUxpbmVDb21tZW50Qm9keVRva2VuXCIpKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoOTIsOTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ1LDQ1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNzcsNzcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNywxMTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDc2LDc2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2Nyw2NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA5LDEwOSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA5LDEwOSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjYsNjYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMCwxMDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEyMSwxMjEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDg0LDg0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDcsMTA3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {92,105,116,101,114,45,115,116,97,114,40,115,111,114,116,40,34,77,117,108,116,105,76,105,110,101,67,111,109,109,101,110,116,66,111,100,121,84,111,107,101,110,34,41,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(3140, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(3139, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[0] = new CharStackNode<IConstructor>(3136, 0, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3138, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIk11bHRpTGluZUNvbW1lbnRCb2R5VG9rZW4iKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc3Rhcihzb3J0KFwiTXVsdGlMaW5lQ29tbWVudEJvZHlUb2tlblwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXN0YXIobGV4KCJNdWx0aUxpbmVDb21tZW50Qm9keVRva2VuIikpKSl9KQ0000, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsZXgoIk11bHRpTGluZUNvbW1lbnRCb2R5VG9rZW4iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEsNDEpLHJhbmdlKDQzLDE2Nzc3MjE1KV0pXSx7fSk00(builder);
      
        _init_cHJvZChsZXgoIk11bHRpTGluZUNvbW1lbnRCb2R5VG9rZW4iKSxbbGV4KCJBc3RlcmlzayIpXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIk11bHRpTGluZUNvbW1lbnRCb2R5VG9rZW4iKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiTXVsdGlMaW5lQ29tbWVudEJvZHlUb2tlblwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIobGV4KCJNdWx0aUxpbmVDb21tZW50Qm9keVRva2VuIikpKX0p(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIk11bHRpTGluZUNvbW1lbnRCb2R5VG9rZW4iKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc3Rhcihzb3J0KFwiTXVsdGlMaW5lQ29tbWVudEJvZHlUb2tlblwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXN0YXIobGV4KCJNdWx0aUxpbmVDb21tZW50Qm9keVRva2VuIikpKSl9KQ0000(builder);
      
    }
  }
	
  protected static class StringConstantContent {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIlN0cmluZ0NvbnN0YW50Q29udGVudCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJTdHJpbmdDb25zdGFudENvbnRlbnRcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGxleCgiU3RyaW5nQ29uc3RhbnRDb250ZW50IikpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new LiteralStackNode<IConstructor>(3273, 1, cHJvZChsaXQoInNvcnQoXCJTdHJpbmdDb25zdGFudENvbnRlbnRcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODMsODMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY3LDY3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjcsNjcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {115,111,114,116,40,34,83,116,114,105,110,103,67,111,110,115,116,97,110,116,67,111,110,116,101,110,116,34,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(3276, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(3275, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[0] = new CharStackNode<IConstructor>(3272, 0, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3274, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(3277, 4, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIlN0cmluZ0NvbnN0YW50Q29udGVudCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJTdHJpbmdDb25zdGFudENvbnRlbnRcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGxleCgiU3RyaW5nQ29uc3RhbnRDb250ZW50IikpKX0p, tmp);
	}
    protected static final void _init_cHJvZChsZXgoIlN0cmluZ0NvbnN0YW50Q29udGVudCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoOTIsOTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEsMTY3NzcyMTUpXSldLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[2];
      
      tmp[0] = new CharStackNode<IConstructor>(3280, 0, new int[][]{{92,92}}, null, null);
      tmp[1] = new CharStackNode<IConstructor>(3281, 1, new int[][]{{1,16777215}}, null, null);
      builder.addAlternative(CParser.cHJvZChsZXgoIlN0cmluZ0NvbnN0YW50Q29udGVudCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoOTIsOTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEsMTY3NzcyMTUpXSldLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsZXgoIlN0cmluZ0NvbnN0YW50Q29udGVudCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMSwzMykscmFuZ2UoMzUsOTEpLHJhbmdlKDkzLDE2Nzc3MjE1KV0pXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new CharStackNode<IConstructor>(3283, 0, new int[][]{{1,33},{35,91},{93,16777215}}, null, null);
      builder.addAlternative(CParser.cHJvZChsZXgoIlN0cmluZ0NvbnN0YW50Q29udGVudCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMSwzMykscmFuZ2UoMzUsOTEpLHJhbmdlKDkzLDE2Nzc3MjE1KV0pXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIlN0cmluZ0NvbnN0YW50Q29udGVudCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJTdHJpbmdDb25zdGFudENvbnRlbnRcIikpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zdGFyKGxleCgiU3RyaW5nQ29uc3RhbnRDb250ZW50IikpKSl9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new CharStackNode<IConstructor>(3286, 0, new int[][]{{0,0}}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(3291, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3288, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(3290, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(3289, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(3287, 1, cHJvZChsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJTdHJpbmdDb25zdGFudENvbnRlbnRcIikpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4Myw4MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAzLDEwMyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjcsNjcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2Nyw2NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {92,105,116,101,114,45,115,116,97,114,40,115,111,114,116,40,34,83,116,114,105,110,103,67,111,110,115,116,97,110,116,67,111,110,116,101,110,116,34,41,41}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIlN0cmluZ0NvbnN0YW50Q29udGVudCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJTdHJpbmdDb25zdGFudENvbnRlbnRcIikpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zdGFyKGxleCgiU3RyaW5nQ29uc3RhbnRDb250ZW50IikpKSl9KQ0000, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIlN0cmluZ0NvbnN0YW50Q29udGVudCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJTdHJpbmdDb25zdGFudENvbnRlbnRcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGxleCgiU3RyaW5nQ29uc3RhbnRDb250ZW50IikpKX0p(builder);
      
        _init_cHJvZChsZXgoIlN0cmluZ0NvbnN0YW50Q29udGVudCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoOTIsOTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEsMTY3NzcyMTUpXSldLHt9KQ0000(builder);
      
        _init_cHJvZChsZXgoIlN0cmluZ0NvbnN0YW50Q29udGVudCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMSwzMykscmFuZ2UoMzUsOTEpLHJhbmdlKDkzLDE2Nzc3MjE1KV0pXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIlN0cmluZ0NvbnN0YW50Q29udGVudCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJTdHJpbmdDb25zdGFudENvbnRlbnRcIikpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zdGFyKGxleCgiU3RyaW5nQ29uc3RhbnRDb250ZW50IikpKSl9KQ0000(builder);
      
    }
  }
	
  protected static class PrototypeParameters {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXJzIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgib3B0KHNvcnQoXCJQcm90b3R5cGVQYXJhbWV0ZXJzXCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIob3B0KHNvcnQoIlByb3RvdHlwZVBhcmFtZXRlcnMiKSkpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new LiteralStackNode<IConstructor>(3320, 1, cHJvZChsaXQoIm9wdChzb3J0KFwiUHJvdG90eXBlUGFyYW1ldGVyc1wiKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDgwLDgwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjEsMTIxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4MCw4MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {111,112,116,40,115,111,114,116,40,34,80,114,111,116,111,116,121,112,101,80,97,114,97,109,101,116,101,114,115,34,41,41}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3321, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(3323, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(3322, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[4] = new CharStackNode<IConstructor>(3324, 4, new int[][]{{0,0}}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(3319, 0, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXJzIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgib3B0KHNvcnQoXCJQcm90b3R5cGVQYXJhbWV0ZXJzXCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIob3B0KHNvcnQoIlByb3RvdHlwZVBhcmFtZXRlcnMiKSkpKX0p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXJzIiksW1xpdGVyLXNlcHMoc29ydCgiUHJvdG90eXBlUGFyYW1ldGVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksb3B0KHNvcnQoIk1vcmVQYXJhbWV0ZXJzIikpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[2] = new OptionalStackNode<IConstructor>(3335, 2, cmVndWxhcihvcHQoc29ydCgiTW9yZVBhcmFtZXRlcnMiKSkp, new NonTerminalStackNode<IConstructor>(3334, 0, "MoreParameters", null, null), null, null);
      tmp[0] = new SeparatedListStackNode<IConstructor>(3332, 0, cmVndWxhcihcaXRlci1zZXBzKHNvcnQoIlByb3RvdHlwZVBhcmFtZXRlciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIsIiksbGF5b3V0cygiTEFZT1VUTElTVCIpXSkp, new NonTerminalStackNode<IConstructor>(3328, 0, "PrototypeParameter", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(3329, 1, "layouts_LAYOUTLIST", null, null), new LiteralStackNode<IConstructor>(3330, 2, cHJvZChsaXQoIiwiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pXSx7fSk00, new int[] {44}, null, null), new NonTerminalStackNode<IConstructor>(3331, 3, "layouts_LAYOUTLIST", null, null)}, true, null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(3333, 1, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXJzIiksW1xpdGVyLXNlcHMoc29ydCgiUHJvdG90eXBlUGFyYW1ldGVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksb3B0KHNvcnQoIk1vcmVQYXJhbWV0ZXJzIikpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXJzIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlByb3RvdHlwZVBhcmFtZXRlcnNcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlByb3RvdHlwZVBhcmFtZXRlcnMiKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new LiteralStackNode<IConstructor>(3339, 1, cHJvZChsaXQoInNvcnQoXCJQcm90b3R5cGVQYXJhbWV0ZXJzXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDgwLDgwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjEsMTIxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4MCw4MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000, new int[] {115,111,114,116,40,34,80,114,111,116,111,116,121,112,101,80,97,114,97,109,101,116,101,114,115,34,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(3342, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(3341, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3340, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(3338, 0, new int[][]{{0,0}}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(3343, 4, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXJzIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlByb3RvdHlwZVBhcmFtZXRlcnNcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlByb3RvdHlwZVBhcmFtZXRlcnMiKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXJzIiksW2xpdCgidm9pZCIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(3346, 0, cHJvZChsaXQoInZvaWQiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExOCwxMTgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMCwxMDApXSldLHt9KQ0000, new int[] {118,111,105,100}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXJzIiksW2xpdCgidm9pZCIpXSx7fSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXJzIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgib3B0KHNvcnQoXCJQcm90b3R5cGVQYXJhbWV0ZXJzXCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIob3B0KHNvcnQoIlByb3RvdHlwZVBhcmFtZXRlcnMiKSkpKX0p(builder);
      
        _init_cHJvZChzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXJzIiksW1xpdGVyLXNlcHMoc29ydCgiUHJvdG90eXBlUGFyYW1ldGVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksb3B0KHNvcnQoIk1vcmVQYXJhbWV0ZXJzIikpXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXJzIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlByb3RvdHlwZVBhcmFtZXRlcnNcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlByb3RvdHlwZVBhcmFtZXRlcnMiKSkpfSk00(builder);
      
        _init_cHJvZChzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXJzIiksW2xpdCgidm9pZCIpXSx7fSk00(builder);
      
    }
  }
	
  protected static class Statement {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbc29ydCgiRXhwcmVzc2lvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(3509, 1, "layouts_LAYOUTLIST", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3510, 2, cHJvZChsaXQoIjsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU5LDU5KV0pXSx7fSk00, new int[] {59}, null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(3508, 0, "Expression", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbc29ydCgiRXhwcmVzc2lvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJ7IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJEZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0YXRlbWVudCIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ9IildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[7];
      
      tmp[5] = new NonTerminalStackNode<IConstructor>(3521, 5, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(3513, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(3517, 3, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(3512, 0, cHJvZChsaXQoInsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEyMywxMjMpXSldLHt9KQ0000, new int[] {123}, null, null);
      tmp[6] = new LiteralStackNode<IConstructor>(3522, 6, cHJvZChsaXQoIn0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEyNSwxMjUpXSldLHt9KQ0000, new int[] {125}, null, null);
      tmp[2] = new SeparatedListStackNode<IConstructor>(3516, 2, cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiRGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkp, new NonTerminalStackNode<IConstructor>(3514, 0, "Declaration", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(3515, 1, "layouts_LAYOUTLIST", null, null)}, false, null, null);
      tmp[4] = new SeparatedListStackNode<IConstructor>(3520, 4, cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RhdGVtZW50IiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pKQ0000, new NonTerminalStackNode<IConstructor>(3518, 0, "Statement", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(3519, 1, "layouts_LAYOUTLIST", null, null)}, false, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJ7IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJEZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0YXRlbWVudCIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ9IildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJjYXNlIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI6IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIlN0YXRlbWVudCIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[7];
      
      tmp[3] = new NonTerminalStackNode<IConstructor>(3527, 3, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(3525, 1, "layouts_LAYOUTLIST", null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(3529, 5, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(3524, 0, cHJvZChsaXQoImNhc2UiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKV0se30p, new int[] {99,97,115,101}, null, null);
      tmp[4] = new LiteralStackNode<IConstructor>(3528, 4, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[6] = new NonTerminalStackNode<IConstructor>(3530, 6, "Statement", null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(3526, 2, "Expression", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJjYXNlIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI6IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIlN0YXRlbWVudCIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJyZXR1cm4iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[2] = new NonTerminalStackNode<IConstructor>(3534, 2, "Expression", null, null);
      tmp[4] = new LiteralStackNode<IConstructor>(3536, 4, cHJvZChsaXQoIjsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU5LDU5KV0pXSx7fSk00, new int[] {59}, null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(3532, 0, cHJvZChsaXQoInJldHVybiIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE3LDExNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKV0se30p, new int[] {114,101,116,117,114,110}, null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(3533, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(3535, 3, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJyZXR1cm4iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGV4KCJJZGVudGlmaWVyIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJTdGF0ZW1lbnQiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new NonTerminalStackNode<IConstructor>(3542, 4, "Statement", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3540, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(3538, 0, "Identifier", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(3541, 3, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(3539, 1, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGV4KCJJZGVudGlmaWVyIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJTdGF0ZW1lbnQiKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJicmVhayIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[2] = new LiteralStackNode<IConstructor>(3546, 2, cHJvZChsaXQoIjsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU5LDU5KV0pXSx7fSk00, new int[] {59}, null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(3544, 0, cHJvZChsaXQoImJyZWFrIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5OCw5OCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNywxMDcpXSldLHt9KQ0000, new int[] {98,114,101,97,107}, null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(3545, 1, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJicmVhayIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCI7IildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(3548, 0, cHJvZChsaXQoIjsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU5LDU5KV0pXSx7fSk00, new int[] {59}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCI7IildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJjb250aW51ZSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[0] = new LiteralStackNode<IConstructor>(3550, 0, cHJvZChsaXQoImNvbnRpbnVlIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE3LDExNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKV0se30p, new int[] {99,111,110,116,105,110,117,101}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3552, 2, cHJvZChsaXQoIjsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU5LDU5KV0pXSx7fSk00, new int[] {59}, null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(3551, 1, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJjb250aW51ZSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJpZiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIigiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiU3RhdGVtZW50IildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[9];
      
      tmp[3] = new NonTerminalStackNode<IConstructor>(3557, 3, "layouts_LAYOUTLIST", null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(3559, 5, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(3555, 1, "layouts_LAYOUTLIST", null, null);
      tmp[7] = new NonTerminalStackNode<IConstructor>(3561, 7, "layouts_LAYOUTLIST", null, null);
      tmp[8] = new NonTerminalStackNode<IConstructor>(3562, 8, "Statement", null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(3558, 4, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3556, 2, cHJvZChsaXQoIigiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pXSx7fSk00, new int[] {40}, null, null);
      tmp[6] = new LiteralStackNode<IConstructor>(3560, 6, cHJvZChsaXQoIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {41}, null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(3554, 0, cHJvZChsaXQoImlmIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDIsMTAyKV0pXSx7fSk00, new int[] {105,102}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJpZiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIigiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiU3RhdGVtZW50IildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdGF0ZW1lbnQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc3Rhcihzb3J0KFwiU3RhdGVtZW50XCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0YXRlbWVudCIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new ListStackNode<IConstructor>(3569, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(3568, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(3566, 1, cHJvZChsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJTdGF0ZW1lbnRcIikpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4Myw4MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000, new int[] {92,105,116,101,114,45,115,116,97,114,40,115,111,114,116,40,34,83,116,97,116,101,109,101,110,116,34,41,41}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(3570, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3567, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(3565, 0, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdGF0ZW1lbnQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc3Rhcihzb3J0KFwiU3RhdGVtZW50XCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0YXRlbWVudCIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJ3aGlsZSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIigiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiU3RhdGVtZW50IildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[9];
      
      tmp[3] = new NonTerminalStackNode<IConstructor>(3578, 3, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(3576, 1, "layouts_LAYOUTLIST", null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(3580, 5, "layouts_LAYOUTLIST", null, null);
      tmp[7] = new NonTerminalStackNode<IConstructor>(3582, 7, "layouts_LAYOUTLIST", null, null);
      tmp[8] = new NonTerminalStackNode<IConstructor>(3583, 8, "Statement", null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(3579, 4, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3577, 2, cHJvZChsaXQoIigiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pXSx7fSk00, new int[] {40}, null, null);
      tmp[6] = new LiteralStackNode<IConstructor>(3581, 6, cHJvZChsaXQoIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {41}, null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(3575, 0, cHJvZChsaXQoIndoaWxlIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTksMTE5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDQsMTA0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pXSx7fSk00, new int[] {119,104,105,108,101}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJ3aGlsZSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIigiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiU3RhdGVtZW50IildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJnb3RvIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxleCgiSWRlbnRpZmllciIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(3586, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(3588, 3, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(3585, 0, cHJvZChsaXQoImdvdG8iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSldLHt9KQ0000, new int[] {103,111,116,111}, null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(3587, 2, "Identifier", null, null);
      tmp[4] = new LiteralStackNode<IConstructor>(3589, 4, cHJvZChsaXQoIjsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU5LDU5KV0pXSx7fSk00, new int[] {59}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJnb3RvIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxleCgiSWRlbnRpZmllciIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJkbyIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJTdGF0ZW1lbnQiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ3aGlsZSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIigiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI7IildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[13];
      
      tmp[8] = new NonTerminalStackNode<IConstructor>(3599, 8, "Expression", null, null);
      tmp[7] = new NonTerminalStackNode<IConstructor>(3598, 7, "layouts_LAYOUTLIST", null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(3596, 5, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(3592, 1, "layouts_LAYOUTLIST", null, null);
      tmp[11] = new NonTerminalStackNode<IConstructor>(3602, 11, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(3594, 3, "layouts_LAYOUTLIST", null, null);
      tmp[9] = new NonTerminalStackNode<IConstructor>(3600, 9, "layouts_LAYOUTLIST", null, null);
      tmp[10] = new LiteralStackNode<IConstructor>(3601, 10, cHJvZChsaXQoIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {41}, null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(3591, 0, cHJvZChsaXQoImRvIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMDAsMTAwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pXSx7fSk00, new int[] {100,111}, null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(3593, 2, "Statement", null, null);
      tmp[6] = new LiteralStackNode<IConstructor>(3597, 6, cHJvZChsaXQoIigiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pXSx7fSk00, new int[] {40}, null, null);
      tmp[4] = new LiteralStackNode<IConstructor>(3595, 4, cHJvZChsaXQoIndoaWxlIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTksMTE5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDQsMTA0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pXSx7fSk00, new int[] {119,104,105,108,101}, null, null);
      tmp[12] = new LiteralStackNode<IConstructor>(3603, 12, cHJvZChsaXQoIjsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU5LDU5KV0pXSx7fSk00, new int[] {59}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJkbyIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJTdGF0ZW1lbnQiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ3aGlsZSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIigiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI7IildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJmb3IiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLG9wdChzb3J0KCJFeHByZXNzaW9uIikpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksb3B0KHNvcnQoIkV4cHJlc3Npb24iKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOyIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxvcHQoc29ydCgiRXhwcmVzc2lvbiIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIpIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIlN0YXRlbWVudCIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[17];
      
      tmp[13] = new NonTerminalStackNode<IConstructor>(3621, 13, "layouts_LAYOUTLIST", null, null);
      tmp[15] = new NonTerminalStackNode<IConstructor>(3623, 15, "layouts_LAYOUTLIST", null, null);
      tmp[8] = new OptionalStackNode<IConstructor>(3615, 8, cmVndWxhcihvcHQoc29ydCgiRXhwcmVzc2lvbiIpKSk00, new NonTerminalStackNode<IConstructor>(3614, 0, "Expression", null, null), null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(3608, 3, "layouts_LAYOUTLIST", null, null);
      tmp[11] = new NonTerminalStackNode<IConstructor>(3618, 11, "layouts_LAYOUTLIST", null, null);
      tmp[7] = new NonTerminalStackNode<IConstructor>(3613, 7, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(3606, 1, "layouts_LAYOUTLIST", null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(3611, 5, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(3605, 0, cHJvZChsaXQoImZvciIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTAyLDEwMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKV0se30p, new int[] {102,111,114}, null, null);
      tmp[10] = new LiteralStackNode<IConstructor>(3617, 10, cHJvZChsaXQoIjsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU5LDU5KV0pXSx7fSk00, new int[] {59}, null, null);
      tmp[16] = new NonTerminalStackNode<IConstructor>(3624, 16, "Statement", null, null);
      tmp[9] = new NonTerminalStackNode<IConstructor>(3616, 9, "layouts_LAYOUTLIST", null, null);
      tmp[4] = new OptionalStackNode<IConstructor>(3610, 4, cmVndWxhcihvcHQoc29ydCgiRXhwcmVzc2lvbiIpKSk00, new NonTerminalStackNode<IConstructor>(3609, 0, "Expression", null, null), null, null);
      tmp[14] = new LiteralStackNode<IConstructor>(3622, 14, cHJvZChsaXQoIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {41}, null, null);
      tmp[12] = new OptionalStackNode<IConstructor>(3620, 12, cmVndWxhcihvcHQoc29ydCgiRXhwcmVzc2lvbiIpKSk00, new NonTerminalStackNode<IConstructor>(3619, 0, "Expression", null, null), null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3607, 2, cHJvZChsaXQoIigiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pXSx7fSk00, new int[] {40}, null, null);
      tmp[6] = new LiteralStackNode<IConstructor>(3612, 6, cHJvZChsaXQoIjsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU5LDU5KV0pXSx7fSk00, new int[] {59}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJmb3IiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLG9wdChzb3J0KCJFeHByZXNzaW9uIikpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksb3B0KHNvcnQoIkV4cHJlc3Npb24iKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOyIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxvcHQoc29ydCgiRXhwcmVzc2lvbiIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIpIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIlN0YXRlbWVudCIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJyZXR1cm4iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI7IildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(3627, 1, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(3626, 0, cHJvZChsaXQoInJldHVybiIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE3LDExNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKV0se30p, new int[] {114,101,116,117,114,110}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3628, 2, cHJvZChsaXQoIjsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU5LDU5KV0pXSx7fSk00, new int[] {59}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJyZXR1cm4iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI7IildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJzd2l0Y2giKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIpIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIlN0YXRlbWVudCIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[9];
      
      tmp[8] = new NonTerminalStackNode<IConstructor>(3638, 8, "Statement", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(3633, 3, "layouts_LAYOUTLIST", null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(3635, 5, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(3631, 1, "layouts_LAYOUTLIST", null, null);
      tmp[7] = new NonTerminalStackNode<IConstructor>(3637, 7, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(3630, 0, cHJvZChsaXQoInN3aXRjaCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE5LDExOSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNCwxMDQpXSldLHt9KQ0000, new int[] {115,119,105,116,99,104}, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(3634, 4, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3632, 2, cHJvZChsaXQoIigiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pXSx7fSk00, new int[] {40}, null, null);
      tmp[6] = new LiteralStackNode<IConstructor>(3636, 6, cHJvZChsaXQoIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {41}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJzd2l0Y2giKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIpIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIlN0YXRlbWVudCIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJkZWZhdWx0IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJTdGF0ZW1lbnQiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new NonTerminalStackNode<IConstructor>(3643, 3, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(3641, 1, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(3640, 0, cHJvZChsaXQoImRlZmF1bHQiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwMCwxMDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMiwxMDIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pXSx7fSk00, new int[] {100,101,102,97,117,108,116}, null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(3644, 4, "Statement", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3642, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJkZWZhdWx0IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJTdGF0ZW1lbnQiKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdGF0ZW1lbnQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiU3RhdGVtZW50XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJTdGF0ZW1lbnQiKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new CharStackNode<IConstructor>(3652, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3649, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(3647, 0, new int[][]{{0,0}}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(3651, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(3650, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(3648, 1, cHJvZChsaXQoInNvcnQoXCJTdGF0ZW1lbnRcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODMsODMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000, new int[] {115,111,114,116,40,34,83,116,97,116,101,109,101,110,116,34,41}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdGF0ZW1lbnQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiU3RhdGVtZW50XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJTdGF0ZW1lbnQiKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJpZiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIigiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiU3RhdGVtZW50IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiZWxzZSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJTdGF0ZW1lbnQiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[13];
      
      tmp[12] = new NonTerminalStackNode<IConstructor>(3667, 12, "Statement", null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(3659, 4, "Expression", null, null);
      tmp[6] = new LiteralStackNode<IConstructor>(3661, 6, cHJvZChsaXQoIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {41}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3657, 2, cHJvZChsaXQoIigiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pXSx7fSk00, new int[] {40}, null, null);
      tmp[10] = new LiteralStackNode<IConstructor>(3665, 10, cHJvZChsaXQoImVsc2UiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSldLHt9KQ0000, new int[] {101,108,115,101}, null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(3655, 0, cHJvZChsaXQoImlmIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDIsMTAyKV0pXSx7fSk00, new int[] {105,102}, null, null);
      tmp[9] = new NonTerminalStackNode<IConstructor>(3664, 9, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(3658, 3, "layouts_LAYOUTLIST", null, null);
      tmp[11] = new NonTerminalStackNode<IConstructor>(3666, 11, "layouts_LAYOUTLIST", null, null);
      tmp[7] = new NonTerminalStackNode<IConstructor>(3662, 7, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(3656, 1, "layouts_LAYOUTLIST", null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(3660, 5, "layouts_LAYOUTLIST", null, null);
      tmp[8] = new NonTerminalStackNode<IConstructor>(3663, 8, "Statement", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJpZiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIigiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiU3RhdGVtZW50IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiZWxzZSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJTdGF0ZW1lbnQiKV0se30p, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbc29ydCgiRXhwcmVzc2lvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKV0se30p(builder);
      
        _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJ7IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJEZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0YXRlbWVudCIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ9IildLHt9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJjYXNlIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI6IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIlN0YXRlbWVudCIpXSx7fSk00(builder);
      
        _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJyZXR1cm4iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKV0se30p(builder);
      
        _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGV4KCJJZGVudGlmaWVyIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJTdGF0ZW1lbnQiKV0se30p(builder);
      
        _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJicmVhayIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKV0se30p(builder);
      
        _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCI7IildLHt9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJjb250aW51ZSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKV0se30p(builder);
      
        _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJpZiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIigiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiU3RhdGVtZW50IildLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdGF0ZW1lbnQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc3Rhcihzb3J0KFwiU3RhdGVtZW50XCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0YXRlbWVudCIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(builder);
      
        _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJ3aGlsZSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIigiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiU3RhdGVtZW50IildLHt9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJnb3RvIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxleCgiSWRlbnRpZmllciIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKV0se30p(builder);
      
        _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJkbyIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJTdGF0ZW1lbnQiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ3aGlsZSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIigiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI7IildLHt9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJmb3IiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLG9wdChzb3J0KCJFeHByZXNzaW9uIikpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjsiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksb3B0KHNvcnQoIkV4cHJlc3Npb24iKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOyIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxvcHQoc29ydCgiRXhwcmVzc2lvbiIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIpIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIlN0YXRlbWVudCIpXSx7fSk00(builder);
      
        _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJyZXR1cm4iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI7IildLHt9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJzd2l0Y2giKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIoIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkV4cHJlc3Npb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIpIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIlN0YXRlbWVudCIpXSx7fSk00(builder);
      
        _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJkZWZhdWx0IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJTdGF0ZW1lbnQiKV0se30p(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdGF0ZW1lbnQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiU3RhdGVtZW50XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJTdGF0ZW1lbnQiKSkpfSk00(builder);
      
        _init_cHJvZChzb3J0KCJTdGF0ZW1lbnQiKSxbbGl0KCJpZiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIigiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIikiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiU3RhdGVtZW50IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiZWxzZSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxzb3J0KCJTdGF0ZW1lbnQiKV0se30p(builder);
      
    }
  }
	
  protected static class ExternalDeclaration {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChzb3J0KCJFeHRlcm5hbERlY2xhcmF0aW9uIiksW3NvcnQoIkZ1bmN0aW9uRGVmaW5pdGlvbiIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(3749, 0, "FunctionDefinition", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHRlcm5hbERlY2xhcmF0aW9uIiksW3NvcnQoIkZ1bmN0aW9uRGVmaW5pdGlvbiIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFeHRlcm5hbERlY2xhcmF0aW9uIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkV4dGVybmFsRGVjbGFyYXRpb25cIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIkV4dGVybmFsRGVjbGFyYXRpb24iKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new LiteralStackNode<IConstructor>(3753, 1, cHJvZChsaXQoInNvcnQoXCJFeHRlcm5hbERlY2xhcmF0aW9uXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY5LDY5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjAsMTIwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjgsNjgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {115,111,114,116,40,34,69,120,116,101,114,110,97,108,68,101,99,108,97,114,97,116,105,111,110,34,41}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(3752, 0, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3754, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(3757, 4, new int[][]{{0,0}}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(3756, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(3755, 0, new int[][]{{48,57}}, null, null), true, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFeHRlcm5hbERlY2xhcmF0aW9uIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkV4dGVybmFsRGVjbGFyYXRpb25cIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIkV4dGVybmFsRGVjbGFyYXRpb24iKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHRlcm5hbERlY2xhcmF0aW9uIiksW3NvcnQoIkdsb2JhbERlY2xhcmF0aW9uIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(3760, 0, "GlobalDeclaration", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHRlcm5hbERlY2xhcmF0aW9uIiksW3NvcnQoIkdsb2JhbERlY2xhcmF0aW9uIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFeHRlcm5hbERlY2xhcmF0aW9uIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiaXRlcihzb3J0KFwiRXh0ZXJuYWxEZWNsYXJhdGlvblwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXNlcHMoc29ydCgiRXh0ZXJuYWxEZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new CharStackNode<IConstructor>(3763, 0, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3765, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(3768, 4, new int[][]{{0,0}}, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(3764, 1, cHJvZChsaXQoIml0ZXIoc29ydChcIkV4dGVybmFsRGVjbGFyYXRpb25cIikpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2OSw2OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTIwLDEyMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY4LDY4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {105,116,101,114,40,115,111,114,116,40,34,69,120,116,101,114,110,97,108,68,101,99,108,97,114,97,116,105,111,110,34,41,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(3767, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(3766, 0, new int[][]{{48,57}}, null, null), true, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFeHRlcm5hbERlY2xhcmF0aW9uIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiaXRlcihzb3J0KFwiRXh0ZXJuYWxEZWNsYXJhdGlvblwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXNlcHMoc29ydCgiRXh0ZXJuYWxEZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHRlcm5hbERlY2xhcmF0aW9uIiksW3NvcnQoIkZ1bmN0aW9uUHJvdG90eXBlIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(3773, 0, "FunctionPrototype", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFeHRlcm5hbERlY2xhcmF0aW9uIiksW3NvcnQoIkZ1bmN0aW9uUHJvdG90eXBlIildLHt9KQ0000, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChzb3J0KCJFeHRlcm5hbERlY2xhcmF0aW9uIiksW3NvcnQoIkZ1bmN0aW9uRGVmaW5pdGlvbiIpXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFeHRlcm5hbERlY2xhcmF0aW9uIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkV4dGVybmFsRGVjbGFyYXRpb25cIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIkV4dGVybmFsRGVjbGFyYXRpb24iKSkpfSk00(builder);
      
        _init_cHJvZChzb3J0KCJFeHRlcm5hbERlY2xhcmF0aW9uIiksW3NvcnQoIkdsb2JhbERlY2xhcmF0aW9uIildLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFeHRlcm5hbERlY2xhcmF0aW9uIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiaXRlcihzb3J0KFwiRXh0ZXJuYWxEZWNsYXJhdGlvblwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXNlcHMoc29ydCgiRXh0ZXJuYWxEZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(builder);
      
        _init_cHJvZChzb3J0KCJFeHRlcm5hbERlY2xhcmF0aW9uIiksW3NvcnQoIkZ1bmN0aW9uUHJvdG90eXBlIildLHt9KQ0000(builder);
      
    }
  }
	
  protected static class InitDeclarator {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChzb3J0KCJJbml0RGVjbGFyYXRvciIpLFtsYWJlbCgiZGVjbCIsc29ydCgiRGVjbGFyYXRvciIpKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(3895, 0, "Declarator", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJJbml0RGVjbGFyYXRvciIpLFtsYWJlbCgiZGVjbCIsc29ydCgiRGVjbGFyYXRvciIpKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJJbml0RGVjbGFyYXRvciIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zZXBzKHNvcnQoXCJJbml0RGVjbGFyYXRvclwiKSxbbGl0KFwiLFwiKV0pIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zZXBzKHNvcnQoIkluaXREZWNsYXJhdG9yIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new CharStackNode<IConstructor>(3904, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3901, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(3899, 0, new int[][]{{0,0}}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(3903, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(3902, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(3900, 1, cHJvZChsaXQoIlxcaXRlci1zZXBzKHNvcnQoXCJJbml0RGVjbGFyYXRvclwiKSxbbGl0KFwiLFwiKV0pIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDczLDczKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2OCw2OCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTEsOTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTMsOTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {92,105,116,101,114,45,115,101,112,115,40,115,111,114,116,40,34,73,110,105,116,68,101,99,108,97,114,97,116,111,114,34,41,44,91,108,105,116,40,34,44,34,41,93,41}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJJbml0RGVjbGFyYXRvciIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zZXBzKHNvcnQoXCJJbml0RGVjbGFyYXRvclwiKSxbbGl0KFwiLFwiKV0pIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zZXBzKHNvcnQoIkluaXREZWNsYXJhdG9yIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJJbml0RGVjbGFyYXRvciIpLFtsYWJlbCgiZGVjbCIsc29ydCgiRGVjbGFyYXRvciIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI9IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkluaXRpYWxpemVyIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(3911, 0, "Declarator", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3914, 2, cHJvZChsaXQoIj0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDYxLDYxKV0pXSx7fSk00, new int[] {61}, null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(3913, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(3915, 3, "layouts_LAYOUTLIST", null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(3916, 4, "Initializer", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJJbml0RGVjbGFyYXRvciIpLFtsYWJlbCgiZGVjbCIsc29ydCgiRGVjbGFyYXRvciIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI9IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkluaXRpYWxpemVyIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJJbml0RGVjbGFyYXRvciIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJJbml0RGVjbGFyYXRvclwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiSW5pdERlY2xhcmF0b3IiKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new CharStackNode<IConstructor>(3919, 0, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3921, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(3924, 4, new int[][]{{0,0}}, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(3920, 1, cHJvZChsaXQoInNvcnQoXCJJbml0RGVjbGFyYXRvclwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg3Myw3MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjgsNjgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {115,111,114,116,40,34,73,110,105,116,68,101,99,108,97,114,97,116,111,114,34,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(3923, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(3922, 0, new int[][]{{48,57}}, null, null), true, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJJbml0RGVjbGFyYXRvciIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJJbml0RGVjbGFyYXRvclwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiSW5pdERlY2xhcmF0b3IiKSkpfSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChzb3J0KCJJbml0RGVjbGFyYXRvciIpLFtsYWJlbCgiZGVjbCIsc29ydCgiRGVjbGFyYXRvciIpKV0se30p(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJJbml0RGVjbGFyYXRvciIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zZXBzKHNvcnQoXCJJbml0RGVjbGFyYXRvclwiKSxbbGl0KFwiLFwiKV0pIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zZXBzKHNvcnQoIkluaXREZWNsYXJhdG9yIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(builder);
      
        _init_cHJvZChzb3J0KCJJbml0RGVjbGFyYXRvciIpLFtsYWJlbCgiZGVjbCIsc29ydCgiRGVjbGFyYXRvciIpKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCI9IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLHNvcnQoIkluaXRpYWxpemVyIildLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJJbml0RGVjbGFyYXRvciIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJJbml0RGVjbGFyYXRvclwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiSW5pdERlY2xhcmF0b3IiKSkpfSk00(builder);
      
    }
  }
	
  protected static class Identifier {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsZXgoIklkZW50aWZpZXIiKSxbY29uZGl0aW9uYWwoc2VxKFtcY2hhci1jbGFzcyhbcmFuZ2UoNjUsOTApLHJhbmdlKDk1LDk1KSxyYW5nZSg5NywxMjIpXSksY29uZGl0aW9uYWwoXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpLHJhbmdlKDY1LDkwKSxyYW5nZSg5NSw5NSkscmFuZ2UoOTcsMTIyKV0pKSx7XG5vdC1mb2xsb3coXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KSxyYW5nZSg2NSw5MCkscmFuZ2UoOTUsOTUpLHJhbmdlKDk3LDEyMildKSl9KV0pLHtkZWxldGUoa2V5d29yZHMoIktleXdvcmQiKSl9KV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new SequenceStackNode<IConstructor>(3947, 0, cmVndWxhcihzZXEoW1xjaGFyLWNsYXNzKFtyYW5nZSg2NSw5MCkscmFuZ2UoOTUsOTUpLHJhbmdlKDk3LDEyMildKSxjb25kaXRpb25hbChcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NykscmFuZ2UoNjUsOTApLHJhbmdlKDk1LDk1KSxyYW5nZSg5NywxMjIpXSkpLHtcbm90LWZvbGxvdyhcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpLHJhbmdlKDY1LDkwKSxyYW5nZSg5NSw5NSkscmFuZ2UoOTcsMTIyKV0pKX0pXSkp, (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new CharStackNode<IConstructor>(3940, 0, new int[][]{{65,90},{95,95},{97,122}}, null, null), new ListStackNode<IConstructor>(3944, 1, cmVndWxhcihcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NykscmFuZ2UoNjUsOTApLHJhbmdlKDk1LDk1KSxyYW5nZSg5NywxMjIpXSkpKQ0000, new CharStackNode<IConstructor>(3941, 0, new int[][]{{48,57},{65,90},{95,95},{97,122}}, null, null), false, null, new ICompletionFilter[] {new CharFollowRestriction(new int[][]{{48,57},{65,90},{95,95},{97,122}})})}, null, new ICompletionFilter[] {new StringMatchRestriction(new int[] {101,108,115,101}), new StringMatchRestriction(new int[] {115,105,122,101,111,102}), new StringMatchRestriction(new int[] {98,114,101,97,107}), new StringMatchRestriction(new int[] {105,102}), new StringMatchRestriction(new int[] {99,104,97,114}), new StringMatchRestriction(new int[] {102,111,114}), new StringMatchRestriction(new int[] {115,116,97,116,105,99}), new StringMatchRestriction(new int[] {101,120,116,101,114,110}), new StringMatchRestriction(new int[] {99,111,110,116,105,110,117,101}), new StringMatchRestriction(new int[] {115,105,103,110,101,100}), new StringMatchRestriction(new int[] {102,108,111,97,116}), new StringMatchRestriction(new int[] {108,111,110,103}), new StringMatchRestriction(new int[] {118,111,108,97,116,105,108,101}), new StringMatchRestriction(new int[] {115,104,111,114,116}), new StringMatchRestriction(new int[] {119,104,105,108,101}), new StringMatchRestriction(new int[] {100,111,117,98,108,101}), new StringMatchRestriction(new int[] {99,97,115,101}), new StringMatchRestriction(new int[] {114,101,116,117,114,110}), new StringMatchRestriction(new int[] {115,116,114,117,99,116}), new StringMatchRestriction(new int[] {117,110,115,105,103,110,101,100}), new StringMatchRestriction(new int[] {115,119,105,116,99,104}), new StringMatchRestriction(new int[] {118,111,105,100}), new StringMatchRestriction(new int[] {116,121,112,101,100,101,102}), new StringMatchRestriction(new int[] {100,111}), new StringMatchRestriction(new int[] {105,110,116}), new StringMatchRestriction(new int[] {117,110,105,111,110}), new StringMatchRestriction(new int[] {97,117,116,111}), new StringMatchRestriction(new int[] {99,111,110,115,116}), new StringMatchRestriction(new int[] {114,101,103,105,115,116,101,114}), new StringMatchRestriction(new int[] {103,111,116,111}), new StringMatchRestriction(new int[] {100,101,102,97,117,108,116}), new StringMatchRestriction(new int[] {101,110,117,109})});
      builder.addAlternative(CParser.cHJvZChsZXgoIklkZW50aWZpZXIiKSxbY29uZGl0aW9uYWwoc2VxKFtcY2hhci1jbGFzcyhbcmFuZ2UoNjUsOTApLHJhbmdlKDk1LDk1KSxyYW5nZSg5NywxMjIpXSksY29uZGl0aW9uYWwoXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpLHJhbmdlKDY1LDkwKSxyYW5nZSg5NSw5NSkscmFuZ2UoOTcsMTIyKV0pKSx7XG5vdC1mb2xsb3coXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KSxyYW5nZSg2NSw5MCkscmFuZ2UoOTUsOTUpLHJhbmdlKDk3LDEyMildKSl9KV0pLHtkZWxldGUoa2V5d29yZHMoIktleXdvcmQiKSl9KV0se30p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIklkZW50aWZpZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiSWRlbnRpZmllclwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIobGV4KCJJZGVudGlmaWVyIikpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new CharStackNode<IConstructor>(3950, 0, new int[][]{{0,0}}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(3955, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(3952, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(3954, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(3953, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(3951, 1, cHJvZChsaXQoInNvcnQoXCJJZGVudGlmaWVyXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDczLDczKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDAsMTAwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDIsMTAyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000, new int[] {115,111,114,116,40,34,73,100,101,110,116,105,102,105,101,114,34,41}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIklkZW50aWZpZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiSWRlbnRpZmllclwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIobGV4KCJJZGVudGlmaWVyIikpKX0p, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsZXgoIklkZW50aWZpZXIiKSxbY29uZGl0aW9uYWwoc2VxKFtcY2hhci1jbGFzcyhbcmFuZ2UoNjUsOTApLHJhbmdlKDk1LDk1KSxyYW5nZSg5NywxMjIpXSksY29uZGl0aW9uYWwoXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpLHJhbmdlKDY1LDkwKSxyYW5nZSg5NSw5NSkscmFuZ2UoOTcsMTIyKV0pKSx7XG5vdC1mb2xsb3coXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KSxyYW5nZSg2NSw5MCkscmFuZ2UoOTUsOTUpLHJhbmdlKDk3LDEyMildKSl9KV0pLHtkZWxldGUoa2V5d29yZHMoIktleXdvcmQiKSl9KV0se30p(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIklkZW50aWZpZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiSWRlbnRpZmllclwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIobGV4KCJJZGVudGlmaWVyIikpKX0p(builder);
      
    }
  }
	
  protected static class NonCommaExpression {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJOb25Db21tYUV4cHJlc3Npb24iKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc3Rhci1zZXBzKHNvcnQoXCJOb25Db21tYUV4cHJlc3Npb25cIiksW2xpdChcIixcIildKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc3Rhci1zZXBzKHNvcnQoIk5vbkNvbW1hRXhwcmVzc2lvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIsIiksbGF5b3V0cygiTEFZT1VUTElTVCIpXSkpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new ListStackNode<IConstructor>(4076, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(4075, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(4073, 1, cHJvZChsaXQoIlxcaXRlci1zdGFyLXNlcHMoc29ydChcIk5vbkNvbW1hRXhwcmVzc2lvblwiKSxbbGl0KFwiLFwiKV0pIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEyLDExMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNzgsNzgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDY3LDY3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjksNjkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEyMCwxMjApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDkxLDkxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDkzLDkzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {92,105,116,101,114,45,115,116,97,114,45,115,101,112,115,40,115,111,114,116,40,34,78,111,110,67,111,109,109,97,69,120,112,114,101,115,115,105,111,110,34,41,44,91,108,105,116,40,34,44,34,41,93,41}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(4074, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(4077, 4, new int[][]{{0,0}}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(4072, 0, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJOb25Db21tYUV4cHJlc3Npb24iKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc3Rhci1zZXBzKHNvcnQoXCJOb25Db21tYUV4cHJlc3Npb25cIiksW2xpdChcIixcIildKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc3Rhci1zZXBzKHNvcnQoIk5vbkNvbW1hRXhwcmVzc2lvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIsIiksbGF5b3V0cygiTEFZT1VUTElTVCIpXSkpKX0p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgibm9uQ29tbWFFeHByZXNzaW9uIixzb3J0KCJOb25Db21tYUV4cHJlc3Npb24iKSksW2xhYmVsKCJleHByIixzb3J0KCJFeHByZXNzaW9uIikpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(4085, 0, "Expression", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgibm9uQ29tbWFFeHByZXNzaW9uIixzb3J0KCJOb25Db21tYUV4cHJlc3Npb24iKSksW2xhYmVsKCJleHByIixzb3J0KCJFeHByZXNzaW9uIikpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJOb25Db21tYUV4cHJlc3Npb24iKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiTm9uQ29tbWFFeHByZXNzaW9uXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJOb25Db21tYUV4cHJlc3Npb24iKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new ListStackNode<IConstructor>(4093, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(4092, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(4090, 1, cHJvZChsaXQoInNvcnQoXCJOb25Db21tYUV4cHJlc3Npb25cIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNzgsNzgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDY3LDY3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjksNjkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEyMCwxMjApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {115,111,114,116,40,34,78,111,110,67,111,109,109,97,69,120,112,114,101,115,115,105,111,110,34,41}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(4091, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(4089, 0, new int[][]{{0,0}}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(4094, 4, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJOb25Db21tYUV4cHJlc3Npb24iKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiTm9uQ29tbWFFeHByZXNzaW9uXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJOb25Db21tYUV4cHJlc3Npb24iKSkpfSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJOb25Db21tYUV4cHJlc3Npb24iKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc3Rhci1zZXBzKHNvcnQoXCJOb25Db21tYUV4cHJlc3Npb25cIiksW2xpdChcIixcIildKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc3Rhci1zZXBzKHNvcnQoIk5vbkNvbW1hRXhwcmVzc2lvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIsIiksbGF5b3V0cygiTEFZT1VUTElTVCIpXSkpKX0p(builder);
      
        _init_cHJvZChsYWJlbCgibm9uQ29tbWFFeHByZXNzaW9uIixzb3J0KCJOb25Db21tYUV4cHJlc3Npb24iKSksW2xhYmVsKCJleHByIixzb3J0KCJFeHByZXNzaW9uIikpXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJOb25Db21tYUV4cHJlc3Npb24iKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiTm9uQ29tbWFFeHByZXNzaW9uXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJOb25Db21tYUV4cHJlc3Npb24iKSkpfSk00(builder);
      
    }
  }
	
  protected static class start__TranslationUnit {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChzdGFydChzb3J0KCJUcmFuc2xhdGlvblVuaXQiKSksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgidG9wIixzb3J0KCJUcmFuc2xhdGlvblVuaXQiKSksbGF5b3V0cygiTEFZT1VUTElTVCIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(4148, 1, "TranslationUnit", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(4147, 0, "layouts_LAYOUTLIST", null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(4150, 2, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzdGFydChzb3J0KCJUcmFuc2xhdGlvblVuaXQiKSksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgidG9wIixzb3J0KCJUcmFuc2xhdGlvblVuaXQiKSksbGF5b3V0cygiTEFZT1VUTElTVCIpXSx7fSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChzdGFydChzb3J0KCJUcmFuc2xhdGlvblVuaXQiKSksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsYWJlbCgidG9wIixzb3J0KCJUcmFuc2xhdGlvblVuaXQiKSksbGF5b3V0cygiTEFZT1VUTElTVCIpXSx7fSk00(builder);
      
    }
  }
	
  protected static class Initializer {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChzb3J0KCJJbml0aWFsaXplciIpLFtsaXQoInsiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksXGl0ZXItc2Vwcyhzb3J0KCJJbml0aWFsaXplciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIsIiksbGF5b3V0cygiTEFZT1VUTElTVCIpXSksbGF5b3V0cygiTEFZT1VUTElTVCIpLG9wdChsaXQoIiwiKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgifSIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[7];
      
      tmp[3] = new NonTerminalStackNode<IConstructor>(4307, 3, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(4300, 0, cHJvZChsaXQoInsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEyMywxMjMpXSldLHt9KQ0000, new int[] {123}, null, null);
      tmp[2] = new SeparatedListStackNode<IConstructor>(4306, 2, cmVndWxhcihcaXRlci1zZXBzKHNvcnQoIkluaXRpYWxpemVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSk00, new NonTerminalStackNode<IConstructor>(4302, 0, "Initializer", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(4303, 1, "layouts_LAYOUTLIST", null, null), new LiteralStackNode<IConstructor>(4304, 2, cHJvZChsaXQoIiwiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pXSx7fSk00, new int[] {44}, null, null), new NonTerminalStackNode<IConstructor>(4305, 3, "layouts_LAYOUTLIST", null, null)}, true, null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(4310, 5, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(4301, 1, "layouts_LAYOUTLIST", null, null);
      tmp[4] = new OptionalStackNode<IConstructor>(4309, 4, cmVndWxhcihvcHQobGl0KCIsIikpKQ0000, new LiteralStackNode<IConstructor>(4308, 0, cHJvZChsaXQoIiwiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pXSx7fSk00, new int[] {44}, null, null), null, null);
      tmp[6] = new LiteralStackNode<IConstructor>(4311, 6, cHJvZChsaXQoIn0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEyNSwxMjUpXSldLHt9KQ0000, new int[] {125}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJJbml0aWFsaXplciIpLFtsaXQoInsiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksXGl0ZXItc2Vwcyhzb3J0KCJJbml0aWFsaXplciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIsIiksbGF5b3V0cygiTEFZT1VUTElTVCIpXSksbGF5b3V0cygiTEFZT1VUTElTVCIpLG9wdChsaXQoIiwiKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgifSIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJJbml0aWFsaXplciIpLFtzb3J0KCJOb25Db21tYUV4cHJlc3Npb24iKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(4313, 0, "NonCommaExpression", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJJbml0aWFsaXplciIpLFtzb3J0KCJOb25Db21tYUV4cHJlc3Npb24iKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJJbml0aWFsaXplciIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zZXBzKHNvcnQoXCJJbml0aWFsaXplclwiKSxbbGl0KFwiLFwiKV0pIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zZXBzKHNvcnQoIkluaXRpYWxpemVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new CharStackNode<IConstructor>(4316, 0, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(4318, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(4321, 4, new int[][]{{0,0}}, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(4317, 1, cHJvZChsaXQoIlxcaXRlci1zZXBzKHNvcnQoXCJJbml0aWFsaXplclwiKSxbbGl0KFwiLFwiKV0pIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDczLDczKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTIyLDEyMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTEsOTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTMsOTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {92,105,116,101,114,45,115,101,112,115,40,115,111,114,116,40,34,73,110,105,116,105,97,108,105,122,101,114,34,41,44,91,108,105,116,40,34,44,34,41,93,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(4320, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(4319, 0, new int[][]{{48,57}}, null, null), true, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJJbml0aWFsaXplciIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zZXBzKHNvcnQoXCJJbml0aWFsaXplclwiKSxbbGl0KFwiLFwiKV0pIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zZXBzKHNvcnQoIkluaXRpYWxpemVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJJbml0aWFsaXplciIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJJbml0aWFsaXplclwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiSW5pdGlhbGl6ZXIiKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new CharStackNode<IConstructor>(4329, 0, new int[][]{{0,0}}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(4334, 4, new int[][]{{0,0}}, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(4330, 1, cHJvZChsaXQoInNvcnQoXCJJbml0aWFsaXplclwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg3Myw3MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEyMiwxMjIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {115,111,114,116,40,34,73,110,105,116,105,97,108,105,122,101,114,34,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(4333, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(4332, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(4331, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJJbml0aWFsaXplciIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJJbml0aWFsaXplclwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiSW5pdGlhbGl6ZXIiKSkpfSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChzb3J0KCJJbml0aWFsaXplciIpLFtsaXQoInsiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksXGl0ZXItc2Vwcyhzb3J0KCJJbml0aWFsaXplciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIsIiksbGF5b3V0cygiTEFZT1VUTElTVCIpXSksbGF5b3V0cygiTEFZT1VUTElTVCIpLG9wdChsaXQoIiwiKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgifSIpXSx7fSk00(builder);
      
        _init_cHJvZChzb3J0KCJJbml0aWFsaXplciIpLFtzb3J0KCJOb25Db21tYUV4cHJlc3Npb24iKV0se30p(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJJbml0aWFsaXplciIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zZXBzKHNvcnQoXCJJbml0aWFsaXplclwiKSxbbGl0KFwiLFwiKV0pIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zZXBzKHNvcnQoIkluaXRpYWxpemVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJJbml0aWFsaXplciIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJJbml0aWFsaXplclwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiSW5pdGlhbGl6ZXIiKSkpfSk00(builder);
      
    }
  }
	
  protected static class LAYOUT {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkxBWU9VVCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJMQVlPVVRcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGxleCgiTEFZT1VUIikpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new LiteralStackNode<IConstructor>(4371, 1, cHJvZChsaXQoInNvcnQoXCJMQVlPVVRcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNzYsNzYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY1LDY1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4OSw4OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNzksNzkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDg1LDg1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4NCw4NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {115,111,114,116,40,34,76,65,89,79,85,84,34,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(4374, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(4373, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(4372, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(4375, 4, new int[][]{{0,0}}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(4370, 0, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkxBWU9VVCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJMQVlPVVRcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGxleCgiTEFZT1VUIikpKX0p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgid2hpdGVzcGFjZSIsbGV4KCJMQVlPVVQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSg5LDEwKSxyYW5nZSgxMywxMykscmFuZ2UoMzIsMzIpXSldLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new CharStackNode<IConstructor>(4379, 0, new int[][]{{9,10},{13,13},{32,32}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgid2hpdGVzcGFjZSIsbGV4KCJMQVlPVVQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSg5LDEwKSxyYW5nZSgxMywxMykscmFuZ2UoMzIsMzIpXSldLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkxBWU9VVCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJMQVlPVVRcIikpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zdGFyKGxleCgiTEFZT1VUIikpKSl9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new CharStackNode<IConstructor>(4387, 4, new int[][]{{0,0}}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(4382, 0, new int[][]{{0,0}}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(4386, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(4385, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(4383, 1, cHJvZChsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJMQVlPVVRcIikpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg3Niw3NildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjUsNjUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDg5LDg5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg3OSw3OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODUsODUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDg0LDg0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {92,105,116,101,114,45,115,116,97,114,40,115,111,114,116,40,34,76,65,89,79,85,84,34,41,41}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(4384, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkxBWU9VVCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJMQVlPVVRcIikpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zdGFyKGxleCgiTEFZT1VUIikpKSl9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiY29tbWVudCIsbGV4KCJMQVlPVVQiKSksW2xleCgiQ29tbWVudCIpXSx7dGFnKCJjYXRlZ29yeSIoIkNvbW1lbnQiKSl9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(4392, 0, "Comment", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiY29tbWVudCIsbGV4KCJMQVlPVVQiKSksW2xleCgiQ29tbWVudCIpXSx7dGFnKCJjYXRlZ29yeSIoIkNvbW1lbnQiKSl9KQ0000, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkxBWU9VVCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJMQVlPVVRcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGxleCgiTEFZT1VUIikpKX0p(builder);
      
        _init_cHJvZChsYWJlbCgid2hpdGVzcGFjZSIsbGV4KCJMQVlPVVQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSg5LDEwKSxyYW5nZSgxMywxMykscmFuZ2UoMzIsMzIpXSldLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkxBWU9VVCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJMQVlPVVRcIikpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zdGFyKGxleCgiTEFZT1VUIikpKSl9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiY29tbWVudCIsbGV4KCJMQVlPVVQiKSksW2xleCgiQ29tbWVudCIpXSx7dGFnKCJjYXRlZ29yeSIoIkNvbW1lbnQiKSl9KQ0000(builder);
      
    }
  }
	
  protected static class CharacterConstant {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkNoYXJhY3RlckNvbnN0YW50IikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkNoYXJhY3RlckNvbnN0YW50XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihsZXgoIkNoYXJhY3RlckNvbnN0YW50IikpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new LiteralStackNode<IConstructor>(4410, 1, cHJvZChsaXQoInNvcnQoXCJDaGFyYWN0ZXJDb25zdGFudFwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2Nyw2NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA0LDEwNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjcsNjcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000, new int[] {115,111,114,116,40,34,67,104,97,114,97,99,116,101,114,67,111,110,115,116,97,110,116,34,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(4413, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(4412, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(4411, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(4414, 4, new int[][]{{0,0}}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(4409, 0, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkNoYXJhY3RlckNvbnN0YW50IikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkNoYXJhY3RlckNvbnN0YW50XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihsZXgoIkNoYXJhY3RlckNvbnN0YW50IikpKX0p, tmp);
	}
    protected static final void _init_cHJvZChsZXgoIkNoYXJhY3RlckNvbnN0YW50IiksW29wdChcY2hhci1jbGFzcyhbcmFuZ2UoNzYsNzYpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgzOSwzOSldKSxpdGVyKGxleCgiQ2hhcmFjdGVyQ29uc3RhbnRDb250ZW50IikpLFxjaGFyLWNsYXNzKFtyYW5nZSgzOSwzOSldKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[4];
      
      tmp[1] = new CharStackNode<IConstructor>(4419, 1, new int[][]{{39,39}}, null, null);
      tmp[3] = new CharStackNode<IConstructor>(4422, 3, new int[][]{{39,39}}, null, null);
      tmp[0] = new OptionalStackNode<IConstructor>(4418, 0, cmVndWxhcihvcHQoXGNoYXItY2xhc3MoW3JhbmdlKDc2LDc2KV0pKSk00, new CharStackNode<IConstructor>(4417, 0, new int[][]{{76,76}}, null, null), null, null);
      tmp[2] = new ListStackNode<IConstructor>(4421, 2, cmVndWxhcihpdGVyKGxleCgiQ2hhcmFjdGVyQ29uc3RhbnRDb250ZW50IikpKQ0000, new NonTerminalStackNode<IConstructor>(4420, 0, "CharacterConstantContent", null, null), true, null, null);
      builder.addAlternative(CParser.cHJvZChsZXgoIkNoYXJhY3RlckNvbnN0YW50IiksW29wdChcY2hhci1jbGFzcyhbcmFuZ2UoNzYsNzYpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgzOSwzOSldKSxpdGVyKGxleCgiQ2hhcmFjdGVyQ29uc3RhbnRDb250ZW50IikpLFxjaGFyLWNsYXNzKFtyYW5nZSgzOSwzOSldKV0se30p, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkNoYXJhY3RlckNvbnN0YW50IikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkNoYXJhY3RlckNvbnN0YW50XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihsZXgoIkNoYXJhY3RlckNvbnN0YW50IikpKX0p(builder);
      
        _init_cHJvZChsZXgoIkNoYXJhY3RlckNvbnN0YW50IiksW29wdChcY2hhci1jbGFzcyhbcmFuZ2UoNzYsNzYpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgzOSwzOSldKSxpdGVyKGxleCgiQ2hhcmFjdGVyQ29uc3RhbnRDb250ZW50IikpLFxjaGFyLWNsYXNzKFtyYW5nZSgzOSwzOSldKV0se30p(builder);
      
    }
  }
	
  protected static class TypeName {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChzb3J0KCJUeXBlTmFtZSIpLFtcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiQWJzdHJhY3REZWNsYXJhdG9yIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(4473, 1, "layouts_LAYOUTLIST", null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(4474, 2, "AbstractDeclarator", null, null);
      tmp[0] = new SeparatedListStackNode<IConstructor>(4472, 0, cmVndWxhcihcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSk00, new NonTerminalStackNode<IConstructor>(4470, 0, "Specifier", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(4471, 1, "layouts_LAYOUTLIST", null, null)}, true, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJUeXBlTmFtZSIpLFtcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiQWJzdHJhY3REZWNsYXJhdG9yIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJUeXBlTmFtZSIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJUeXBlTmFtZVwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiVHlwZU5hbWUiKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new ListStackNode<IConstructor>(4481, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(4480, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(4478, 1, cHJvZChsaXQoInNvcnQoXCJUeXBlTmFtZVwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4NCw4NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTIxLDEyMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEyLDExMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNzgsNzgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000, new int[] {115,111,114,116,40,34,84,121,112,101,78,97,109,101,34,41}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(4482, 4, new int[][]{{0,0}}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(4477, 0, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(4479, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJUeXBlTmFtZSIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJUeXBlTmFtZVwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiVHlwZU5hbWUiKSkpfSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChzb3J0KCJUeXBlTmFtZSIpLFtcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiQWJzdHJhY3REZWNsYXJhdG9yIildLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJUeXBlTmFtZSIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJUeXBlTmFtZVwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiVHlwZU5hbWUiKSkpfSk00(builder);
      
    }
  }
	
  protected static class StructDeclaration {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgic3RydWN0RGVjbFdpdGhEZWNsIixzb3J0KCJTdHJ1Y3REZWNsYXJhdGlvbiIpKSxbbGFiZWwoInNwZWNzIixcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXNlcHMoc29ydCgiU3RydWN0RGVjbGFyYXRvciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIsIiksbGF5b3V0cygiTEFZT1VUTElTVCIpXSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOyIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(4520, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(4526, 3, "layouts_LAYOUTLIST", null, null);
      tmp[2] = new SeparatedListStackNode<IConstructor>(4525, 2, cmVndWxhcihcaXRlci1zZXBzKHNvcnQoIlN0cnVjdERlY2xhcmF0b3IiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiLCIpLGxheW91dHMoIkxBWU9VVExJU1QiKV0pKQ0000, new NonTerminalStackNode<IConstructor>(4521, 0, "StructDeclarator", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(4522, 1, "layouts_LAYOUTLIST", null, null), new LiteralStackNode<IConstructor>(4523, 2, cHJvZChsaXQoIiwiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pXSx7fSk00, new int[] {44}, null, null), new NonTerminalStackNode<IConstructor>(4524, 3, "layouts_LAYOUTLIST", null, null)}, true, null, null);
      tmp[0] = new SeparatedListStackNode<IConstructor>(4518, 0, cmVndWxhcihcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSk00, new NonTerminalStackNode<IConstructor>(4516, 0, "Specifier", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(4517, 1, "layouts_LAYOUTLIST", null, null)}, true, null, null);
      tmp[4] = new LiteralStackNode<IConstructor>(4527, 4, cHJvZChsaXQoIjsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU5LDU5KV0pXSx7fSk00, new int[] {59}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgic3RydWN0RGVjbFdpdGhEZWNsIixzb3J0KCJTdHJ1Y3REZWNsYXJhdGlvbiIpKSxbbGFiZWwoInNwZWNzIixcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXNlcHMoc29ydCgiU3RydWN0RGVjbGFyYXRvciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIsIiksbGF5b3V0cygiTEFZT1VUTElTVCIpXSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOyIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgic3RydWN0RGVjbFdpdGhvdXREZWNsIixzb3J0KCJTdHJ1Y3REZWNsYXJhdGlvbiIpKSxbbGFiZWwoInNwZWNzIixcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOyIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(4534, 1, "layouts_LAYOUTLIST", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(4535, 2, cHJvZChsaXQoIjsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU5LDU5KV0pXSx7fSk00, new int[] {59}, null, null);
      tmp[0] = new SeparatedListStackNode<IConstructor>(4532, 0, cmVndWxhcihcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSk00, new NonTerminalStackNode<IConstructor>(4530, 0, "Specifier", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(4531, 1, "layouts_LAYOUTLIST", null, null)}, true, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgic3RydWN0RGVjbFdpdGhvdXREZWNsIixzb3J0KCJTdHJ1Y3REZWNsYXJhdGlvbiIpKSxbbGFiZWwoInNwZWNzIixcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOyIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdHJ1Y3REZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJTdHJ1Y3REZWNsYXJhdGlvblwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJTdHJ1Y3REZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new CharStackNode<IConstructor>(4538, 0, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(4540, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(4543, 4, new int[][]{{0,0}}, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(4539, 1, cHJvZChsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJTdHJ1Y3REZWNsYXJhdGlvblwiKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkyLDkyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDgzLDgzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjgsNjgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000, new int[] {92,105,116,101,114,45,115,116,97,114,40,115,111,114,116,40,34,83,116,114,117,99,116,68,101,99,108,97,114,97,116,105,111,110,34,41,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(4542, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(4541, 0, new int[][]{{48,57}}, null, null), true, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdHJ1Y3REZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJTdHJ1Y3REZWNsYXJhdGlvblwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJTdHJ1Y3REZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdHJ1Y3REZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJTdHJ1Y3REZWNsYXJhdGlvblwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiU3RydWN0RGVjbGFyYXRpb24iKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new CharStackNode<IConstructor>(4549, 0, new int[][]{{0,0}}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(4554, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(4551, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(4553, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(4552, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(4550, 1, cHJvZChsaXQoInNvcnQoXCJTdHJ1Y3REZWNsYXJhdGlvblwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4Myw4MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE3LDExNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY4LDY4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000, new int[] {115,111,114,116,40,34,83,116,114,117,99,116,68,101,99,108,97,114,97,116,105,111,110,34,41}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdHJ1Y3REZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJTdHJ1Y3REZWNsYXJhdGlvblwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiU3RydWN0RGVjbGFyYXRpb24iKSkpfSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgic3RydWN0RGVjbFdpdGhEZWNsIixzb3J0KCJTdHJ1Y3REZWNsYXJhdGlvbiIpKSxbbGFiZWwoInNwZWNzIixcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXNlcHMoc29ydCgiU3RydWN0RGVjbGFyYXRvciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIsIiksbGF5b3V0cygiTEFZT1VUTElTVCIpXSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOyIpXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgic3RydWN0RGVjbFdpdGhvdXREZWNsIixzb3J0KCJTdHJ1Y3REZWNsYXJhdGlvbiIpKSxbbGFiZWwoInNwZWNzIixcaXRlci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiOyIpXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdHJ1Y3REZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJTdHJ1Y3REZWNsYXJhdGlvblwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJTdHJ1Y3REZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdHJ1Y3REZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJTdHJ1Y3REZWNsYXJhdGlvblwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiU3RydWN0RGVjbGFyYXRpb24iKSkpfSk00(builder);
      
    }
  }
	
  protected static class CharacterConstantContent {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkNoYXJhY3RlckNvbnN0YW50Q29udGVudCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIml0ZXIoc29ydChcIkNoYXJhY3RlckNvbnN0YW50Q29udGVudFwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGl0ZXIobGV4KCJDaGFyYWN0ZXJDb25zdGFudENvbnRlbnQiKSkpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new ListStackNode<IConstructor>(4590, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(4589, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(4587, 1, cHJvZChsaXQoIml0ZXIoc29ydChcIkNoYXJhY3RlckNvbnN0YW50Q29udGVudFwiKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY3LDY3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDQsMTA0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2Nyw2NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY3LDY3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {105,116,101,114,40,115,111,114,116,40,34,67,104,97,114,97,99,116,101,114,67,111,110,115,116,97,110,116,67,111,110,116,101,110,116,34,41,41}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(4586, 0, new int[][]{{0,0}}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(4591, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(4588, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkNoYXJhY3RlckNvbnN0YW50Q29udGVudCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIml0ZXIoc29ydChcIkNoYXJhY3RlckNvbnN0YW50Q29udGVudFwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGl0ZXIobGV4KCJDaGFyYWN0ZXJDb25zdGFudENvbnRlbnQiKSkpKX0p, tmp);
	}
    protected static final void _init_cHJvZChsZXgoIkNoYXJhY3RlckNvbnN0YW50Q29udGVudCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMSwzOCkscmFuZ2UoNDAsOTEpLHJhbmdlKDkzLDE2Nzc3MjE1KV0pXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new CharStackNode<IConstructor>(4595, 0, new int[][]{{1,38},{40,91},{93,16777215}}, null, null);
      builder.addAlternative(CParser.cHJvZChsZXgoIkNoYXJhY3RlckNvbnN0YW50Q29udGVudCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMSwzOCkscmFuZ2UoNDAsOTEpLHJhbmdlKDkzLDE2Nzc3MjE1KV0pXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkNoYXJhY3RlckNvbnN0YW50Q29udGVudCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJDaGFyYWN0ZXJDb25zdGFudENvbnRlbnRcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGxleCgiQ2hhcmFjdGVyQ29uc3RhbnRDb250ZW50IikpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new CharStackNode<IConstructor>(4598, 0, new int[][]{{0,0}}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(4603, 4, new int[][]{{0,0}}, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(4599, 1, cHJvZChsaXQoInNvcnQoXCJDaGFyYWN0ZXJDb25zdGFudENvbnRlbnRcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjcsNjcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNCwxMDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY3LDY3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjcsNjcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {115,111,114,116,40,34,67,104,97,114,97,99,116,101,114,67,111,110,115,116,97,110,116,67,111,110,116,101,110,116,34,41}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(4600, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(4602, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(4601, 0, new int[][]{{48,57}}, null, null), true, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkNoYXJhY3RlckNvbnN0YW50Q29udGVudCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJDaGFyYWN0ZXJDb25zdGFudENvbnRlbnRcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGxleCgiQ2hhcmFjdGVyQ29uc3RhbnRDb250ZW50IikpKX0p, tmp);
	}
    protected static final void _init_cHJvZChsZXgoIkNoYXJhY3RlckNvbnN0YW50Q29udGVudCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoOTIsOTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEsMTY3NzcyMTUpXSldLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[2];
      
      tmp[0] = new CharStackNode<IConstructor>(4606, 0, new int[][]{{92,92}}, null, null);
      tmp[1] = new CharStackNode<IConstructor>(4607, 1, new int[][]{{1,16777215}}, null, null);
      builder.addAlternative(CParser.cHJvZChsZXgoIkNoYXJhY3RlckNvbnN0YW50Q29udGVudCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoOTIsOTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEsMTY3NzcyMTUpXSldLHt9KQ0000, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkNoYXJhY3RlckNvbnN0YW50Q29udGVudCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIml0ZXIoc29ydChcIkNoYXJhY3RlckNvbnN0YW50Q29udGVudFwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGl0ZXIobGV4KCJDaGFyYWN0ZXJDb25zdGFudENvbnRlbnQiKSkpKX0p(builder);
      
        _init_cHJvZChsZXgoIkNoYXJhY3RlckNvbnN0YW50Q29udGVudCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMSwzOCkscmFuZ2UoNDAsOTEpLHJhbmdlKDkzLDE2Nzc3MjE1KV0pXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkNoYXJhY3RlckNvbnN0YW50Q29udGVudCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJDaGFyYWN0ZXJDb25zdGFudENvbnRlbnRcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGxleCgiQ2hhcmFjdGVyQ29uc3RhbnRDb250ZW50IikpKX0p(builder);
      
        _init_cHJvZChsZXgoIkNoYXJhY3RlckNvbnN0YW50Q29udGVudCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoOTIsOTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEsMTY3NzcyMTUpXSldLHt9KQ0000(builder);
      
    }
  }
	
  protected static class TypeSpecifier {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiY2hhciIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGl0KCJjaGFyIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(4852, 0, cHJvZChsaXQoImNoYXIiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDQsMTA0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKV0se30p, new int[] {99,104,97,114}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiY2hhciIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGl0KCJjaGFyIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJUeXBlU3BlY2lmaWVyIiksW2xpdCgidW5zaWduZWQiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(4854, 0, cHJvZChsaXQoInVuc2lnbmVkIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDAsMTAwKV0pXSx7fSk00, new int[] {117,110,115,105,103,110,101,100}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJUeXBlU3BlY2lmaWVyIiksW2xpdCgidW5zaWduZWQiKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgic3RydWN0Iixzb3J0KCJUeXBlU3BlY2lmaWVyIikpLFtsaXQoInN0cnVjdCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsZXgoIklkZW50aWZpZXIiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(4858, 1, "layouts_LAYOUTLIST", null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(4859, 2, "Identifier", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(4857, 0, cHJvZChsaXQoInN0cnVjdCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE3LDExNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSldLHt9KQ0000, new int[] {115,116,114,117,99,116}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgic3RydWN0Iixzb3J0KCJUeXBlU3BlY2lmaWVyIikpLFtsaXQoInN0cnVjdCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsZXgoIklkZW50aWZpZXIiKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJUeXBlU3BlY2lmaWVyIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlR5cGVTcGVjaWZpZXJcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlR5cGVTcGVjaWZpZXIiKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new ListStackNode<IConstructor>(4866, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(4865, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(4863, 1, cHJvZChsaXQoInNvcnQoXCJUeXBlU3BlY2lmaWVyXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDg0LDg0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjEsMTIxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4Myw4MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEyLDExMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMiwxMDIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {115,111,114,116,40,34,84,121,112,101,83,112,101,99,105,102,105,101,114,34,41}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(4862, 0, new int[][]{{0,0}}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(4867, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(4864, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJUeXBlU3BlY2lmaWVyIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlR5cGVTcGVjaWZpZXJcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlR5cGVTcGVjaWZpZXIiKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiZW51bURlY2wiLHNvcnQoIlR5cGVTcGVjaWZpZXIiKSksW2xpdCgiZW51bSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsZXgoIklkZW50aWZpZXIiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ7IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXNlcHMoc29ydCgiRW51bWVyYXRvciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIsIiksbGF5b3V0cygiTEFZT1VUTElTVCIpXSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgifSIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[9];
      
      tmp[7] = new NonTerminalStackNode<IConstructor>(4882, 7, "layouts_LAYOUTLIST", null, null);
      tmp[8] = new LiteralStackNode<IConstructor>(4883, 8, cHJvZChsaXQoIn0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEyNSwxMjUpXSldLHt9KQ0000, new int[] {125}, null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(4874, 3, "layouts_LAYOUTLIST", null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(4876, 5, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(4872, 1, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(4871, 0, cHJvZChsaXQoImVudW0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNywxMTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSldLHt9KQ0000, new int[] {101,110,117,109}, null, null);
      tmp[4] = new LiteralStackNode<IConstructor>(4875, 4, cHJvZChsaXQoInsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEyMywxMjMpXSldLHt9KQ0000, new int[] {123}, null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(4873, 2, "Identifier", null, null);
      tmp[6] = new SeparatedListStackNode<IConstructor>(4881, 6, cmVndWxhcihcaXRlci1zZXBzKHNvcnQoIkVudW1lcmF0b3IiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiLCIpLGxheW91dHMoIkxBWU9VVExJU1QiKV0pKQ0000, new NonTerminalStackNode<IConstructor>(4877, 0, "Enumerator", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(4878, 1, "layouts_LAYOUTLIST", null, null), new LiteralStackNode<IConstructor>(4879, 2, cHJvZChsaXQoIiwiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pXSx7fSk00, new int[] {44}, null, null), new NonTerminalStackNode<IConstructor>(4880, 3, "layouts_LAYOUTLIST", null, null)}, true, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiZW51bURlY2wiLHNvcnQoIlR5cGVTcGVjaWZpZXIiKSksW2xpdCgiZW51bSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsZXgoIklkZW50aWZpZXIiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ7IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXNlcHMoc29ydCgiRW51bWVyYXRvciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIsIiksbGF5b3V0cygiTEFZT1VUTElTVCIpXSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgifSIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiaWRlbnRpZmllciIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGV4KCJJZGVudGlmaWVyIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(4886, 0, "Identifier", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiaWRlbnRpZmllciIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGV4KCJJZGVudGlmaWVyIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgidm9pZCIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGl0KCJ2b2lkIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(4889, 0, cHJvZChsaXQoInZvaWQiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExOCwxMTgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMCwxMDApXSldLHt9KQ0000, new int[] {118,111,105,100}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgidm9pZCIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGl0KCJ2b2lkIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiaW50Iixzb3J0KCJUeXBlU3BlY2lmaWVyIikpLFtsaXQoImludCIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(4892, 0, cHJvZChsaXQoImludCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKV0se30p, new int[] {105,110,116}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiaW50Iixzb3J0KCJUeXBlU3BlY2lmaWVyIikpLFtsaXQoImludCIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgidW5pb24iLHNvcnQoIlR5cGVTcGVjaWZpZXIiKSksW2xpdCgidW5pb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGV4KCJJZGVudGlmaWVyIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[0] = new LiteralStackNode<IConstructor>(4895, 0, cHJvZChsaXQoInVuaW9uIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pXSx7fSk00, new int[] {117,110,105,111,110}, null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(4897, 2, "Identifier", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(4896, 1, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgidW5pb24iLHNvcnQoIlR5cGVTcGVjaWZpZXIiKSksW2xpdCgidW5pb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGV4KCJJZGVudGlmaWVyIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgic3RydWN0RGVjbCIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGl0KCJzdHJ1Y3QiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGV4KCJJZGVudGlmaWVyIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgieyIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RydWN0RGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgifSIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[9];
      
      tmp[0] = new LiteralStackNode<IConstructor>(4900, 0, cHJvZChsaXQoInN0cnVjdCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE3LDExNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSldLHt9KQ0000, new int[] {115,116,114,117,99,116}, null, null);
      tmp[4] = new LiteralStackNode<IConstructor>(4904, 4, cHJvZChsaXQoInsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEyMywxMjMpXSldLHt9KQ0000, new int[] {123}, null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(4902, 2, "Identifier", null, null);
      tmp[6] = new SeparatedListStackNode<IConstructor>(4908, 6, cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RydWN0RGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkp, new NonTerminalStackNode<IConstructor>(4906, 0, "StructDeclaration", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(4907, 1, "layouts_LAYOUTLIST", null, null)}, false, null, null);
      tmp[8] = new LiteralStackNode<IConstructor>(4910, 8, cHJvZChsaXQoIn0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEyNSwxMjUpXSldLHt9KQ0000, new int[] {125}, null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(4903, 3, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(4901, 1, "layouts_LAYOUTLIST", null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(4905, 5, "layouts_LAYOUTLIST", null, null);
      tmp[7] = new NonTerminalStackNode<IConstructor>(4909, 7, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgic3RydWN0RGVjbCIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGl0KCJzdHJ1Y3QiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGV4KCJJZGVudGlmaWVyIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgieyIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RydWN0RGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgifSIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiZmxvYXQiLHNvcnQoIlR5cGVTcGVjaWZpZXIiKSksW2xpdCgiZmxvYXQiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(4913, 0, cHJvZChsaXQoImZsb2F0IiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMDIsMTAyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKV0se30p, new int[] {102,108,111,97,116}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiZmxvYXQiLHNvcnQoIlR5cGVTcGVjaWZpZXIiKSksW2xpdCgiZmxvYXQiKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiZW51bUFub25EZWNsIixzb3J0KCJUeXBlU3BlY2lmaWVyIikpLFtsaXQoImVudW0iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ7IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXNlcHMoc29ydCgiRW51bWVyYXRvciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIsIiksbGF5b3V0cygiTEFZT1VUTElTVCIpXSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgifSIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[7];
      
      tmp[5] = new NonTerminalStackNode<IConstructor>(4925, 5, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(4917, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(4919, 3, "layouts_LAYOUTLIST", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(4918, 2, cHJvZChsaXQoInsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEyMywxMjMpXSldLHt9KQ0000, new int[] {123}, null, null);
      tmp[6] = new LiteralStackNode<IConstructor>(4926, 6, cHJvZChsaXQoIn0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEyNSwxMjUpXSldLHt9KQ0000, new int[] {125}, null, null);
      tmp[4] = new SeparatedListStackNode<IConstructor>(4924, 4, cmVndWxhcihcaXRlci1zZXBzKHNvcnQoIkVudW1lcmF0b3IiKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgiLCIpLGxheW91dHMoIkxBWU9VVExJU1QiKV0pKQ0000, new NonTerminalStackNode<IConstructor>(4920, 0, "Enumerator", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(4921, 1, "layouts_LAYOUTLIST", null, null), new LiteralStackNode<IConstructor>(4922, 2, cHJvZChsaXQoIiwiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pXSx7fSk00, new int[] {44}, null, null), new NonTerminalStackNode<IConstructor>(4923, 3, "layouts_LAYOUTLIST", null, null)}, true, null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(4916, 0, cHJvZChsaXQoImVudW0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNywxMTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSldLHt9KQ0000, new int[] {101,110,117,109}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiZW51bUFub25EZWNsIixzb3J0KCJUeXBlU3BlY2lmaWVyIikpLFtsaXQoImVudW0iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ7IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXNlcHMoc29ydCgiRW51bWVyYXRvciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIsIiksbGF5b3V0cygiTEFZT1VUTElTVCIpXSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgifSIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgibG9uZyIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGl0KCJsb25nIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(4929, 0, cHJvZChsaXQoImxvbmciKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSldLHt9KQ0000, new int[] {108,111,110,103}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgibG9uZyIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGl0KCJsb25nIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiZG91YmxlIixzb3J0KCJUeXBlU3BlY2lmaWVyIikpLFtsaXQoImRvdWJsZSIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(4932, 0, cHJvZChsaXQoImRvdWJsZSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTAwLDEwMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE3LDExNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTgsOTgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSldLHt9KQ0000, new int[] {100,111,117,98,108,101}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiZG91YmxlIixzb3J0KCJUeXBlU3BlY2lmaWVyIikpLFtsaXQoImRvdWJsZSIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgidW5pb25Bbm9uRGVjbCIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGl0KCJ1bmlvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoInsiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0cnVjdERlY2xhcmF0aW9uIiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIn0iKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[7];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(4936, 1, "layouts_LAYOUTLIST", null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(4942, 5, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(4938, 3, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(4935, 0, cHJvZChsaXQoInVuaW9uIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pXSx7fSk00, new int[] {117,110,105,111,110}, null, null);
      tmp[6] = new LiteralStackNode<IConstructor>(4943, 6, cHJvZChsaXQoIn0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEyNSwxMjUpXSldLHt9KQ0000, new int[] {125}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(4937, 2, cHJvZChsaXQoInsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEyMywxMjMpXSldLHt9KQ0000, new int[] {123}, null, null);
      tmp[4] = new SeparatedListStackNode<IConstructor>(4941, 4, cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RydWN0RGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkp, new NonTerminalStackNode<IConstructor>(4939, 0, "StructDeclaration", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(4940, 1, "layouts_LAYOUTLIST", null, null)}, false, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgidW5pb25Bbm9uRGVjbCIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGl0KCJ1bmlvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoInsiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0cnVjdERlY2xhcmF0aW9uIiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIn0iKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiZW51bSIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGl0KCJlbnVtIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxleCgiSWRlbnRpZmllciIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(4947, 1, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(4946, 0, cHJvZChsaXQoImVudW0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNywxMTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSldLHt9KQ0000, new int[] {101,110,117,109}, null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(4948, 2, "Identifier", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiZW51bSIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGl0KCJlbnVtIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxleCgiSWRlbnRpZmllciIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJUeXBlU3BlY2lmaWVyIiksW2xpdCgic2lnbmVkIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(4950, 0, cHJvZChsaXQoInNpZ25lZCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAzLDEwMyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAwLDEwMCldKV0se30p, new int[] {115,105,103,110,101,100}, null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJUeXBlU3BlY2lmaWVyIiksW2xpdCgic2lnbmVkIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgidW5pb25EZWNsIixzb3J0KCJUeXBlU3BlY2lmaWVyIikpLFtsaXQoInVuaW9uIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxleCgiSWRlbnRpZmllciIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoInsiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0cnVjdERlY2xhcmF0aW9uIiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIn0iKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[9];
      
      tmp[7] = new NonTerminalStackNode<IConstructor>(4962, 7, "layouts_LAYOUTLIST", null, null);
      tmp[8] = new LiteralStackNode<IConstructor>(4963, 8, cHJvZChsaXQoIn0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEyNSwxMjUpXSldLHt9KQ0000, new int[] {125}, null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(4958, 5, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(4954, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(4956, 3, "layouts_LAYOUTLIST", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(4953, 0, cHJvZChsaXQoInVuaW9uIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pXSx7fSk00, new int[] {117,110,105,111,110}, null, null);
      tmp[6] = new SeparatedListStackNode<IConstructor>(4961, 6, cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RydWN0RGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkp, new NonTerminalStackNode<IConstructor>(4959, 0, "StructDeclaration", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(4960, 1, "layouts_LAYOUTLIST", null, null)}, false, null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(4955, 2, "Identifier", null, null);
      tmp[4] = new LiteralStackNode<IConstructor>(4957, 4, cHJvZChsaXQoInsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEyMywxMjMpXSldLHt9KQ0000, new int[] {123}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgidW5pb25EZWNsIixzb3J0KCJUeXBlU3BlY2lmaWVyIikpLFtsaXQoInVuaW9uIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxleCgiSWRlbnRpZmllciIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoInsiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0cnVjdERlY2xhcmF0aW9uIiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIn0iKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgic2hvcnQiLHNvcnQoIlR5cGVTcGVjaWZpZXIiKSksW2xpdCgic2hvcnQiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(4966, 0, cHJvZChsaXQoInNob3J0IiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDQsMTA0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pXSx7fSk00, new int[] {115,104,111,114,116}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgic2hvcnQiLHNvcnQoIlR5cGVTcGVjaWZpZXIiKSksW2xpdCgic2hvcnQiKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgic3RydWN0QW5vbkRlY2wiLHNvcnQoIlR5cGVTcGVjaWZpZXIiKSksW2xpdCgic3RydWN0IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgieyIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RydWN0RGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgifSIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[7];
      
      tmp[2] = new LiteralStackNode<IConstructor>(4971, 2, cHJvZChsaXQoInsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEyMywxMjMpXSldLHt9KQ0000, new int[] {123}, null, null);
      tmp[6] = new LiteralStackNode<IConstructor>(4977, 6, cHJvZChsaXQoIn0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEyNSwxMjUpXSldLHt9KQ0000, new int[] {125}, null, null);
      tmp[4] = new SeparatedListStackNode<IConstructor>(4975, 4, cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RydWN0RGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSkp, new NonTerminalStackNode<IConstructor>(4973, 0, "StructDeclaration", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(4974, 1, "layouts_LAYOUTLIST", null, null)}, false, null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(4969, 0, cHJvZChsaXQoInN0cnVjdCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE3LDExNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSldLHt9KQ0000, new int[] {115,116,114,117,99,116}, null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(4976, 5, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(4970, 1, "layouts_LAYOUTLIST", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(4972, 3, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgic3RydWN0QW5vbkRlY2wiLHNvcnQoIlR5cGVTcGVjaWZpZXIiKSksW2xpdCgic3RydWN0IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgieyIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RydWN0RGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgifSIpXSx7fSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiY2hhciIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGl0KCJjaGFyIildLHt9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJUeXBlU3BlY2lmaWVyIiksW2xpdCgidW5zaWduZWQiKV0se30p(builder);
      
        _init_cHJvZChsYWJlbCgic3RydWN0Iixzb3J0KCJUeXBlU3BlY2lmaWVyIikpLFtsaXQoInN0cnVjdCIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsZXgoIklkZW50aWZpZXIiKV0se30p(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJUeXBlU3BlY2lmaWVyIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlR5cGVTcGVjaWZpZXJcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlR5cGVTcGVjaWZpZXIiKSkpfSk00(builder);
      
        _init_cHJvZChsYWJlbCgiZW51bURlY2wiLHNvcnQoIlR5cGVTcGVjaWZpZXIiKSksW2xpdCgiZW51bSIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsZXgoIklkZW50aWZpZXIiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ7IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXNlcHMoc29ydCgiRW51bWVyYXRvciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIsIiksbGF5b3V0cygiTEFZT1VUTElTVCIpXSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgifSIpXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgiaWRlbnRpZmllciIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGV4KCJJZGVudGlmaWVyIildLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgidm9pZCIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGl0KCJ2b2lkIildLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiaW50Iixzb3J0KCJUeXBlU3BlY2lmaWVyIikpLFtsaXQoImludCIpXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgidW5pb24iLHNvcnQoIlR5cGVTcGVjaWZpZXIiKSksW2xpdCgidW5pb24iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGV4KCJJZGVudGlmaWVyIildLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgic3RydWN0RGVjbCIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGl0KCJzdHJ1Y3QiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGV4KCJJZGVudGlmaWVyIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgieyIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RydWN0RGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgifSIpXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgiZmxvYXQiLHNvcnQoIlR5cGVTcGVjaWZpZXIiKSksW2xpdCgiZmxvYXQiKV0se30p(builder);
      
        _init_cHJvZChsYWJlbCgiZW51bUFub25EZWNsIixzb3J0KCJUeXBlU3BlY2lmaWVyIikpLFtsaXQoImVudW0iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCJ7IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLFxpdGVyLXNlcHMoc29ydCgiRW51bWVyYXRvciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIiksbGl0KCIsIiksbGF5b3V0cygiTEFZT1VUTElTVCIpXSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgifSIpXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgibG9uZyIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGl0KCJsb25nIildLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiZG91YmxlIixzb3J0KCJUeXBlU3BlY2lmaWVyIikpLFtsaXQoImRvdWJsZSIpXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgidW5pb25Bbm9uRGVjbCIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGl0KCJ1bmlvbiIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoInsiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0cnVjdERlY2xhcmF0aW9uIiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIn0iKV0se30p(builder);
      
        _init_cHJvZChsYWJlbCgiZW51bSIsc29ydCgiVHlwZVNwZWNpZmllciIpKSxbbGl0KCJlbnVtIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxleCgiSWRlbnRpZmllciIpXSx7fSk00(builder);
      
        _init_cHJvZChzb3J0KCJUeXBlU3BlY2lmaWVyIiksW2xpdCgic2lnbmVkIildLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgidW5pb25EZWNsIixzb3J0KCJUeXBlU3BlY2lmaWVyIikpLFtsaXQoInVuaW9uIiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxleCgiSWRlbnRpZmllciIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoInsiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0cnVjdERlY2xhcmF0aW9uIiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIn0iKV0se30p(builder);
      
        _init_cHJvZChsYWJlbCgic2hvcnQiLHNvcnQoIlR5cGVTcGVjaWZpZXIiKSksW2xpdCgic2hvcnQiKV0se30p(builder);
      
        _init_cHJvZChsYWJlbCgic3RydWN0QW5vbkRlY2wiLHNvcnQoIlR5cGVTcGVjaWZpZXIiKSksW2xpdCgic3RydWN0IiksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgieyIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RydWN0RGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTEFZT1VUTElTVCIpXSksbGF5b3V0cygiTEFZT1VUTElTVCIpLGxpdCgifSIpXSx7fSk00(builder);
      
    }
  }
	
  protected static class Enumerator {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFbnVtZXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkVudW1lcmF0b3JcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIkVudW1lcmF0b3IiKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new ListStackNode<IConstructor>(5036, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(5035, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[4] = new CharStackNode<IConstructor>(5037, 4, new int[][]{{0,0}}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(5032, 0, new int[][]{{0,0}}, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(5033, 1, cHJvZChsaXQoInNvcnQoXCJFbnVtZXJhdG9yXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY5LDY5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {115,111,114,116,40,34,69,110,117,109,101,114,97,116,111,114,34,41}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(5034, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFbnVtZXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkVudW1lcmF0b3JcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIkVudW1lcmF0b3IiKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFbnVtZXJhdG9yIiksW2xleCgiSWRlbnRpZmllciIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(5040, 0, "Identifier", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFbnVtZXJhdG9yIiksW2xleCgiSWRlbnRpZmllciIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFbnVtZXJhdG9yIiksW2xleCgiSWRlbnRpZmllciIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIj0iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiTm9uQ29tbWFFeHByZXNzaW9uIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new NonTerminalStackNode<IConstructor>(5046, 4, "NonCommaExpression", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(5042, 0, "Identifier", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(5045, 3, "layouts_LAYOUTLIST", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(5044, 2, cHJvZChsaXQoIj0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDYxLDYxKV0pXSx7fSk00, new int[] {61}, null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(5043, 1, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJFbnVtZXJhdG9yIiksW2xleCgiSWRlbnRpZmllciIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIj0iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiTm9uQ29tbWFFeHByZXNzaW9uIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFbnVtZXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiXFxpdGVyLXNlcHMoc29ydChcIkVudW1lcmF0b3JcIiksW2xpdChcIixcIildKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc2Vwcyhzb3J0KCJFbnVtZXJhdG9yIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new CharStackNode<IConstructor>(5049, 0, new int[][]{{0,0}}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(5054, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(5051, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(5053, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(5052, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(5050, 1, cHJvZChsaXQoIlxcaXRlci1zZXBzKHNvcnQoXCJFbnVtZXJhdG9yXCIpLFtsaXQoXCIsXCIpXSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkyLDkyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEyLDExMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjksNjkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNywxMTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5MSw5MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Myw5MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000, new int[] {92,105,116,101,114,45,115,101,112,115,40,115,111,114,116,40,34,69,110,117,109,101,114,97,116,111,114,34,41,44,91,108,105,116,40,34,44,34,41,93,41}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFbnVtZXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiXFxpdGVyLXNlcHMoc29ydChcIkVudW1lcmF0b3JcIiksW2xpdChcIixcIildKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc2Vwcyhzb3J0KCJFbnVtZXJhdG9yIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFbnVtZXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkVudW1lcmF0b3JcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIkVudW1lcmF0b3IiKSkpfSk00(builder);
      
        _init_cHJvZChzb3J0KCJFbnVtZXJhdG9yIiksW2xleCgiSWRlbnRpZmllciIpXSx7fSk00(builder);
      
        _init_cHJvZChzb3J0KCJFbnVtZXJhdG9yIiksW2xleCgiSWRlbnRpZmllciIpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIj0iKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiTm9uQ29tbWFFeHByZXNzaW9uIildLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFbnVtZXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiXFxpdGVyLXNlcHMoc29ydChcIkVudW1lcmF0b3JcIiksW2xpdChcIixcIildKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc2Vwcyhzb3J0KCJFbnVtZXJhdG9yIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(builder);
      
    }
  }
	
  protected static class HexadecimalConstant {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsZXgoIkhleGFkZWNpbWFsQ29uc3RhbnQiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDQ4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4OCw4OCkscmFuZ2UoMTIwLDEyMCldKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NykscmFuZ2UoNjUsNzApLHJhbmdlKDk3LDEwMildKSksY29uZGl0aW9uYWwoXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoNzYsNzYpLHJhbmdlKDg1LDg1KSxyYW5nZSgxMDgsMTA4KSxyYW5nZSgxMTcsMTE3KV0pKSx7XG5vdC1mb2xsb3coXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KSxyYW5nZSg2NSw3MCkscmFuZ2UoOTcsMTAyKV0pKX0pXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[4];
      
      tmp[3] = new ListStackNode<IConstructor>(5125, 3, cmVndWxhcihcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSg3Niw3NikscmFuZ2UoODUsODUpLHJhbmdlKDEwOCwxMDgpLHJhbmdlKDExNywxMTcpXSkpKQ0000, new CharStackNode<IConstructor>(5122, 0, new int[][]{{76,76},{85,85},{108,108},{117,117}}, null, null), false, null, new ICompletionFilter[] {new CharFollowRestriction(new int[][]{{48,57},{65,70},{97,102}})});
      tmp[1] = new CharStackNode<IConstructor>(5119, 1, new int[][]{{88,88},{120,120}}, null, null);
      tmp[2] = new ListStackNode<IConstructor>(5121, 2, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NykscmFuZ2UoNjUsNzApLHJhbmdlKDk3LDEwMildKSkp, new CharStackNode<IConstructor>(5120, 0, new int[][]{{48,57},{65,70},{97,102}}, null, null), true, null, null);
      tmp[0] = new CharStackNode<IConstructor>(5118, 0, new int[][]{{48,48}}, null, null);
      builder.addAlternative(CParser.cHJvZChsZXgoIkhleGFkZWNpbWFsQ29uc3RhbnQiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDQ4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4OCw4OCkscmFuZ2UoMTIwLDEyMCldKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NykscmFuZ2UoNjUsNzApLHJhbmdlKDk3LDEwMildKSksY29uZGl0aW9uYWwoXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoNzYsNzYpLHJhbmdlKDg1LDg1KSxyYW5nZSgxMDgsMTA4KSxyYW5nZSgxMTcsMTE3KV0pKSx7XG5vdC1mb2xsb3coXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KSxyYW5nZSg2NSw3MCkscmFuZ2UoOTcsMTAyKV0pKX0pXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkhleGFkZWNpbWFsQ29uc3RhbnQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiSGV4YWRlY2ltYWxDb25zdGFudFwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIobGV4KCJIZXhhZGVjaW1hbENvbnN0YW50IikpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new ListStackNode<IConstructor>(5132, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(5131, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(5129, 1, cHJvZChsaXQoInNvcnQoXCJIZXhhZGVjaW1hbENvbnN0YW50XCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDcyLDcyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjAsMTIwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAwLDEwMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2Nyw2NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {115,111,114,116,40,34,72,101,120,97,100,101,99,105,109,97,108,67,111,110,115,116,97,110,116,34,41}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(5128, 0, new int[][]{{0,0}}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(5133, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(5130, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkhleGFkZWNpbWFsQ29uc3RhbnQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiSGV4YWRlY2ltYWxDb25zdGFudFwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIobGV4KCJIZXhhZGVjaW1hbENvbnN0YW50IikpKX0p, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsZXgoIkhleGFkZWNpbWFsQ29uc3RhbnQiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDQ4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4OCw4OCkscmFuZ2UoMTIwLDEyMCldKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NykscmFuZ2UoNjUsNzApLHJhbmdlKDk3LDEwMildKSksY29uZGl0aW9uYWwoXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoNzYsNzYpLHJhbmdlKDg1LDg1KSxyYW5nZSgxMDgsMTA4KSxyYW5nZSgxMTcsMTE3KV0pKSx7XG5vdC1mb2xsb3coXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KSxyYW5nZSg2NSw3MCkscmFuZ2UoOTcsMTAyKV0pKX0pXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkhleGFkZWNpbWFsQ29uc3RhbnQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiSGV4YWRlY2ltYWxDb25zdGFudFwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIobGV4KCJIZXhhZGVjaW1hbENvbnN0YW50IikpKX0p(builder);
      
    }
  }
	
  protected static class PrototypeParameter {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc2Vwcyhzb3J0KFwiUHJvdG90eXBlUGFyYW1ldGVyXCIpLFtsaXQoXCIsXCIpXSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXNlcHMoc29ydCgiUHJvdG90eXBlUGFyYW1ldGVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new CharStackNode<IConstructor>(5179, 4, new int[][]{{0,0}}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(5178, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(5177, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(5175, 1, cHJvZChsaXQoIlxcaXRlci1zZXBzKHNvcnQoXCJQcm90b3R5cGVQYXJhbWV0ZXJcIiksW2xpdChcIixcIildKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoOTIsOTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ1LDQ1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4MCw4MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTIxLDEyMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEyLDExMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODAsODApXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA5LDEwOSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTEsOTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTMsOTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {92,105,116,101,114,45,115,101,112,115,40,115,111,114,116,40,34,80,114,111,116,111,116,121,112,101,80,97,114,97,109,101,116,101,114,34,41,44,91,108,105,116,40,34,44,34,41,93,41}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(5176, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(5174, 0, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc2Vwcyhzb3J0KFwiUHJvdG90eXBlUGFyYW1ldGVyXCIpLFtsaXQoXCIsXCIpXSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXNlcHMoc29ydCgiUHJvdG90eXBlUGFyYW1ldGVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXIiKSxbXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiQWJzdHJhY3REZWNsYXJhdG9yIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[2] = new NonTerminalStackNode<IConstructor>(5190, 2, "AbstractDeclarator", null, null);
      tmp[0] = new SeparatedListStackNode<IConstructor>(5188, 0, cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiU3BlY2lmaWVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKV0pKQ0000, new NonTerminalStackNode<IConstructor>(5186, 0, "Specifier", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(5187, 1, "layouts_LAYOUTLIST", null, null)}, false, null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(5189, 1, "layouts_LAYOUTLIST", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXIiKSxbXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiQWJzdHJhY3REZWNsYXJhdG9yIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiUHJvdG90eXBlUGFyYW1ldGVyXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXIiKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new CharStackNode<IConstructor>(5198, 4, new int[][]{{0,0}}, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(5194, 1, cHJvZChsaXQoInNvcnQoXCJQcm90b3R5cGVQYXJhbWV0ZXJcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODAsODApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEyMSwxMjEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMiwxMTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDgwLDgwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {115,111,114,116,40,34,80,114,111,116,111,116,121,112,101,80,97,114,97,109,101,116,101,114,34,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(5197, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(5196, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[0] = new CharStackNode<IConstructor>(5193, 0, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(5195, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiUHJvdG90eXBlUGFyYW1ldGVyXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXIiKSkpfSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc2Vwcyhzb3J0KFwiUHJvdG90eXBlUGFyYW1ldGVyXCIpLFtsaXQoXCIsXCIpXSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXNlcHMoc29ydCgiUHJvdG90eXBlUGFyYW1ldGVyIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(builder);
      
        _init_cHJvZChzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXIiKSxbXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlNwZWNpZmllciIpLFtsYXlvdXRzKCJMQVlPVVRMSVNUIildKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiQWJzdHJhY3REZWNsYXJhdG9yIildLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXIiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiUHJvdG90eXBlUGFyYW1ldGVyXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJQcm90b3R5cGVQYXJhbWV0ZXIiKSkpfSk00(builder);
      
    }
  }
	
  protected static class Exponent {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsZXgoIkV4cG9uZW50IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg2OSw2OSkscmFuZ2UoMTAxLDEwMSldKSxvcHQoXGNoYXItY2xhc3MoW3JhbmdlKDQzLDQzKSxyYW5nZSg0NSw0NSldKSksY29uZGl0aW9uYWwoaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLHtcbm90LWZvbGxvdyhcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpfSldLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[1] = new OptionalStackNode<IConstructor>(5255, 1, cmVndWxhcihvcHQoXGNoYXItY2xhc3MoW3JhbmdlKDQzLDQzKSxyYW5nZSg0NSw0NSldKSkp, new CharStackNode<IConstructor>(5254, 0, new int[][]{{43,43},{45,45}}, null, null), null, null);
      tmp[0] = new CharStackNode<IConstructor>(5253, 0, new int[][]{{69,69},{101,101}}, null, null);
      tmp[2] = new ListStackNode<IConstructor>(5259, 2, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(5256, 0, new int[][]{{48,57}}, null, null), true, null, new ICompletionFilter[] {new CharFollowRestriction(new int[][]{{48,57}})});
      builder.addAlternative(CParser.cHJvZChsZXgoIkV4cG9uZW50IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg2OSw2OSkscmFuZ2UoMTAxLDEwMSldKSxvcHQoXGNoYXItY2xhc3MoW3JhbmdlKDQzLDQzKSxyYW5nZSg0NSw0NSldKSksY29uZGl0aW9uYWwoaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLHtcbm90LWZvbGxvdyhcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpfSldLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkV4cG9uZW50IikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkV4cG9uZW50XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihsZXgoIkV4cG9uZW50IikpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new CharStackNode<IConstructor>(5262, 0, new int[][]{{0,0}}, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(5263, 1, cHJvZChsaXQoInNvcnQoXCJFeHBvbmVudFwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2OSw2OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTIwLDEyMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEyLDExMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {115,111,114,116,40,34,69,120,112,111,110,101,110,116,34,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(5266, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(5265, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(5264, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(5267, 4, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkV4cG9uZW50IikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkV4cG9uZW50XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihsZXgoIkV4cG9uZW50IikpKX0p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkV4cG9uZW50IikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgib3B0KHNvcnQoXCJFeHBvbmVudFwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKG9wdChsZXgoIkV4cG9uZW50IikpKSl9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new CharStackNode<IConstructor>(5271, 0, new int[][]{{0,0}}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(5275, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(5274, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(5272, 1, cHJvZChsaXQoIm9wdChzb3J0KFwiRXhwb25lbnRcIikpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2OSw2OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTIwLDEyMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEyLDExMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {111,112,116,40,115,111,114,116,40,34,69,120,112,111,110,101,110,116,34,41,41}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(5276, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(5273, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkV4cG9uZW50IikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgib3B0KHNvcnQoXCJFeHBvbmVudFwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKG9wdChsZXgoIkV4cG9uZW50IikpKSl9KQ0000, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsZXgoIkV4cG9uZW50IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg2OSw2OSkscmFuZ2UoMTAxLDEwMSldKSxvcHQoXGNoYXItY2xhc3MoW3JhbmdlKDQzLDQzKSxyYW5nZSg0NSw0NSldKSksY29uZGl0aW9uYWwoaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLHtcbm90LWZvbGxvdyhcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpfSldLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkV4cG9uZW50IikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkV4cG9uZW50XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihsZXgoIkV4cG9uZW50IikpKX0p(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkV4cG9uZW50IikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgib3B0KHNvcnQoXCJFeHBvbmVudFwiKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKG9wdChsZXgoIkV4cG9uZW50IikpKSl9KQ0000(builder);
      
    }
  }
	
  protected static class FloatingPointConstant {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkZsb2F0aW5nUG9pbnRDb25zdGFudCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJGbG9hdGluZ1BvaW50Q29uc3RhbnRcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGxleCgiRmxvYXRpbmdQb2ludENvbnN0YW50IikpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new ListStackNode<IConstructor>(5418, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(5417, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(5415, 1, cHJvZChsaXQoInNvcnQoXCJGbG9hdGluZ1BvaW50Q29uc3RhbnRcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNzAsNzApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4MCw4MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjcsNjcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000, new int[] {115,111,114,116,40,34,70,108,111,97,116,105,110,103,80,111,105,110,116,67,111,110,115,116,97,110,116,34,41}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(5416, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(5414, 0, new int[][]{{0,0}}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(5419, 4, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkZsb2F0aW5nUG9pbnRDb25zdGFudCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJGbG9hdGluZ1BvaW50Q29uc3RhbnRcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGxleCgiRmxvYXRpbmdQb2ludENvbnN0YW50IikpKX0p, tmp);
	}
    protected static final void _init_cHJvZChsZXgoIkZsb2F0aW5nUG9pbnRDb25zdGFudCIpLFtcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDQ2LDQ2KV0pLGNvbmRpdGlvbmFsKGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSx7XG5vdC1mb2xsb3coXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKX0pLG9wdChsZXgoIkV4cG9uZW50IikpLG9wdChcY2hhci1jbGFzcyhbcmFuZ2UoNzAsNzApLHJhbmdlKDc2LDc2KSxyYW5nZSgxMDIsMTAyKSxyYW5nZSgxMDgsMTA4KV0pKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[2] = new ListStackNode<IConstructor>(5428, 2, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(5425, 0, new int[][]{{48,57}}, null, null), true, null, new ICompletionFilter[] {new CharFollowRestriction(new int[][]{{48,57}})});
      tmp[4] = new OptionalStackNode<IConstructor>(5432, 4, cmVndWxhcihvcHQoXGNoYXItY2xhc3MoW3JhbmdlKDcwLDcwKSxyYW5nZSg3Niw3NikscmFuZ2UoMTAyLDEwMikscmFuZ2UoMTA4LDEwOCldKSkp, new CharStackNode<IConstructor>(5431, 0, new int[][]{{70,70},{76,76},{102,102},{108,108}}, null, null), null, null);
      tmp[0] = new ListStackNode<IConstructor>(5423, 0, cmVndWxhcihcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(5422, 0, new int[][]{{48,57}}, null, null), false, null, null);
      tmp[1] = new CharStackNode<IConstructor>(5424, 1, new int[][]{{46,46}}, null, null);
      tmp[3] = new OptionalStackNode<IConstructor>(5430, 3, cmVndWxhcihvcHQobGV4KCJFeHBvbmVudCIpKSk00, new NonTerminalStackNode<IConstructor>(5429, 0, "Exponent", null, null), null, null);
      builder.addAlternative(CParser.cHJvZChsZXgoIkZsb2F0aW5nUG9pbnRDb25zdGFudCIpLFtcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDQ2LDQ2KV0pLGNvbmRpdGlvbmFsKGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSx7XG5vdC1mb2xsb3coXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKX0pLG9wdChsZXgoIkV4cG9uZW50IikpLG9wdChcY2hhci1jbGFzcyhbcmFuZ2UoNzAsNzApLHJhbmdlKDc2LDc2KSxyYW5nZSgxMDIsMTAyKSxyYW5nZSgxMDgsMTA4KV0pKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChsZXgoIkZsb2F0aW5nUG9pbnRDb25zdGFudCIpLFtpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDQ2LDQ2KV0pLG9wdChsZXgoIkV4cG9uZW50IikpLG9wdChcY2hhci1jbGFzcyhbcmFuZ2UoNzAsNzApLHJhbmdlKDc2LDc2KSxyYW5nZSgxMDIsMTAyKSxyYW5nZSgxMDgsMTA4KV0pKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[4];
      
      tmp[1] = new CharStackNode<IConstructor>(5436, 1, new int[][]{{46,46}}, null, null);
      tmp[2] = new OptionalStackNode<IConstructor>(5438, 2, cmVndWxhcihvcHQobGV4KCJFeHBvbmVudCIpKSk00, new NonTerminalStackNode<IConstructor>(5437, 0, "Exponent", null, null), null, null);
      tmp[0] = new ListStackNode<IConstructor>(5435, 0, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(5434, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[3] = new OptionalStackNode<IConstructor>(5440, 3, cmVndWxhcihvcHQoXGNoYXItY2xhc3MoW3JhbmdlKDcwLDcwKSxyYW5nZSg3Niw3NikscmFuZ2UoMTAyLDEwMikscmFuZ2UoMTA4LDEwOCldKSkp, new CharStackNode<IConstructor>(5439, 0, new int[][]{{70,70},{76,76},{102,102},{108,108}}, null, null), null, null);
      builder.addAlternative(CParser.cHJvZChsZXgoIkZsb2F0aW5nUG9pbnRDb25zdGFudCIpLFtpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDQ2LDQ2KV0pLG9wdChsZXgoIkV4cG9uZW50IikpLG9wdChcY2hhci1jbGFzcyhbcmFuZ2UoNzAsNzApLHJhbmdlKDc2LDc2KSxyYW5nZSgxMDIsMTAyKSxyYW5nZSgxMDgsMTA4KV0pKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChsZXgoIkZsb2F0aW5nUG9pbnRDb25zdGFudCIpLFtpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksbGV4KCJFeHBvbmVudCIpLG9wdChcY2hhci1jbGFzcyhbcmFuZ2UoNzAsNzApLHJhbmdlKDc2LDc2KSxyYW5nZSgxMDIsMTAyKSxyYW5nZSgxMDgsMTA4KV0pKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(5444, 1, "Exponent", null, null);
      tmp[0] = new ListStackNode<IConstructor>(5443, 0, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(5442, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[2] = new OptionalStackNode<IConstructor>(5446, 2, cmVndWxhcihvcHQoXGNoYXItY2xhc3MoW3JhbmdlKDcwLDcwKSxyYW5nZSg3Niw3NikscmFuZ2UoMTAyLDEwMikscmFuZ2UoMTA4LDEwOCldKSkp, new CharStackNode<IConstructor>(5445, 0, new int[][]{{70,70},{76,76},{102,102},{108,108}}, null, null), null, null);
      builder.addAlternative(CParser.cHJvZChsZXgoIkZsb2F0aW5nUG9pbnRDb25zdGFudCIpLFtpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksbGV4KCJFeHBvbmVudCIpLG9wdChcY2hhci1jbGFzcyhbcmFuZ2UoNzAsNzApLHJhbmdlKDc2LDc2KSxyYW5nZSgxMDIsMTAyKSxyYW5nZSgxMDgsMTA4KV0pKV0se30p, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIkZsb2F0aW5nUG9pbnRDb25zdGFudCIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJGbG9hdGluZ1BvaW50Q29uc3RhbnRcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGxleCgiRmxvYXRpbmdQb2ludENvbnN0YW50IikpKX0p(builder);
      
        _init_cHJvZChsZXgoIkZsb2F0aW5nUG9pbnRDb25zdGFudCIpLFtcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDQ2LDQ2KV0pLGNvbmRpdGlvbmFsKGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSx7XG5vdC1mb2xsb3coXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKX0pLG9wdChsZXgoIkV4cG9uZW50IikpLG9wdChcY2hhci1jbGFzcyhbcmFuZ2UoNzAsNzApLHJhbmdlKDc2LDc2KSxyYW5nZSgxMDIsMTAyKSxyYW5nZSgxMDgsMTA4KV0pKV0se30p(builder);
      
        _init_cHJvZChsZXgoIkZsb2F0aW5nUG9pbnRDb25zdGFudCIpLFtpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDQ2LDQ2KV0pLG9wdChsZXgoIkV4cG9uZW50IikpLG9wdChcY2hhci1jbGFzcyhbcmFuZ2UoNzAsNzApLHJhbmdlKDc2LDc2KSxyYW5nZSgxMDIsMTAyKSxyYW5nZSgxMDgsMTA4KV0pKV0se30p(builder);
      
        _init_cHJvZChsZXgoIkZsb2F0aW5nUG9pbnRDb25zdGFudCIpLFtpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksbGV4KCJFeHBvbmVudCIpLG9wdChcY2hhci1jbGFzcyhbcmFuZ2UoNzAsNzApLHJhbmdlKDc2LDc2KSxyYW5nZSgxMDIsMTAyKSxyYW5nZSgxMDgsMTA4KV0pKV0se30p(builder);
      
    }
  }
	
  protected static class StructDeclarator {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdHJ1Y3REZWNsYXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlN0cnVjdERlY2xhcmF0b3JcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlN0cnVjdERlY2xhcmF0b3IiKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new LiteralStackNode<IConstructor>(5452, 1, cHJvZChsaXQoInNvcnQoXCJTdHJ1Y3REZWNsYXJhdG9yXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDgzLDgzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5OSw5OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjgsNjgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {115,111,114,116,40,34,83,116,114,117,99,116,68,101,99,108,97,114,97,116,111,114,34,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(5455, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(5454, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[4] = new CharStackNode<IConstructor>(5456, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(5453, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(5451, 0, new int[][]{{0,0}}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdHJ1Y3REZWNsYXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlN0cnVjdERlY2xhcmF0b3JcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlN0cnVjdERlY2xhcmF0b3IiKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJTdHJ1Y3REZWNsYXJhdG9yIiksW29wdChzb3J0KCJEZWNsYXJhdG9yIikpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjoiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new NonTerminalStackNode<IConstructor>(5463, 3, "layouts_LAYOUTLIST", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(5461, 1, "layouts_LAYOUTLIST", null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(5464, 4, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(5462, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[0] = new OptionalStackNode<IConstructor>(5460, 0, cmVndWxhcihvcHQoc29ydCgiRGVjbGFyYXRvciIpKSk00, new NonTerminalStackNode<IConstructor>(5459, 0, "Declarator", null, null), null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJTdHJ1Y3REZWNsYXJhdG9yIiksW29wdChzb3J0KCJEZWNsYXJhdG9yIikpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjoiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJTdHJ1Y3REZWNsYXJhdG9yIiksW3NvcnQoIkRlY2xhcmF0b3IiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(5466, 0, "Declarator", null, null);
      builder.addAlternative(CParser.cHJvZChzb3J0KCJTdHJ1Y3REZWNsYXJhdG9yIiksW3NvcnQoIkRlY2xhcmF0b3IiKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdHJ1Y3REZWNsYXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiXFxpdGVyLXNlcHMoc29ydChcIlN0cnVjdERlY2xhcmF0b3JcIiksW2xpdChcIixcIildKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc2Vwcyhzb3J0KCJTdHJ1Y3REZWNsYXJhdG9yIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new ListStackNode<IConstructor>(5473, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(5472, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(5470, 1, cHJvZChsaXQoIlxcaXRlci1zZXBzKHNvcnQoXCJTdHJ1Y3REZWNsYXJhdG9yXCIpLFtsaXQoXCIsXCIpXSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkyLDkyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEyLDExMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODMsODMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNywxMTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2OCw2OCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTEsOTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTMsOTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {92,105,116,101,114,45,115,101,112,115,40,115,111,114,116,40,34,83,116,114,117,99,116,68,101,99,108,97,114,97,116,111,114,34,41,44,91,108,105,116,40,34,44,34,41,93,41}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(5469, 0, new int[][]{{0,0}}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(5474, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(5471, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      builder.addAlternative(CParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdHJ1Y3REZWNsYXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiXFxpdGVyLXNlcHMoc29ydChcIlN0cnVjdERlY2xhcmF0b3JcIiksW2xpdChcIixcIildKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc2Vwcyhzb3J0KCJTdHJ1Y3REZWNsYXJhdG9yIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdHJ1Y3REZWNsYXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlN0cnVjdERlY2xhcmF0b3JcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlN0cnVjdERlY2xhcmF0b3IiKSkpfSk00(builder);
      
        _init_cHJvZChzb3J0KCJTdHJ1Y3REZWNsYXJhdG9yIiksW29wdChzb3J0KCJEZWNsYXJhdG9yIikpLGxheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIjoiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIiksc29ydCgiRXhwcmVzc2lvbiIpXSx7fSk00(builder);
      
        _init_cHJvZChzb3J0KCJTdHJ1Y3REZWNsYXJhdG9yIiksW3NvcnQoIkRlY2xhcmF0b3IiKV0se30p(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdHJ1Y3REZWNsYXJhdG9yIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiXFxpdGVyLXNlcHMoc29ydChcIlN0cnVjdERlY2xhcmF0b3JcIiksW2xpdChcIixcIildKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc2Vwcyhzb3J0KCJTdHJ1Y3REZWNsYXJhdG9yIiksW2xheW91dHMoIkxBWU9VVExJU1QiKSxsaXQoIiwiKSxsYXlvdXRzKCJMQVlPVVRMSVNUIildKSkpfSk00(builder);
      
    }
  }
	
  // Parse methods    
  
  public AbstractStackNode<IConstructor>[] Expression() {
    return Expression.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] layouts_$default$() {
    return layouts_$default$.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] Asterisk() {
    return Asterisk.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] Declaration() {
    return Declaration.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] StorageClass() {
    return StorageClass.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] StringConstant() {
    return StringConstant.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] MoreParameters() {
    return MoreParameters.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] Specifier() {
    return Specifier.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] Declarator() {
    return Declarator.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] TypeQualifier() {
    return TypeQualifier.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] AbstractDeclarator() {
    return AbstractDeclarator.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] PrototypeDeclarator() {
    return PrototypeDeclarator.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] TranslationUnit() {
    return TranslationUnit.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] layouts_LAYOUTLIST() {
    return layouts_LAYOUTLIST.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] Comment() {
    return Comment.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] GlobalDeclaration() {
    return GlobalDeclaration.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] AnonymousIdentifier() {
    return AnonymousIdentifier.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] Parameter() {
    return Parameter.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] Keyword() {
    return Keyword.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] FunctionDefinition() {
    return FunctionDefinition.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] Parameters() {
    return Parameters.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] IntegerConstant() {
    return IntegerConstant.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] FunctionPrototype() {
    return FunctionPrototype.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] MultiLineCommentBodyToken() {
    return MultiLineCommentBodyToken.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] StringConstantContent() {
    return StringConstantContent.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] PrototypeParameters() {
    return PrototypeParameters.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] Statement() {
    return Statement.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] ExternalDeclaration() {
    return ExternalDeclaration.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] InitDeclarator() {
    return InitDeclarator.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] Identifier() {
    return Identifier.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] NonCommaExpression() {
    return NonCommaExpression.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] start__TranslationUnit() {
    return start__TranslationUnit.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] Initializer() {
    return Initializer.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] LAYOUT() {
    return LAYOUT.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] CharacterConstant() {
    return CharacterConstant.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] TypeName() {
    return TypeName.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] StructDeclaration() {
    return StructDeclaration.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] CharacterConstantContent() {
    return CharacterConstantContent.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] TypeSpecifier() {
    return TypeSpecifier.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] Enumerator() {
    return Enumerator.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] HexadecimalConstant() {
    return HexadecimalConstant.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] PrototypeParameter() {
    return PrototypeParameter.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] Exponent() {
    return Exponent.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] FloatingPointConstant() {
    return FloatingPointConstant.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] StructDeclarator() {
    return StructDeclarator.EXPECTS;
  }
}