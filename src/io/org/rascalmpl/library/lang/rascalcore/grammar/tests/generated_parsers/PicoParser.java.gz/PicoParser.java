package org.rascalmpl.library.lang.rascal.grammar.tests.generated_parsers;

import java.io.IOException;
import java.io.StringReader;

import io.usethesource.vallang.type.TypeFactory;
import io.usethesource.vallang.IConstructor;
import io.usethesource.vallang.ISourceLocation;
import io.usethesource.vallang.IValue;
import io.usethesource.vallang.IValueFactory;
import io.usethesource.vallang.exceptions.FactTypeUseException;
import io.usethesource.vallang.io.StandardTextReader;
import org.rascalmpl.parser.gtd.stack.*;
import org.rascalmpl.parser.gtd.stack.filter.*;
import org.rascalmpl.parser.gtd.stack.filter.follow.*;
import org.rascalmpl.parser.gtd.stack.filter.match.*;
import org.rascalmpl.parser.gtd.stack.filter.precede.*;
import org.rascalmpl.parser.gtd.preprocessing.ExpectBuilder;
import org.rascalmpl.parser.gtd.util.IntegerKeyedHashMap;
import org.rascalmpl.parser.gtd.util.IntegerList;
import org.rascalmpl.parser.gtd.util.IntegerMap;
import org.rascalmpl.values.ValueFactoryFactory;
import org.rascalmpl.values.uptr.RascalValueFactory;
import org.rascalmpl.values.uptr.ITree;

@SuppressWarnings("all")
public class PicoParser extends org.rascalmpl.parser.gtd.SGTDBF<IConstructor, ITree, ISourceLocation> {
  protected final static IValueFactory VF = ValueFactoryFactory.getValueFactory();

  protected static IValue _read(java.lang.String s, io.usethesource.vallang.type.Type type) {
    try {
      return new StandardTextReader().read(VF, org.rascalmpl.values.uptr.RascalValueFactory.uptr, type, new StringReader(s));
    }
    catch (FactTypeUseException e) {
      throw new RuntimeException("unexpected exception in generated parser", e);  
    } catch (IOException e) {
      throw new RuntimeException("unexpected exception in generated parser", e);  
    }
  }
	
  protected static java.lang.String _concat(java.lang.String ...args) {
    int length = 0;
    for (java.lang.String s :args) {
      length += s.length();
    }
    java.lang.StringBuilder b = new java.lang.StringBuilder(length);
    for (java.lang.String s : args) {
      b.append(s);
    }
    return b.toString();
  }
  protected static final TypeFactory _tf = TypeFactory.getInstance();
 
  private static final IntegerMap _resultStoreIdMappings;
  private static final IntegerKeyedHashMap<IntegerList> _dontNest;
	
  protected static void _putDontNest(IntegerKeyedHashMap<IntegerList> result, int parentId, int childId) {
    IntegerList donts = result.get(childId);
    if (donts == null) {
      donts = new IntegerList();
      result.put(childId, donts);
    }
    donts.add(parentId);
  }
    
  protected int getResultStoreId(int parentId) {
    return _resultStoreIdMappings.get(parentId);
  }
    
  protected static IntegerKeyedHashMap<IntegerList> _initDontNest() {
    IntegerKeyedHashMap<IntegerList> result = new IntegerKeyedHashMap<IntegerList>(); 
    
    
    
    
    _putDontNest(result, 209, 209);
    
    _putDontNest(result, 209, 200);
    
    _putDontNest(result, 190, 190);
    
    _putDontNest(result, 200, 200);
    
    _putDontNest(result, 200, 209);
    
    _putDontNest(result, 185, 209);
    
    _putDontNest(result, 190, 200);
    
    _putDontNest(result, 185, 200);
    
    _putDontNest(result, 190, 209);
   return result;
  }
    
  protected static IntegerMap _initDontNestGroups() {
    IntegerMap result = new IntegerMap();
    int resultStoreId = result.size();
    
    
    ++resultStoreId;
    
    result.putUnsafe(190, resultStoreId);
    ++resultStoreId;
    
    result.putUnsafe(200, resultStoreId);
    result.putUnsafe(185, resultStoreId);
    result.putUnsafe(209, resultStoreId);
      
    return result;
  }
  
  protected boolean hasNestingRestrictions(java.lang.String name){
		return (_dontNest.size() != 0); // TODO Make more specific.
  }
    
  protected IntegerList getFilteredParents(int childId) {
		return _dontNest.get(childId);
  }
    
  // initialize priorities     
  static {
    _dontNest = _initDontNest();
    _resultStoreIdMappings = _initDontNestGroups();
  }
    
  // Production declarations
	
  private static final IConstructor cHJvZChsYWJlbCgid3MyIixsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpLFtsaXQoIiUiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSgxLDM2KSxyYW5nZSgzOCwxNjc3NzIxNSldKSksbGl0KCIlIildLHt0YWcoImNhdGVnb3J5IigiQ29tbWVudCIpKX0p = (IConstructor) _read("prod(label(\"ws2\",lex(\"WhitespaceAndComment\")),[lit(\"%\"),iter(\\char-class([range(1,36),range(38,16777215)])),lit(\"%\")],{tag(\"category\"(\"Comment\"))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiY29uYyIsc29ydCgiRXhwcmVzc2lvbiIpKSxbbGFiZWwoImxocyIsc29ydCgiRXhwcmVzc2lvbiIpKSxsYXlvdXRzKCJMYXlvdXQiKSxsaXQoInx8IiksbGF5b3V0cygiTGF5b3V0IiksbGFiZWwoInJocyIsc29ydCgiRXhwcmVzc2lvbiIpKV0se2Fzc29jKGxlZnQoKSl9KQ0000 = (IConstructor) _read("prod(label(\"conc\",sort(\"Expression\")),[label(\"lhs\",sort(\"Expression\")),layouts(\"Layout\"),lit(\"||\"),layouts(\"Layout\"),label(\"rhs\",sort(\"Expression\"))],{assoc(left())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiaWZFbHNlU3RhdCIsc29ydCgiU3RhdGVtZW50IikpLFtsaXQoImlmIiksbGF5b3V0cygiTGF5b3V0IiksbGFiZWwoImNvbmQiLHNvcnQoIkV4cHJlc3Npb24iKSksbGF5b3V0cygiTGF5b3V0IiksbGl0KCJ0aGVuIiksbGF5b3V0cygiTGF5b3V0IiksbGFiZWwoInRoZW5QYXJ0IixcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RhdGVtZW50IiksW2xheW91dHMoIkxheW91dCIpLGxpdCgiOyIpLGxheW91dHMoIkxheW91dCIpXSkpLGxheW91dHMoIkxheW91dCIpLGxpdCgiZWxzZSIpLGxheW91dHMoIkxheW91dCIpLGxhYmVsKCJlbHNlUGFydCIsXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0YXRlbWVudCIpLFtsYXlvdXRzKCJMYXlvdXQiKSxsaXQoIjsiKSxsYXlvdXRzKCJMYXlvdXQiKV0pKSxsYXlvdXRzKCJMYXlvdXQiKSxsaXQoImZpIildLHt9KQ0000 = (IConstructor) _read("prod(label(\"ifElseStat\",sort(\"Statement\")),[lit(\"if\"),layouts(\"Layout\"),label(\"cond\",sort(\"Expression\")),layouts(\"Layout\"),lit(\"then\"),layouts(\"Layout\"),label(\"thenPart\",\\iter-star-seps(sort(\"Statement\"),[layouts(\"Layout\"),lit(\";\"),layouts(\"Layout\")])),layouts(\"Layout\"),lit(\"else\"),layouts(\"Layout\"),label(\"elsePart\",\\iter-star-seps(sort(\"Statement\"),[layouts(\"Layout\"),lit(\";\"),layouts(\"Layout\")])),layouts(\"Layout\"),lit(\"fi\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsZXgoIlN0cmluZyIpLFtsaXQoIlwiIiksXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoMSwzMykscmFuZ2UoMzUsMTY3NzcyMTUpXSkpLGxpdCgiXCIiKV0se30p = (IConstructor) _read("prod(lex(\"String\"),[lit(\"\\\"\"),\\iter-star(\\char-class([range(1,33),range(35,16777215)])),lit(\"\\\"\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJUeXBlXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDg0LDg0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjEsMTIxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"sort(\\\"Type\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(84,84)]),\\char-class([range(121,121)]),\\char-class([range(112,112)]),\\char-class([range(101,101)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiaWQiLHNvcnQoIkV4cHJlc3Npb24iKSksW2xhYmVsKCJuYW1lIixsZXgoIklkIikpXSx7fSk00 = (IConstructor) _read("prod(label(\"id\",sort(\"Expression\")),[label(\"name\",lex(\"Id\"))],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIldoaXRlc3BhY2VBbmRDb21tZW50XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",lex(\"WhitespaceAndComment\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"WhitespaceAndComment\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(lex(\"WhitespaceAndComment\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJEZWNsYXJhdGlvbnNcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjgsNjgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"sort(\\\"Declarations\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(68,68)]),\\char-class([range(101,101)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(115,115)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zdGFyLXNlcHMoc29ydChcIkRlY2xhcmF0aW9uXCIpLFtsaXQoXCIsXCIpXSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJEZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMYXlvdXQiKSxsaXQoIiwiKSxsYXlvdXRzKCJMYXlvdXQiKV0pKSl9KQ0000 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Declaration\")),[\\char-class([range(0,0)]),lit(\"\\\\iter-star-seps(sort(\\\"Declaration\\\"),[lit(\\\",\\\")])\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-star-seps(sort(\"Declaration\"),[layouts(\"Layout\"),lit(\",\"),layouts(\"Layout\")])))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJTdGF0ZW1lbnRcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODMsODMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"sort(\\\"Statement\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(83,83)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(109,109)]),\\char-class([range(101,101)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJOYXR1cmFsXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDc4LDc4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE3LDExNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"sort(\\\"Natural\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(78,78)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(117,117)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(108,108)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgibmF0dXJhbCIsc29ydCgiVHlwZSIpKSxbbGl0KCJuYXR1cmFsIildLHt9KQ0000 = (IConstructor) _read("prod(label(\"natural\",sort(\"Type\")),[lit(\"natural\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJXaGl0ZXNwYWNlQW5kQ29tbWVudFwiKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkyLDkyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDg3LDg3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDQsMTA0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY1LDY1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDAsMTAwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2Nyw2NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA5LDEwOSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA5LDEwOSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"\\\\iter-star(sort(\\\"WhitespaceAndComment\\\"))\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(87,87)]),\\char-class([range(104,104)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(115,115)]),\\char-class([range(112,112)]),\\char-class([range(97,97)]),\\char-class([range(99,99)]),\\char-class([range(101,101)]),\\char-class([range(65,65)]),\\char-class([range(110,110)]),\\char-class([range(100,100)]),\\char-class([range(67,67)]),\\char-class([range(111,111)]),\\char-class([range(109,109)]),\\char-class([range(109,109)]),\\char-class([range(101,101)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJXaGl0ZXNwYWNlQW5kQ29tbWVudFwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4Nyw4NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA0LDEwNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEyLDExMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2NSw2NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAwLDEwMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjcsNjcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"sort(\\\"WhitespaceAndComment\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(87,87)]),\\char-class([range(104,104)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(115,115)]),\\char-class([range(112,112)]),\\char-class([range(97,97)]),\\char-class([range(99,99)]),\\char-class([range(101,101)]),\\char-class([range(65,65)]),\\char-class([range(110,110)]),\\char-class([range(100,100)]),\\char-class([range(67,67)]),\\char-class([range(111,111)]),\\char-class([range(109,109)]),\\char-class([range(109,109)]),\\char-class([range(101,101)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIlN0cmluZyIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJTdHJpbmdcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGxleCgiU3RyaW5nIikpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",lex(\"String\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"String\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(lex(\"String\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInx8IiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMjQsMTI0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjQsMTI0KV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"||\"),[\\char-class([range(124,124)]),\\char-class([range(124,124)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInN0cmluZyIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAzLDEwMyldKV0se30p = (IConstructor) _read("prod(lit(\"string\"),[\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(114,114)]),\\char-class([range(105,105)]),\\char-class([range(110,110)]),\\char-class([range(103,103)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zdGFyKFxcY2hhci1jbGFzcyhbcmFuZ2UoMSw5KSxyYW5nZSgxMSwxNjc3NzIxNSldKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkyLDkyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNCwxMDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTEsOTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDksNDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Nyw1NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAzLDEwMyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ5LDQ5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0OSw0OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ5LDQ5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1NCw1NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTUsNTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDU1LDU1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1NSw1NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTAsNTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ5LDQ5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1Myw1MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDkzLDkzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"\\\\iter-star(\\\\char-class([range(1,9),range(11,16777215)]))\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(40,40)]),\\char-class([range(92,92)]),\\char-class([range(99,99)]),\\char-class([range(104,104)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(115,115)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(91,91)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(49,49)]),\\char-class([range(44,44)]),\\char-class([range(57,57)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(49,49)]),\\char-class([range(49,49)]),\\char-class([range(44,44)]),\\char-class([range(49,49)]),\\char-class([range(54,54)]),\\char-class([range(55,55)]),\\char-class([range(55,55)]),\\char-class([range(55,55)]),\\char-class([range(50,50)]),\\char-class([range(49,49)]),\\char-class([range(53,53)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzdGFydChzb3J0KCJQcm9ncmFtIikpLFtsYXlvdXRzKCJMYXlvdXQiKSxsYWJlbCgidG9wIixzb3J0KCJQcm9ncmFtIikpLGxheW91dHMoIkxheW91dCIpXSx7fSk00 = (IConstructor) _read("prod(start(sort(\"Program\")),[layouts(\"Layout\"),label(\"top\",sort(\"Program\")),layouts(\"Layout\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixcY2hhci1jbGFzcyhbcmFuZ2UoMSwzMykscmFuZ2UoMzUsMTY3NzcyMTUpXSkpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiXFxpdGVyLXN0YXIoXFxjaGFyLWNsYXNzKFtyYW5nZSgxLDMzKSxyYW5nZSgzNSwxNjc3NzIxNSldKSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXN0YXIoXGNoYXItY2xhc3MoW3JhbmdlKDEsMzMpLHJhbmdlKDM1LDE2Nzc3MjE1KV0pKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",\\char-class([range(1,33),range(35,16777215)])),[\\char-class([range(0,0)]),lit(\"\\\\iter-star(\\\\char-class([range(1,33),range(35,16777215)]))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-star(\\char-class([range(1,33),range(35,16777215)]))))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiaXRlcihcXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpKSl9KQ0000 = (IConstructor) _read("prod(label(\"$MetaHole\",\\char-class([range(48,57)])),[\\char-class([range(0,0)]),lit(\"iter(\\\\char-class([range(48,57)]))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(iter(\\char-class([range(48,57)]))))})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiRGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTGF5b3V0IiksbGl0KCIsIiksbGF5b3V0cygiTGF5b3V0IildKSk00 = (IConstructor) _read("regular(\\iter-star-seps(sort(\"Declaration\"),[layouts(\"Layout\"),lit(\",\"),layouts(\"Layout\")]))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsZXgoIk5hdHVyYWwiKSxbaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpXSx7fSk00 = (IConstructor) _read("prod(lex(\"Natural\"),[iter(\\char-class([range(48,57)]))],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIiUlIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgzNywzNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzcsMzcpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"%%\"),[\\char-class([range(37,37)]),\\char-class([range(37,37)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFeHByZXNzaW9uIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkV4cHJlc3Npb25cIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIkV4cHJlc3Npb24iKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Expression\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"Expression\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"Expression\")))})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp = (IConstructor) _read("regular(iter(\\char-class([range(48,57)])))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zdGFyKFxcY2hhci1jbGFzcyhbcmFuZ2UoMSwzMykscmFuZ2UoMzUsMTY3NzcyMTUpXSkpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTIsOTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDQsMTA0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDkxLDkxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAzLDEwMyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ5LDQ5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTEsNTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDUxLDUxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTEsNTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDUzLDUzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDksNDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDU0LDU0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1NSw1NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTUsNTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDU1LDU1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1MCw1MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDksNDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDUzLDUzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTMsOTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"\\\\iter-star(\\\\char-class([range(1,33),range(35,16777215)]))\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(40,40)]),\\char-class([range(92,92)]),\\char-class([range(99,99)]),\\char-class([range(104,104)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(115,115)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(91,91)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(49,49)]),\\char-class([range(44,44)]),\\char-class([range(51,51)]),\\char-class([range(51,51)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(51,51)]),\\char-class([range(53,53)]),\\char-class([range(44,44)]),\\char-class([range(49,49)]),\\char-class([range(54,54)]),\\char-class([range(55,55)]),\\char-class([range(55,55)]),\\char-class([range(55,55)]),\\char-class([range(50,50)]),\\char-class([range(49,49)]),\\char-class([range(53,53)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiZGVjbCIsc29ydCgiRGVjbGFyYXRpb24iKSksW2xhYmVsKCJpZCIsbGV4KCJJZCIpKSxsYXlvdXRzKCJMYXlvdXQiKSxsaXQoIjoiKSxsYXlvdXRzKCJMYXlvdXQiKSxsYWJlbCgidHAiLHNvcnQoIlR5cGUiKSldLHt9KQ0000 = (IConstructor) _read("prod(label(\"decl\",sort(\"Declaration\")),[label(\"id\",lex(\"Id\")),layouts(\"Layout\"),lit(\":\"),layouts(\"Layout\"),label(\"tp\",sort(\"Type\"))],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJEZWNsYXJhdGlvblwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiRGVjbGFyYXRpb24iKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Declaration\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"Declaration\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"Declaration\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdGlvbnMiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiRGVjbGFyYXRpb25zXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJEZWNsYXJhdGlvbnMiKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Declarations\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"Declarations\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"Declarations\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIjsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU5LDU5KV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\";\"),[\\char-class([range(59,59)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIndoaWxlIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTksMTE5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDQsMTA0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"while\"),[\\char-class([range(119,119)]),\\char-class([range(104,104)]),\\char-class([range(105,105)]),\\char-class([range(108,108)]),\\char-class([range(101,101)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImZpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMDIsMTAyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"fi\"),[\\char-class([range(102,102)]),\\char-class([range(105,105)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImVuZCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAwLDEwMCldKV0se30p = (IConstructor) _read("prod(lit(\"end\"),[\\char-class([range(101,101)]),\\char-class([range(110,110)]),\\char-class([range(100,100)])],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NykscmFuZ2UoOTcsMTIyKV0pKSk00 = (IConstructor) _read("regular(\\iter-star(\\char-class([range(48,57),range(97,122)])))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zdGFyLXNlcHMoc29ydChcIlN0YXRlbWVudFwiKSxbbGl0KFwiO1wiKV0pIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEyLDExMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODMsODMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5MSw5MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1OSw1OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Myw5MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"\\\\iter-star-seps(sort(\\\"Statement\\\"),[lit(\\\";\\\")])\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(101,101)]),\\char-class([range(112,112)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(83,83)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(109,109)]),\\char-class([range(101,101)]),\\char-class([range(110,110)]),\\char-class([range(116,116)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(91,91)]),\\char-class([range(108,108)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(59,59)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJJZFwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg3Myw3MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAwLDEwMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"sort(\\\"Id\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(73,73)]),\\char-class([range(100,100)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiYXNnU3RhdCIsc29ydCgiU3RhdGVtZW50IikpLFtsYWJlbCgidmFyIixsZXgoIklkIikpLGxheW91dHMoIkxheW91dCIpLGxpdCgiOj0iKSxsYXlvdXRzKCJMYXlvdXQiKSxsYWJlbCgidmFsIixzb3J0KCJFeHByZXNzaW9uIikpXSx7fSk00 = (IConstructor) _read("prod(label(\"asgStat\",sort(\"Statement\")),[label(\"var\",lex(\"Id\")),layouts(\"Layout\"),lit(\":=\"),layouts(\"Layout\"),label(\"val\",sort(\"Expression\"))],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImJlZ2luIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5OCw5OCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAzLDEwMyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKV0se30p = (IConstructor) _read("prod(lit(\"begin\"),[\\char-class([range(98,98)]),\\char-class([range(101,101)]),\\char-class([range(103,103)]),\\char-class([range(105,105)]),\\char-class([range(110,110)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIm5hdHVyYWwiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKV0se30p = (IConstructor) _read("prod(lit(\"natural\"),[\\char-class([range(110,110)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(117,117)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(108,108)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYXlvdXRzKCIkZGVmYXVsdCQiKSxbXSx7fSk00 = (IConstructor) _read("prod(layouts(\"$default$\"),[],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgid2hpbGVTdGF0Iixzb3J0KCJTdGF0ZW1lbnQiKSksW2xpdCgid2hpbGUiKSxsYXlvdXRzKCJMYXlvdXQiKSxsYWJlbCgiY29uZCIsc29ydCgiRXhwcmVzc2lvbiIpKSxsYXlvdXRzKCJMYXlvdXQiKSxsaXQoImRvIiksbGF5b3V0cygiTGF5b3V0IiksbGFiZWwoImJvZHkiLFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJTdGF0ZW1lbnQiKSxbbGF5b3V0cygiTGF5b3V0IiksbGl0KCI7IiksbGF5b3V0cygiTGF5b3V0IildKSksbGF5b3V0cygiTGF5b3V0IiksbGl0KCJvZCIpXSx7fSk00 = (IConstructor) _read("prod(label(\"whileStat\",sort(\"Statement\")),[lit(\"while\"),layouts(\"Layout\"),label(\"cond\",sort(\"Expression\")),layouts(\"Layout\"),lit(\"do\"),layouts(\"Layout\"),label(\"body\",\\iter-star-seps(sort(\"Statement\"),[layouts(\"Layout\"),lit(\";\"),layouts(\"Layout\")])),layouts(\"Layout\"),lit(\"od\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIk5hdHVyYWwiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiTmF0dXJhbFwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIobGV4KCJOYXR1cmFsIikpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",lex(\"Natural\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"Natural\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(lex(\"Natural\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImVsc2UiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"else\"),[\\char-class([range(101,101)]),\\char-class([range(108,108)]),\\char-class([range(115,115)]),\\char-class([range(101,101)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixcY2hhci1jbGFzcyhbcmFuZ2UoMSwzNikscmFuZ2UoMzgsMTY3NzcyMTUpXSkpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiaXRlcihcXGNoYXItY2xhc3MoW3JhbmdlKDEsMzYpLHJhbmdlKDM4LDE2Nzc3MjE1KV0pKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoMSwzNikscmFuZ2UoMzgsMTY3NzcyMTUpXSkpKSl9KQ0000 = (IConstructor) _read("prod(label(\"$MetaHole\",\\char-class([range(1,36),range(38,16777215)])),[\\char-class([range(0,0)]),lit(\"iter(\\\\char-class([range(1,36),range(38,16777215)]))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(iter(\\char-class([range(1,36),range(38,16777215)]))))})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSgxLDkpLHJhbmdlKDExLDE2Nzc3MjE1KV0pKSk00 = (IConstructor) _read("regular(\\iter-star(\\char-class([range(1,9),range(11,16777215)])))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlwiIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKV0se30p = (IConstructor) _read("prod(lit(\"\\\"\"),[\\char-class([range(34,34)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\":\"),[\\char-class([range(58,58)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIml0ZXIoXFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNCwxMDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTEsOTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTIsNTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDU2LDU2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTMsNTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDU1LDU1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTMsOTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"iter(\\\\char-class([range(48,57)]))\"),[\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(40,40)]),\\char-class([range(92,92)]),\\char-class([range(99,99)]),\\char-class([range(104,104)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(115,115)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(91,91)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(52,52)]),\\char-class([range(56,56)]),\\char-class([range(44,44)]),\\char-class([range(53,53)]),\\char-class([range(55,55)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgid3MzIixsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpLFtsaXQoIiUlIiksY29uZGl0aW9uYWwoXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoMSw5KSxyYW5nZSgxMSwxNjc3NzIxNSldKSkse1xlbmQtb2YtbGluZSgpfSldLHt0YWcoImNhdGVnb3J5IigiQ29tbWVudCIpKX0p = (IConstructor) _read("prod(label(\"ws3\",lex(\"WhitespaceAndComment\")),[lit(\"%%\"),conditional(\\iter-star(\\char-class([range(1,9),range(11,16777215)])),{\\end-of-line()})],{tag(\"category\"(\"Comment\"))})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSgxLDMzKSxyYW5nZSgzNSwxNjc3NzIxNSldKSkp = (IConstructor) _read("regular(\\iter-star(\\char-class([range(1,33),range(35,16777215)])))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zdGFyKFxcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpLHJhbmdlKDk3LDEyMildKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkyLDkyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNCwxMDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTEsOTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTIsNTIpXSksXGNoYXItY2xhc3MoW3JhbmdlKDU2LDU2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTMsNTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDU1LDU1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTcsNTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDU1LDU1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDksNDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDUwLDUwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1MCw1MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDkzLDkzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"\\\\iter-star(\\\\char-class([range(48,57),range(97,122)]))\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(40,40)]),\\char-class([range(92,92)]),\\char-class([range(99,99)]),\\char-class([range(104,104)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(115,115)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(91,91)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(52,52)]),\\char-class([range(56,56)]),\\char-class([range(44,44)]),\\char-class([range(53,53)]),\\char-class([range(55,55)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(57,57)]),\\char-class([range(55,55)]),\\char-class([range(44,44)]),\\char-class([range(49,49)]),\\char-class([range(50,50)]),\\char-class([range(50,50)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RhdGVtZW50IiksW2xheW91dHMoIkxheW91dCIpLGxpdCgiOyIpLGxheW91dHMoIkxheW91dCIpXSkp = (IConstructor) _read("regular(\\iter-star-seps(sort(\"Statement\"),[layouts(\"Layout\"),lit(\";\"),layouts(\"Layout\")]))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJQcm9ncmFtXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDgwLDgwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA5LDEwOSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"sort(\\\"Program\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(80,80)]),\\char-class([range(114,114)]),\\char-class([range(111,111)]),\\char-class([range(103,103)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(109,109)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInRoZW4iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNCwxMDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"then\"),[\\char-class([range(116,116)]),\\char-class([range(104,104)]),\\char-class([range(101,101)]),\\char-class([range(110,110)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIjo9IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg1OCw1OCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjEsNjEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\":=\"),[\\char-class([range(58,58)]),\\char-class([range(61,61)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5LDEwKSxyYW5nZSgxMywxMykscmFuZ2UoMzIsMzIpXSldLHt9KQ0000 = (IConstructor) _read("prod(lex(\"WhitespaceAndComment\"),[\\char-class([range(9,10),range(13,13),range(32,32)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChlbXB0eSgpLFtdLHt9KQ0000 = (IConstructor) _read("prod(empty(),[],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIi0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ1LDQ1KV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"-\"),[\\char-class([range(45,45)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdGF0ZW1lbnQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiU3RhdGVtZW50XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJTdGF0ZW1lbnQiKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Statement\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"Statement\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"Statement\")))})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSgxLDM2KSxyYW5nZSgzOCwxNjc3NzIxNSldKSkp = (IConstructor) _read("regular(iter(\\char-class([range(1,36),range(38,16777215)])))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdGF0ZW1lbnQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc3Rhci1zZXBzKHNvcnQoXCJTdGF0ZW1lbnRcIiksW2xpdChcIjtcIildKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0YXRlbWVudCIpLFtsYXlvdXRzKCJMYXlvdXQiKSxsaXQoIjsiKSxsYXlvdXRzKCJMYXlvdXQiKV0pKSl9KQ0000 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Statement\")),[\\char-class([range(0,0)]),lit(\"\\\\iter-star-seps(sort(\\\"Statement\\\"),[lit(\\\";\\\")])\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-star-seps(sort(\"Statement\"),[layouts(\"Layout\"),lit(\";\"),layouts(\"Layout\")])))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIiUiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDM3LDM3KV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"%\"),[\\char-class([range(37,37)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgic3RyQ29uIixzb3J0KCJFeHByZXNzaW9uIikpLFtsYWJlbCgic3RyaW5nIixsZXgoIlN0cmluZyIpKV0se30p = (IConstructor) _read("prod(label(\"strCon\",sort(\"Expression\")),[label(\"string\",lex(\"String\"))],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpLHJhbmdlKDk3LDEyMildKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc3RhcihcXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KSxyYW5nZSg5NywxMjIpXSkpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NykscmFuZ2UoOTcsMTIyKV0pKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",\\char-class([range(48,57),range(97,122)])),[\\char-class([range(0,0)]),lit(\"\\\\iter-star(\\\\char-class([range(48,57),range(97,122)]))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-star(\\char-class([range(48,57),range(97,122)]))))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiYWRkIixzb3J0KCJFeHByZXNzaW9uIikpLFtsYWJlbCgibGhzIixzb3J0KCJFeHByZXNzaW9uIikpLGxheW91dHMoIkxheW91dCIpLGxpdCgiKyIpLGxheW91dHMoIkxheW91dCIpLGxhYmVsKCJyaHMiLHNvcnQoIkV4cHJlc3Npb24iKSldLHthc3NvYyhsZWZ0KCkpfSk00 = (IConstructor) _read("prod(label(\"add\",sort(\"Expression\")),[label(\"lhs\",sort(\"Expression\")),layouts(\"Layout\"),lit(\"+\"),layouts(\"Layout\"),label(\"rhs\",sort(\"Expression\"))],{assoc(left())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImlmIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDIsMTAyKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"if\"),[\\char-class([range(105,105)]),\\char-class([range(102,102)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIm9kIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDAsMTAwKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"od\"),[\\char-class([range(111,111)]),\\char-class([range(100,100)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJUeXBlIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlR5cGVcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlR5cGUiKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Type\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"Type\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"Type\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsZXgoIklkIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5NywxMjIpXSksY29uZGl0aW9uYWwoXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpLHJhbmdlKDk3LDEyMildKSkse1xub3QtZm9sbG93KFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NykscmFuZ2UoOTcsMTIyKV0pKX0pXSx7fSk00 = (IConstructor) _read("prod(lex(\"Id\"),[\\char-class([range(97,122)]),conditional(\\iter-star(\\char-class([range(48,57),range(97,122)])),{\\not-follow(\\char-class([range(48,57),range(97,122)]))})],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJEZWNsYXJhdGlvbnMiKSxbbGl0KCJkZWNsYXJlIiksbGF5b3V0cygiTGF5b3V0IiksbGFiZWwoImRlY2xzIixcaXRlci1zdGFyLXNlcHMoc29ydCgiRGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTGF5b3V0IiksbGl0KCIsIiksbGF5b3V0cygiTGF5b3V0IildKSksbGF5b3V0cygiTGF5b3V0IiksbGl0KCI7IildLHt9KQ0000 = (IConstructor) _read("prod(sort(\"Declarations\"),[lit(\"declare\"),layouts(\"Layout\"),label(\"decls\",\\iter-star-seps(sort(\"Declaration\"),[layouts(\"Layout\"),lit(\",\"),layouts(\"Layout\")])),layouts(\"Layout\"),lit(\";\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\")\"),[\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgic3ViIixzb3J0KCJFeHByZXNzaW9uIikpLFtsYWJlbCgibGhzIixzb3J0KCJFeHByZXNzaW9uIikpLGxheW91dHMoIkxheW91dCIpLGxpdCgiLSIpLGxheW91dHMoIkxheW91dCIpLGxhYmVsKCJyaHMiLHNvcnQoIkV4cHJlc3Npb24iKSldLHthc3NvYyhsZWZ0KCkpfSk00 = (IConstructor) _read("prod(label(\"sub\",sort(\"Expression\")),[label(\"lhs\",sort(\"Expression\")),layouts(\"Layout\"),lit(\"-\"),layouts(\"Layout\"),label(\"rhs\",sort(\"Expression\"))],{assoc(left())})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYXlvdXRzKCJMYXlvdXQiKSxbY29uZGl0aW9uYWwoXGl0ZXItc3RhcihsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpLHtcbm90LWZvbGxvdyhcY2hhci1jbGFzcyhbcmFuZ2UoOSwxMCkscmFuZ2UoMTMsMTMpLHJhbmdlKDMyLDMyKSxyYW5nZSgzNywzNyldKSl9KV0se30p = (IConstructor) _read("prod(layouts(\"Layout\"),[conditional(\\iter-star(lex(\"WhitespaceAndComment\")),{\\not-follow(\\char-class([range(9,10),range(13,13),range(32,32),range(37,37)]))})],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJEZWNsYXJhdGlvblwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2OCw2OCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"sort(\\\"Declaration\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(68,68)]),\\char-class([range(101,101)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIigiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"(\"),[\\char-class([range(40,40)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJTdHJpbmdcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODMsODMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p = (IConstructor) _read("prod(lit(\"sort(\\\"String\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(83,83)]),\\char-class([range(116,116)]),\\char-class([range(114,114)]),\\char-class([range(105,105)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQcm9ncmFtIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlByb2dyYW1cIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlByb2dyYW0iKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",sort(\"Program\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"Program\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(sort(\"Program\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIml0ZXIoXFxjaGFyLWNsYXNzKFtyYW5nZSgxLDM2KSxyYW5nZSgzOCwxNjc3NzIxNSldKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNCwxMDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTEsOTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDksNDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1MSw1MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTQsNTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1MSw1MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTYsNTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0OSw0OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTQsNTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDU1LDU1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1NSw1NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTUsNTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDUwLDUwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0OSw0OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNTMsNTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Myw5MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"iter(\\\\char-class([range(1,36),range(38,16777215)]))\"),[\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(40,40)]),\\char-class([range(92,92)]),\\char-class([range(99,99)]),\\char-class([range(104,104)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(115,115)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(91,91)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(49,49)]),\\char-class([range(44,44)]),\\char-class([range(51,51)]),\\char-class([range(54,54)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(110,110)]),\\char-class([range(103,103)]),\\char-class([range(101,101)]),\\char-class([range(40,40)]),\\char-class([range(51,51)]),\\char-class([range(56,56)]),\\char-class([range(44,44)]),\\char-class([range(49,49)]),\\char-class([range(54,54)]),\\char-class([range(55,55)]),\\char-class([range(55,55)]),\\char-class([range(55,55)]),\\char-class([range(50,50)]),\\char-class([range(49,49)]),\\char-class([range(53,53)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgic3RyaW5nIixzb3J0KCJUeXBlIikpLFtsaXQoInN0cmluZyIpXSx7fSk00 = (IConstructor) _read("prod(label(\"string\",sort(\"Type\")),[lit(\"string\")],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImRvIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMDAsMTAwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"do\"),[\\char-class([range(100,100)]),\\char-class([range(111,111)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoImRlY2xhcmUiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwMCwxMDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKV0se30p = (IConstructor) _read("prod(lit(\"declare\"),[\\char-class([range(100,100)]),\\char-class([range(101,101)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(101,101)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixcY2hhci1jbGFzcyhbcmFuZ2UoMSw5KSxyYW5nZSgxMSwxNjc3NzIxNSldKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc3RhcihcXGNoYXItY2xhc3MoW3JhbmdlKDEsOSkscmFuZ2UoMTEsMTY3NzcyMTUpXSkpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSgxLDkpLHJhbmdlKDExLDE2Nzc3MjE1KV0pKSkpfSk00 = (IConstructor) _read("prod(label(\"$MetaHole\",\\char-class([range(1,9),range(11,16777215)])),[\\char-class([range(0,0)]),lit(\"\\\\iter-star(\\\\char-class([range(1,9),range(11,16777215)]))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-star(\\char-class([range(1,9),range(11,16777215)]))))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIlxcaXRlci1zdGFyLXNlcHMoc29ydChcIkRlY2xhcmF0aW9uXCIpLFtsaXQoXCIsXCIpXSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkyLDkyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ1LDQ1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2OCw2OCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTEsOTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTMsOTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"\\\\iter-star-seps(sort(\\\"Declaration\\\"),[lit(\\\",\\\")])\"),[\\char-class([range(92,92)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(101,101)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(116,116)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(45,45)]),\\char-class([range(115,115)]),\\char-class([range(101,101)]),\\char-class([range(112,112)]),\\char-class([range(115,115)]),\\char-class([range(40,40)]),\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(68,68)]),\\char-class([range(101,101)]),\\char-class([range(99,99)]),\\char-class([range(108,108)]),\\char-class([range(97,97)]),\\char-class([range(114,114)]),\\char-class([range(97,97)]),\\char-class([range(116,116)]),\\char-class([range(105,105)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(44,44)]),\\char-class([range(91,91)]),\\char-class([range(108,108)]),\\char-class([range(105,105)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(44,44)]),\\char-class([range(34,34)]),\\char-class([range(41,41)]),\\char-class([range(93,93)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgibmF0Q29uIixzb3J0KCJFeHByZXNzaW9uIikpLFtsYWJlbCgibmF0Y29uIixsZXgoIk5hdHVyYWwiKSldLHt9KQ0000 = (IConstructor) _read("prod(label(\"natCon\",sort(\"Expression\")),[label(\"natcon\",lex(\"Natural\"))],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoInNvcnQoXCJFeHByZXNzaW9uXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY5LDY5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjAsMTIwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000 = (IConstructor) _read("prod(lit(\"sort(\\\"Expression\\\")\"),[\\char-class([range(115,115)]),\\char-class([range(111,111)]),\\char-class([range(114,114)]),\\char-class([range(116,116)]),\\char-class([range(40,40)]),\\char-class([range(34,34)]),\\char-class([range(69,69)]),\\char-class([range(120,120)]),\\char-class([range(112,112)]),\\char-class([range(114,114)]),\\char-class([range(101,101)]),\\char-class([range(115,115)]),\\char-class([range(115,115)]),\\char-class([range(105,105)]),\\char-class([range(111,111)]),\\char-class([range(110,110)]),\\char-class([range(34,34)]),\\char-class([range(41,41)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIiwiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\",\"),[\\char-class([range(44,44)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgicHJvZ3JhbSIsc29ydCgiUHJvZ3JhbSIpKSxbbGl0KCJiZWdpbiIpLGxheW91dHMoIkxheW91dCIpLGxhYmVsKCJkZWNscyIsc29ydCgiRGVjbGFyYXRpb25zIikpLGxheW91dHMoIkxheW91dCIpLGxhYmVsKCJib2R5IixcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RhdGVtZW50IiksW2xheW91dHMoIkxheW91dCIpLGxpdCgiOyIpLGxheW91dHMoIkxheW91dCIpXSkpLGxheW91dHMoIkxheW91dCIpLGxpdCgiZW5kIildLHt9KQ0000 = (IConstructor) _read("prod(label(\"program\",sort(\"Program\")),[lit(\"begin\"),layouts(\"Layout\"),label(\"decls\",sort(\"Declarations\")),layouts(\"Layout\"),label(\"body\",\\iter-star-seps(sort(\"Statement\"),[layouts(\"Layout\"),lit(\";\"),layouts(\"Layout\")])),layouts(\"Layout\"),lit(\"end\")],{})", RascalValueFactory.Production);
  private static final IConstructor cmVndWxhcihcaXRlci1zdGFyKGxleCgiV2hpdGVzcGFjZUFuZENvbW1lbnQiKSkp = (IConstructor) _read("regular(\\iter-star(lex(\"WhitespaceAndComment\")))", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsaXQoIisiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQzLDQzKV0pXSx7fSk00 = (IConstructor) _read("prod(lit(\"+\"),[\\char-class([range(43,43)])],{})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiKCIpLGxheW91dHMoIkxheW91dCIpLGxhYmVsKCJlIixzb3J0KCJFeHByZXNzaW9uIikpLGxheW91dHMoIkxheW91dCIpLGxpdCgiKSIpXSx7YnJhY2tldCgpfSk00 = (IConstructor) _read("prod(sort(\"Expression\"),[lit(\"(\"),layouts(\"Layout\"),label(\"e\",sort(\"Expression\")),layouts(\"Layout\"),lit(\")\")],{bracket()})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIklkIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIklkXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihsZXgoIklkIikpKX0p = (IConstructor) _read("prod(label(\"$MetaHole\",lex(\"Id\")),[\\char-class([range(0,0)]),lit(\"sort(\\\"Id\\\")\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(lex(\"Id\")))})", RascalValueFactory.Production);
  private static final IConstructor cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiXFxpdGVyLXN0YXIoc29ydChcIldoaXRlc3BhY2VBbmRDb21tZW50XCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc3RhcihsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpKSl9KQ0000 = (IConstructor) _read("prod(label(\"$MetaHole\",lex(\"WhitespaceAndComment\")),[\\char-class([range(0,0)]),lit(\"\\\\iter-star(sort(\\\"WhitespaceAndComment\\\"))\"),lit(\":\"),iter(\\char-class([range(48,57)])),\\char-class([range(0,0)])],{tag(\"holeType\"(\\iter-star(lex(\"WhitespaceAndComment\"))))})", RascalValueFactory.Production);
    
  // Item declarations
	
	
  protected static class start__Program {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChzdGFydChzb3J0KCJQcm9ncmFtIikpLFtsYXlvdXRzKCJMYXlvdXQiKSxsYWJlbCgidG9wIixzb3J0KCJQcm9ncmFtIikpLGxheW91dHMoIkxheW91dCIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[1] = new NonTerminalStackNode<IConstructor>(55, 1, "Program", null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(57, 2, "layouts_Layout", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(54, 0, "layouts_Layout", null, null);
      builder.addAlternative(PicoParser.cHJvZChzdGFydChzb3J0KCJQcm9ncmFtIikpLFtsYXlvdXRzKCJMYXlvdXQiKSxsYWJlbCgidG9wIixzb3J0KCJQcm9ncmFtIikpLGxheW91dHMoIkxheW91dCIpXSx7fSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChzdGFydChzb3J0KCJQcm9ncmFtIikpLFtsYXlvdXRzKCJMYXlvdXQiKSxsYWJlbCgidG9wIixzb3J0KCJQcm9ncmFtIikpLGxheW91dHMoIkxheW91dCIpXSx7fSk00(builder);
      
    }
  }
	
  protected static class Declarations {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdGlvbnMiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiRGVjbGFyYXRpb25zXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJEZWNsYXJhdGlvbnMiKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new ListStackNode<IConstructor>(117, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(116, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(114, 1, cHJvZChsaXQoInNvcnQoXCJEZWNsYXJhdGlvbnNcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjgsNjgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {115,111,114,116,40,34,68,101,99,108,97,114,97,116,105,111,110,115,34,41}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(113, 0, new int[][]{{0,0}}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(118, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(115, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdGlvbnMiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiRGVjbGFyYXRpb25zXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJEZWNsYXJhdGlvbnMiKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJEZWNsYXJhdGlvbnMiKSxbbGl0KCJkZWNsYXJlIiksbGF5b3V0cygiTGF5b3V0IiksbGFiZWwoImRlY2xzIixcaXRlci1zdGFyLXNlcHMoc29ydCgiRGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTGF5b3V0IiksbGl0KCIsIiksbGF5b3V0cygiTGF5b3V0IildKSksbGF5b3V0cygiTGF5b3V0IiksbGl0KCI7IildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new LiteralStackNode<IConstructor>(130, 4, cHJvZChsaXQoIjsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU5LDU5KV0pXSx7fSk00, new int[] {59}, null, null);
      tmp[2] = new SeparatedListStackNode<IConstructor>(127, 2, cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiRGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTGF5b3V0IiksbGl0KCIsIiksbGF5b3V0cygiTGF5b3V0IildKSk00, new NonTerminalStackNode<IConstructor>(123, 0, "Declaration", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(124, 1, "layouts_Layout", null, null), new LiteralStackNode<IConstructor>(125, 2, cHJvZChsaXQoIiwiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pXSx7fSk00, new int[] {44}, null, null), new NonTerminalStackNode<IConstructor>(126, 3, "layouts_Layout", null, null)}, false, null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(121, 0, cHJvZChsaXQoImRlY2xhcmUiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwMCwxMDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKV0se30p, new int[] {100,101,99,108,97,114,101}, null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(129, 3, "layouts_Layout", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(122, 1, "layouts_Layout", null, null);
      builder.addAlternative(PicoParser.cHJvZChzb3J0KCJEZWNsYXJhdGlvbnMiKSxbbGl0KCJkZWNsYXJlIiksbGF5b3V0cygiTGF5b3V0IiksbGFiZWwoImRlY2xzIixcaXRlci1zdGFyLXNlcHMoc29ydCgiRGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTGF5b3V0IiksbGl0KCIsIiksbGF5b3V0cygiTGF5b3V0IildKSksbGF5b3V0cygiTGF5b3V0IiksbGl0KCI7IildLHt9KQ0000, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdGlvbnMiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiRGVjbGFyYXRpb25zXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJEZWNsYXJhdGlvbnMiKSkpfSk00(builder);
      
        _init_cHJvZChzb3J0KCJEZWNsYXJhdGlvbnMiKSxbbGl0KCJkZWNsYXJlIiksbGF5b3V0cygiTGF5b3V0IiksbGFiZWwoImRlY2xzIixcaXRlci1zdGFyLXNlcHMoc29ydCgiRGVjbGFyYXRpb24iKSxbbGF5b3V0cygiTGF5b3V0IiksbGl0KCIsIiksbGF5b3V0cygiTGF5b3V0IildKSksbGF5b3V0cygiTGF5b3V0IiksbGl0KCI7IildLHt9KQ0000(builder);
      
    }
  }
	
  protected static class String {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIlN0cmluZyIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJTdHJpbmdcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGxleCgiU3RyaW5nIikpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new ListStackNode<IConstructor>(139, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(138, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(136, 1, cHJvZChsaXQoInNvcnQoXCJTdHJpbmdcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODMsODMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMywxMDMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {115,111,114,116,40,34,83,116,114,105,110,103,34,41}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(140, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(137, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(135, 0, new int[][]{{0,0}}, null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIlN0cmluZyIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJTdHJpbmdcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGxleCgiU3RyaW5nIikpKX0p, tmp);
	}
    protected static final void _init_cHJvZChsZXgoIlN0cmluZyIpLFtsaXQoIlwiIiksXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoMSwzMykscmFuZ2UoMzUsMTY3NzcyMTUpXSkpLGxpdCgiXCIiKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[1] = new ListStackNode<IConstructor>(145, 1, cmVndWxhcihcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSgxLDMzKSxyYW5nZSgzNSwxNjc3NzIxNSldKSkp, new CharStackNode<IConstructor>(144, 0, new int[][]{{1,33},{35,16777215}}, null, null), false, null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(143, 0, cHJvZChsaXQoIlwiIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKV0se30p, new int[] {34}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(146, 2, cHJvZChsaXQoIlwiIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKV0se30p, new int[] {34}, null, null);
      builder.addAlternative(PicoParser.cHJvZChsZXgoIlN0cmluZyIpLFtsaXQoIlwiIiksXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoMSwzMykscmFuZ2UoMzUsMTY3NzcyMTUpXSkpLGxpdCgiXCIiKV0se30p, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIlN0cmluZyIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJTdHJpbmdcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKGxleCgiU3RyaW5nIikpKX0p(builder);
      
        _init_cHJvZChsZXgoIlN0cmluZyIpLFtsaXQoIlwiIiksXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoMSwzMykscmFuZ2UoMzUsMTY3NzcyMTUpXSkpLGxpdCgiXCIiKV0se30p(builder);
      
    }
  }
	
  protected static class Expression {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiY29uYyIsc29ydCgiRXhwcmVzc2lvbiIpKSxbbGFiZWwoImxocyIsc29ydCgiRXhwcmVzc2lvbiIpKSxsYXlvdXRzKCJMYXlvdXQiKSxsaXQoInx8IiksbGF5b3V0cygiTGF5b3V0IiksbGFiZWwoInJocyIsc29ydCgiRXhwcmVzc2lvbiIpKV0se2Fzc29jKGxlZnQoKSl9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new NonTerminalStackNode<IConstructor>(190, 4, "Expression", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(185, 0, "Expression", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(187, 1, "layouts_Layout", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(189, 3, "layouts_Layout", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(188, 2, cHJvZChsaXQoInx8IiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMjQsMTI0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjQsMTI0KV0pXSx7fSk00, new int[] {124,124}, null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgiY29uYyIsc29ydCgiRXhwcmVzc2lvbiIpKSxbbGFiZWwoImxocyIsc29ydCgiRXhwcmVzc2lvbiIpKSxsYXlvdXRzKCJMYXlvdXQiKSxsaXQoInx8IiksbGF5b3V0cygiTGF5b3V0IiksbGFiZWwoInJocyIsc29ydCgiRXhwcmVzc2lvbiIpKV0se2Fzc29jKGxlZnQoKSl9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFeHByZXNzaW9uIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkV4cHJlc3Npb25cIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIkV4cHJlc3Npb24iKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new ListStackNode<IConstructor>(159, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(158, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(157, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(160, 4, new int[][]{{0,0}}, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(156, 1, cHJvZChsaXQoInNvcnQoXCJFeHByZXNzaW9uXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY5LDY5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjAsMTIwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000, new int[] {115,111,114,116,40,34,69,120,112,114,101,115,115,105,111,110,34,41}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(155, 0, new int[][]{{0,0}}, null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFeHByZXNzaW9uIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkV4cHJlc3Npb25cIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIkV4cHJlc3Npb24iKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgic3RyQ29uIixzb3J0KCJFeHByZXNzaW9uIikpLFtsYWJlbCgic3RyaW5nIixsZXgoIlN0cmluZyIpKV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(166, 0, "String", null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgic3RyQ29uIixzb3J0KCJFeHByZXNzaW9uIikpLFtsYWJlbCgic3RyaW5nIixsZXgoIlN0cmluZyIpKV0se30p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiYWRkIixzb3J0KCJFeHByZXNzaW9uIikpLFtsYWJlbCgibGhzIixzb3J0KCJFeHByZXNzaW9uIikpLGxheW91dHMoIkxheW91dCIpLGxpdCgiKyIpLGxheW91dHMoIkxheW91dCIpLGxhYmVsKCJyaHMiLHNvcnQoIkV4cHJlc3Npb24iKSldLHthc3NvYyhsZWZ0KCkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new NonTerminalStackNode<IConstructor>(199, 3, "layouts_Layout", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(197, 1, "layouts_Layout", null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(200, 4, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(198, 2, cHJvZChsaXQoIisiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQzLDQzKV0pXSx7fSk00, new int[] {43}, null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(195, 0, "Expression", null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgiYWRkIixzb3J0KCJFeHByZXNzaW9uIikpLFtsYWJlbCgibGhzIixzb3J0KCJFeHByZXNzaW9uIikpLGxheW91dHMoIkxheW91dCIpLGxpdCgiKyIpLGxheW91dHMoIkxheW91dCIpLGxhYmVsKCJyaHMiLHNvcnQoIkV4cHJlc3Npb24iKSldLHthc3NvYyhsZWZ0KCkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgic3ViIixzb3J0KCJFeHByZXNzaW9uIikpLFtsYWJlbCgibGhzIixzb3J0KCJFeHByZXNzaW9uIikpLGxheW91dHMoIkxheW91dCIpLGxpdCgiLSIpLGxheW91dHMoIkxheW91dCIpLGxhYmVsKCJyaHMiLHNvcnQoIkV4cHJlc3Npb24iKSldLHthc3NvYyhsZWZ0KCkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new NonTerminalStackNode<IConstructor>(209, 4, "Expression", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(207, 2, cHJvZChsaXQoIi0iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQ1LDQ1KV0pXSx7fSk00, new int[] {45}, null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(204, 0, "Expression", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(208, 3, "layouts_Layout", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(206, 1, "layouts_Layout", null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgic3ViIixzb3J0KCJFeHByZXNzaW9uIikpLFtsYWJlbCgibGhzIixzb3J0KCJFeHByZXNzaW9uIikpLGxheW91dHMoIkxheW91dCIpLGxpdCgiLSIpLGxheW91dHMoIkxheW91dCIpLGxhYmVsKCJyaHMiLHNvcnQoIkV4cHJlc3Npb24iKSldLHthc3NvYyhsZWZ0KCkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiaWQiLHNvcnQoIkV4cHJlc3Npb24iKSksW2xhYmVsKCJuYW1lIixsZXgoIklkIikpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(170, 0, "Id", null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgiaWQiLHNvcnQoIkV4cHJlc3Npb24iKSksW2xhYmVsKCJuYW1lIixsZXgoIklkIikpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgibmF0Q29uIixzb3J0KCJFeHByZXNzaW9uIikpLFtsYWJlbCgibmF0Y29uIixsZXgoIk5hdHVyYWwiKSldLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new NonTerminalStackNode<IConstructor>(174, 0, "Natural", null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgibmF0Q29uIixzb3J0KCJFeHByZXNzaW9uIikpLFtsYWJlbCgibmF0Y29uIixsZXgoIk5hdHVyYWwiKSldLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiKCIpLGxheW91dHMoIkxheW91dCIpLGxhYmVsKCJlIixzb3J0KCJFeHByZXNzaW9uIikpLGxheW91dHMoIkxheW91dCIpLGxpdCgiKSIpXSx7YnJhY2tldCgpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[2] = new NonTerminalStackNode<IConstructor>(179, 2, "Expression", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(181, 3, "layouts_Layout", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(178, 1, "layouts_Layout", null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(177, 0, cHJvZChsaXQoIigiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pXSx7fSk00, new int[] {40}, null, null);
      tmp[4] = new LiteralStackNode<IConstructor>(182, 4, cHJvZChsaXQoIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {41}, null, null);
      builder.addAlternative(PicoParser.cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiKCIpLGxheW91dHMoIkxheW91dCIpLGxhYmVsKCJlIixzb3J0KCJFeHByZXNzaW9uIikpLGxheW91dHMoIkxheW91dCIpLGxpdCgiKSIpXSx7YnJhY2tldCgpfSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiY29uYyIsc29ydCgiRXhwcmVzc2lvbiIpKSxbbGFiZWwoImxocyIsc29ydCgiRXhwcmVzc2lvbiIpKSxsYXlvdXRzKCJMYXlvdXQiKSxsaXQoInx8IiksbGF5b3V0cygiTGF5b3V0IiksbGFiZWwoInJocyIsc29ydCgiRXhwcmVzc2lvbiIpKV0se2Fzc29jKGxlZnQoKSl9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJFeHByZXNzaW9uIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIkV4cHJlc3Npb25cIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIkV4cHJlc3Npb24iKSkpfSk00(builder);
      
        _init_cHJvZChsYWJlbCgic3RyQ29uIixzb3J0KCJFeHByZXNzaW9uIikpLFtsYWJlbCgic3RyaW5nIixsZXgoIlN0cmluZyIpKV0se30p(builder);
      
        _init_cHJvZChsYWJlbCgiYWRkIixzb3J0KCJFeHByZXNzaW9uIikpLFtsYWJlbCgibGhzIixzb3J0KCJFeHByZXNzaW9uIikpLGxheW91dHMoIkxheW91dCIpLGxpdCgiKyIpLGxheW91dHMoIkxheW91dCIpLGxhYmVsKCJyaHMiLHNvcnQoIkV4cHJlc3Npb24iKSldLHthc3NvYyhsZWZ0KCkpfSk00(builder);
      
        _init_cHJvZChsYWJlbCgic3ViIixzb3J0KCJFeHByZXNzaW9uIikpLFtsYWJlbCgibGhzIixzb3J0KCJFeHByZXNzaW9uIikpLGxheW91dHMoIkxheW91dCIpLGxpdCgiLSIpLGxheW91dHMoIkxheW91dCIpLGxhYmVsKCJyaHMiLHNvcnQoIkV4cHJlc3Npb24iKSldLHthc3NvYyhsZWZ0KCkpfSk00(builder);
      
        _init_cHJvZChsYWJlbCgiaWQiLHNvcnQoIkV4cHJlc3Npb24iKSksW2xhYmVsKCJuYW1lIixsZXgoIklkIikpXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgibmF0Q29uIixzb3J0KCJFeHByZXNzaW9uIikpLFtsYWJlbCgibmF0Y29uIixsZXgoIk5hdHVyYWwiKSldLHt9KQ0000(builder);
      
        _init_cHJvZChzb3J0KCJFeHByZXNzaW9uIiksW2xpdCgiKCIpLGxheW91dHMoIkxheW91dCIpLGxhYmVsKCJlIixzb3J0KCJFeHByZXNzaW9uIikpLGxheW91dHMoIkxheW91dCIpLGxpdCgiKSIpXSx7YnJhY2tldCgpfSk00(builder);
      
    }
  }
	
  protected static class layouts_$default$ {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYXlvdXRzKCIkZGVmYXVsdCQiKSxbXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new EpsilonStackNode<IConstructor>(213, 0);
      builder.addAlternative(PicoParser.cHJvZChsYXlvdXRzKCIkZGVmYXVsdCQiKSxbXSx7fSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYXlvdXRzKCIkZGVmYXVsdCQiKSxbXSx7fSk00(builder);
      
    }
  }
	
  protected static class Type {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgibmF0dXJhbCIsc29ydCgiVHlwZSIpKSxbbGl0KCJuYXR1cmFsIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(231, 0, cHJvZChsaXQoIm5hdHVyYWwiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTcsMTE3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKV0se30p, new int[] {110,97,116,117,114,97,108}, null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgibmF0dXJhbCIsc29ydCgiVHlwZSIpKSxbbGl0KCJuYXR1cmFsIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJUeXBlIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlR5cGVcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlR5cGUiKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new CharStackNode<IConstructor>(239, 4, new int[][]{{0,0}}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(234, 0, new int[][]{{0,0}}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(238, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(237, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(235, 1, cHJvZChsaXQoInNvcnQoXCJUeXBlXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDg0LDg0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMjEsMTIxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000, new int[] {115,111,114,116,40,34,84,121,112,101,34,41}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(236, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJUeXBlIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlR5cGVcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlR5cGUiKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgic3RyaW5nIixzb3J0KCJUeXBlIikpLFtsaXQoInN0cmluZyIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new LiteralStackNode<IConstructor>(243, 0, cHJvZChsaXQoInN0cmluZyIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAzLDEwMyldKV0se30p, new int[] {115,116,114,105,110,103}, null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgic3RyaW5nIixzb3J0KCJUeXBlIikpLFtsaXQoInN0cmluZyIpXSx7fSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgibmF0dXJhbCIsc29ydCgiVHlwZSIpKSxbbGl0KCJuYXR1cmFsIildLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJUeXBlIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlR5cGVcIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlR5cGUiKSkpfSk00(builder);
      
        _init_cHJvZChsYWJlbCgic3RyaW5nIixzb3J0KCJUeXBlIikpLFtsaXQoInN0cmluZyIpXSx7fSk00(builder);
      
    }
  }
	
  protected static class Declaration {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zdGFyLXNlcHMoc29ydChcIkRlY2xhcmF0aW9uXCIpLFtsaXQoXCIsXCIpXSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJEZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMYXlvdXQiKSxsaXQoIiwiKSxsYXlvdXRzKCJMYXlvdXQiKV0pKSl9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new LiteralStackNode<IConstructor>(249, 1, cHJvZChsaXQoIlxcaXRlci1zdGFyLXNlcHMoc29ydChcIkRlY2xhcmF0aW9uXCIpLFtsaXQoXCIsXCIpXSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkyLDkyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ1LDQ1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2OCw2OCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NCw0NCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTEsOTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNSwxMDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDQsNDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTMsOTMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {92,105,116,101,114,45,115,116,97,114,45,115,101,112,115,40,115,111,114,116,40,34,68,101,99,108,97,114,97,116,105,111,110,34,41,44,91,108,105,116,40,34,44,34,41,93,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(252, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(251, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(250, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(253, 4, new int[][]{{0,0}}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(248, 0, new int[][]{{0,0}}, null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zdGFyLXNlcHMoc29ydChcIkRlY2xhcmF0aW9uXCIpLFtsaXQoXCIsXCIpXSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJEZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMYXlvdXQiKSxsaXQoIiwiKSxsYXlvdXRzKCJMYXlvdXQiKV0pKSl9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiZGVjbCIsc29ydCgiRGVjbGFyYXRpb24iKSksW2xhYmVsKCJpZCIsbGV4KCJJZCIpKSxsYXlvdXRzKCJMYXlvdXQiKSxsaXQoIjoiKSxsYXlvdXRzKCJMYXlvdXQiKSxsYWJlbCgidHAiLHNvcnQoIlR5cGUiKSldLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new NonTerminalStackNode<IConstructor>(265, 3, "layouts_Layout", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(263, 1, "layouts_Layout", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(261, 0, "Id", null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(266, 4, "Type", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(264, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgiZGVjbCIsc29ydCgiRGVjbGFyYXRpb24iKSksW2xhYmVsKCJpZCIsbGV4KCJJZCIpKSxsYXlvdXRzKCJMYXlvdXQiKSxsaXQoIjoiKSxsYXlvdXRzKCJMYXlvdXQiKSxsYWJlbCgidHAiLHNvcnQoIlR5cGUiKSldLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJEZWNsYXJhdGlvblwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiRGVjbGFyYXRpb24iKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new ListStackNode<IConstructor>(274, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(273, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(271, 1, cHJvZChsaXQoInNvcnQoXCJEZWNsYXJhdGlvblwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2OCw2OCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {115,111,114,116,40,34,68,101,99,108,97,114,97,116,105,111,110,34,41}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(270, 0, new int[][]{{0,0}}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(275, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(272, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJEZWNsYXJhdGlvblwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiRGVjbGFyYXRpb24iKSkpfSk00, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoIlxcaXRlci1zdGFyLXNlcHMoc29ydChcIkRlY2xhcmF0aW9uXCIpLFtsaXQoXCIsXCIpXSkiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJEZWNsYXJhdGlvbiIpLFtsYXlvdXRzKCJMYXlvdXQiKSxsaXQoIiwiKSxsYXlvdXRzKCJMYXlvdXQiKV0pKSl9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiZGVjbCIsc29ydCgiRGVjbGFyYXRpb24iKSksW2xhYmVsKCJpZCIsbGV4KCJJZCIpKSxsYXlvdXRzKCJMYXlvdXQiKSxsaXQoIjoiKSxsYXlvdXRzKCJMYXlvdXQiKSxsYWJlbCgidHAiLHNvcnQoIlR5cGUiKSldLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJEZWNsYXJhdGlvbiIpKSxbXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKSxsaXQoInNvcnQoXCJEZWNsYXJhdGlvblwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoc29ydCgiRGVjbGFyYXRpb24iKSkpfSk00(builder);
      
    }
  }
	
  protected static class Id {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsZXgoIklkIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5NywxMjIpXSksY29uZGl0aW9uYWwoXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpLHJhbmdlKDk3LDEyMildKSkse1xub3QtZm9sbG93KFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NykscmFuZ2UoOTcsMTIyKV0pKX0pXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[2];
      
      tmp[0] = new CharStackNode<IConstructor>(452, 0, new int[][]{{97,122}}, null, null);
      tmp[1] = new ListStackNode<IConstructor>(456, 1, cmVndWxhcihcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NykscmFuZ2UoOTcsMTIyKV0pKSk00, new CharStackNode<IConstructor>(453, 0, new int[][]{{48,57},{97,122}}, null, null), false, null, new ICompletionFilter[] {new CharFollowRestriction(new int[][]{{48,57},{97,122}})});
      builder.addAlternative(PicoParser.cHJvZChsZXgoIklkIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5NywxMjIpXSksY29uZGl0aW9uYWwoXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpLHJhbmdlKDk3LDEyMildKSkse1xub3QtZm9sbG93KFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NykscmFuZ2UoOTcsMTIyKV0pKX0pXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIklkIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIklkXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihsZXgoIklkIikpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new CharStackNode<IConstructor>(459, 0, new int[][]{{0,0}}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(464, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(461, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(463, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(462, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(460, 1, cHJvZChsaXQoInNvcnQoXCJJZFwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg3Myw3MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAwLDEwMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {115,111,114,116,40,34,73,100,34,41}, null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIklkIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIklkXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihsZXgoIklkIikpKX0p, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsZXgoIklkIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5NywxMjIpXSksY29uZGl0aW9uYWwoXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpLHJhbmdlKDk3LDEyMildKSkse1xub3QtZm9sbG93KFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NykscmFuZ2UoOTcsMTIyKV0pKX0pXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIklkIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIklkXCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihsZXgoIklkIikpKX0p(builder);
      
    }
  }
	
  protected static class layouts_Layout {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYXlvdXRzKCJMYXlvdXQiKSxbY29uZGl0aW9uYWwoXGl0ZXItc3RhcihsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpLHtcbm90LWZvbGxvdyhcY2hhci1jbGFzcyhbcmFuZ2UoOSwxMCkscmFuZ2UoMTMsMTMpLHJhbmdlKDMyLDMyKSxyYW5nZSgzNywzNyldKSl9KV0se30p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new ListStackNode<IConstructor>(499, 0, cmVndWxhcihcaXRlci1zdGFyKGxleCgiV2hpdGVzcGFjZUFuZENvbW1lbnQiKSkp, new NonTerminalStackNode<IConstructor>(496, 0, "WhitespaceAndComment", null, null), false, null, new ICompletionFilter[] {new CharFollowRestriction(new int[][]{{9,10},{13,13},{32,32},{37,37}})});
      builder.addAlternative(PicoParser.cHJvZChsYXlvdXRzKCJMYXlvdXQiKSxbY29uZGl0aW9uYWwoXGl0ZXItc3RhcihsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpLHtcbm90LWZvbGxvdyhcY2hhci1jbGFzcyhbcmFuZ2UoOSwxMCkscmFuZ2UoMTMsMTMpLHJhbmdlKDMyLDMyKSxyYW5nZSgzNywzNyldKSl9KV0se30p, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYXlvdXRzKCJMYXlvdXQiKSxbY29uZGl0aW9uYWwoXGl0ZXItc3RhcihsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpLHtcbm90LWZvbGxvdyhcY2hhci1jbGFzcyhbcmFuZ2UoOSwxMCkscmFuZ2UoMTMsMTMpLHJhbmdlKDMyLDMyKSxyYW5nZSgzNywzNyldKSl9KV0se30p(builder);
      
    }
  }
	
  protected static class WhitespaceAndComment {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgid3MyIixsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpLFtsaXQoIiUiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSgxLDM2KSxyYW5nZSgzOCwxNjc3NzIxNSldKSksbGl0KCIlIildLHt0YWcoImNhdGVnb3J5IigiQ29tbWVudCIpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[3];
      
      tmp[2] = new LiteralStackNode<IConstructor>(614, 2, cHJvZChsaXQoIiUiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDM3LDM3KV0pXSx7fSk00, new int[] {37}, null, null);
      tmp[1] = new ListStackNode<IConstructor>(613, 1, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSgxLDM2KSxyYW5nZSgzOCwxNjc3NzIxNSldKSkp, new CharStackNode<IConstructor>(612, 0, new int[][]{{1,36},{38,16777215}}, null, null), true, null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(611, 0, cHJvZChsaXQoIiUiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDM3LDM3KV0pXSx7fSk00, new int[] {37}, null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgid3MyIixsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpLFtsaXQoIiUiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSgxLDM2KSxyYW5nZSgzOCwxNjc3NzIxNSldKSksbGl0KCIlIildLHt0YWcoImNhdGVnb3J5IigiQ29tbWVudCIpKX0p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIldoaXRlc3BhY2VBbmRDb21tZW50XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[1] = new LiteralStackNode<IConstructor>(618, 1, cHJvZChsaXQoInNvcnQoXCJXaGl0ZXNwYWNlQW5kQ29tbWVudFwiKSIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg4Nyw4NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA0LDEwNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEyLDExMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk5LDk5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2NSw2NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAwLDEwMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjcsNjcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOSwxMDkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {115,111,114,116,40,34,87,104,105,116,101,115,112,97,99,101,65,110,100,67,111,109,109,101,110,116,34,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(621, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(620, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[4] = new CharStackNode<IConstructor>(622, 4, new int[][]{{0,0}}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(617, 0, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(619, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIldoaXRlc3BhY2VBbmRDb21tZW50XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpKX0p, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgid3MzIixsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpLFtsaXQoIiUlIiksY29uZGl0aW9uYWwoXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoMSw5KSxyYW5nZSgxMSwxNjc3NzIxNSldKSkse1xlbmQtb2YtbGluZSgpfSldLHt0YWcoImNhdGVnb3J5IigiQ29tbWVudCIpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[2];
      
      tmp[0] = new LiteralStackNode<IConstructor>(626, 0, cHJvZChsaXQoIiUlIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgzNywzNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzcsMzcpXSldLHt9KQ0000, new int[] {37,37}, null, null);
      tmp[1] = new ListStackNode<IConstructor>(629, 1, cmVndWxhcihcaXRlci1zdGFyKFxjaGFyLWNsYXNzKFtyYW5nZSgxLDkpLHJhbmdlKDExLDE2Nzc3MjE1KV0pKSk00, new CharStackNode<IConstructor>(627, 0, new int[][]{{1,9},{11,16777215}}, null, null), false, null, new ICompletionFilter[] {new AtEndOfLineRequirement()});
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgid3MzIixsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpLFtsaXQoIiUlIiksY29uZGl0aW9uYWwoXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoMSw5KSxyYW5nZSgxMSwxNjc3NzIxNSldKSkse1xlbmQtb2YtbGluZSgpfSldLHt0YWcoImNhdGVnb3J5IigiQ29tbWVudCIpKX0p, tmp);
	}
    protected static final void _init_cHJvZChsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5LDEwKSxyYW5nZSgxMywxMykscmFuZ2UoMzIsMzIpXSldLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new CharStackNode<IConstructor>(631, 0, new int[][]{{9,10},{13,13},{32,32}}, null, null);
      builder.addAlternative(PicoParser.cHJvZChsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5LDEwKSxyYW5nZSgxMywxMykscmFuZ2UoMzIsMzIpXSldLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiXFxpdGVyLXN0YXIoc29ydChcIldoaXRlc3BhY2VBbmRDb21tZW50XCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc3RhcihsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpKSl9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new CharStackNode<IConstructor>(639, 4, new int[][]{{0,0}}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(638, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(637, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[0] = new CharStackNode<IConstructor>(634, 0, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(636, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(635, 1, cHJvZChsaXQoIlxcaXRlci1zdGFyKHNvcnQoXCJXaGl0ZXNwYWNlQW5kQ29tbWVudFwiKSkiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDkyLDkyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDg3LDg3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDQsMTA0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTIsMTEyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTksOTkpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDY1LDY1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDAsMTAwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg2Nyw2NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTExLDExMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA5LDEwOSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA5LDEwOSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {92,105,116,101,114,45,115,116,97,114,40,115,111,114,116,40,34,87,104,105,116,101,115,112,97,99,101,65,110,100,67,111,109,109,101,110,116,34,41,41}, null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiXFxpdGVyLXN0YXIoc29ydChcIldoaXRlc3BhY2VBbmRDb21tZW50XCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc3RhcihsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpKSl9KQ0000, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgid3MyIixsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpLFtsaXQoIiUiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSgxLDM2KSxyYW5nZSgzOCwxNjc3NzIxNSldKSksbGl0KCIlIildLHt0YWcoImNhdGVnb3J5IigiQ29tbWVudCIpKX0p(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIldoaXRlc3BhY2VBbmRDb21tZW50XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpKX0p(builder);
      
        _init_cHJvZChsYWJlbCgid3MzIixsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpLFtsaXQoIiUlIiksY29uZGl0aW9uYWwoXGl0ZXItc3RhcihcY2hhci1jbGFzcyhbcmFuZ2UoMSw5KSxyYW5nZSgxMSwxNjc3NzIxNSldKSkse1xlbmQtb2YtbGluZSgpfSldLHt0YWcoImNhdGVnb3J5IigiQ29tbWVudCIpKX0p(builder);
      
        _init_cHJvZChsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5LDEwKSxyYW5nZSgxMywxMykscmFuZ2UoMzIsMzIpXSldLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgiXFxpdGVyLXN0YXIoc29ydChcIldoaXRlc3BhY2VBbmRDb21tZW50XCIpKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc3RhcihsZXgoIldoaXRlc3BhY2VBbmRDb21tZW50IikpKSl9KQ0000(builder);
      
    }
  }
	
  protected static class Statement {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiaWZFbHNlU3RhdCIsc29ydCgiU3RhdGVtZW50IikpLFtsaXQoImlmIiksbGF5b3V0cygiTGF5b3V0IiksbGFiZWwoImNvbmQiLHNvcnQoIkV4cHJlc3Npb24iKSksbGF5b3V0cygiTGF5b3V0IiksbGl0KCJ0aGVuIiksbGF5b3V0cygiTGF5b3V0IiksbGFiZWwoInRoZW5QYXJ0IixcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RhdGVtZW50IiksW2xheW91dHMoIkxheW91dCIpLGxpdCgiOyIpLGxheW91dHMoIkxheW91dCIpXSkpLGxheW91dHMoIkxheW91dCIpLGxpdCgiZWxzZSIpLGxheW91dHMoIkxheW91dCIpLGxhYmVsKCJlbHNlUGFydCIsXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0YXRlbWVudCIpLFtsYXlvdXRzKCJMYXlvdXQiKSxsaXQoIjsiKSxsYXlvdXRzKCJMYXlvdXQiKV0pKSxsYXlvdXRzKCJMYXlvdXQiKSxsaXQoImZpIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[13];
      
      tmp[6] = new SeparatedListStackNode<IConstructor>(765, 6, cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RhdGVtZW50IiksW2xheW91dHMoIkxheW91dCIpLGxpdCgiOyIpLGxheW91dHMoIkxheW91dCIpXSkp, new NonTerminalStackNode<IConstructor>(761, 0, "Statement", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(762, 1, "layouts_Layout", null, null), new LiteralStackNode<IConstructor>(763, 2, cHJvZChsaXQoIjsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU5LDU5KV0pXSx7fSk00, new int[] {59}, null, null), new NonTerminalStackNode<IConstructor>(764, 3, "layouts_Layout", null, null)}, false, null, null);
      tmp[9] = new NonTerminalStackNode<IConstructor>(769, 9, "layouts_Layout", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(758, 3, "layouts_Layout", null, null);
      tmp[11] = new NonTerminalStackNode<IConstructor>(776, 11, "layouts_Layout", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(755, 1, "layouts_Layout", null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(760, 5, "layouts_Layout", null, null);
      tmp[7] = new NonTerminalStackNode<IConstructor>(767, 7, "layouts_Layout", null, null);
      tmp[8] = new LiteralStackNode<IConstructor>(768, 8, cHJvZChsaXQoImVsc2UiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSldLHt9KQ0000, new int[] {101,108,115,101}, null, null);
      tmp[4] = new LiteralStackNode<IConstructor>(759, 4, cHJvZChsaXQoInRoZW4iKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwNCwxMDQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwMSwxMDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMCwxMTApXSldLHt9KQ0000, new int[] {116,104,101,110}, null, null);
      tmp[12] = new LiteralStackNode<IConstructor>(777, 12, cHJvZChsaXQoImZpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMDIsMTAyKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pXSx7fSk00, new int[] {102,105}, null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(756, 2, "Expression", null, null);
      tmp[10] = new SeparatedListStackNode<IConstructor>(774, 10, cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RhdGVtZW50IiksW2xheW91dHMoIkxheW91dCIpLGxpdCgiOyIpLGxheW91dHMoIkxheW91dCIpXSkp, new NonTerminalStackNode<IConstructor>(770, 0, "Statement", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(771, 1, "layouts_Layout", null, null), new LiteralStackNode<IConstructor>(772, 2, cHJvZChsaXQoIjsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU5LDU5KV0pXSx7fSk00, new int[] {59}, null, null), new NonTerminalStackNode<IConstructor>(773, 3, "layouts_Layout", null, null)}, false, null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(754, 0, cHJvZChsaXQoImlmIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDIsMTAyKV0pXSx7fSk00, new int[] {105,102}, null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgiaWZFbHNlU3RhdCIsc29ydCgiU3RhdGVtZW50IikpLFtsaXQoImlmIiksbGF5b3V0cygiTGF5b3V0IiksbGFiZWwoImNvbmQiLHNvcnQoIkV4cHJlc3Npb24iKSksbGF5b3V0cygiTGF5b3V0IiksbGl0KCJ0aGVuIiksbGF5b3V0cygiTGF5b3V0IiksbGFiZWwoInRoZW5QYXJ0IixcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RhdGVtZW50IiksW2xheW91dHMoIkxheW91dCIpLGxpdCgiOyIpLGxheW91dHMoIkxheW91dCIpXSkpLGxheW91dHMoIkxheW91dCIpLGxpdCgiZWxzZSIpLGxheW91dHMoIkxheW91dCIpLGxhYmVsKCJlbHNlUGFydCIsXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0YXRlbWVudCIpLFtsYXlvdXRzKCJMYXlvdXQiKSxsaXQoIjsiKSxsYXlvdXRzKCJMYXlvdXQiKV0pKSxsYXlvdXRzKCJMYXlvdXQiKSxsaXQoImZpIildLHt9KQ0000, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiYXNnU3RhdCIsc29ydCgiU3RhdGVtZW50IikpLFtsYWJlbCgidmFyIixsZXgoIklkIikpLGxheW91dHMoIkxheW91dCIpLGxpdCgiOj0iKSxsYXlvdXRzKCJMYXlvdXQiKSxsYWJlbCgidmFsIixzb3J0KCJFeHByZXNzaW9uIikpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[3] = new NonTerminalStackNode<IConstructor>(784, 3, "layouts_Layout", null, null);
      tmp[4] = new NonTerminalStackNode<IConstructor>(785, 4, "Expression", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(782, 1, "layouts_Layout", null, null);
      tmp[0] = new NonTerminalStackNode<IConstructor>(780, 0, "Id", null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(783, 2, cHJvZChsaXQoIjo9IiksW1xjaGFyLWNsYXNzKFtyYW5nZSg1OCw1OCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNjEsNjEpXSldLHt9KQ0000, new int[] {58,61}, null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgiYXNnU3RhdCIsc29ydCgiU3RhdGVtZW50IikpLFtsYWJlbCgidmFyIixsZXgoIklkIikpLGxheW91dHMoIkxheW91dCIpLGxpdCgiOj0iKSxsYXlvdXRzKCJMYXlvdXQiKSxsYWJlbCgidmFsIixzb3J0KCJFeHByZXNzaW9uIikpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgid2hpbGVTdGF0Iixzb3J0KCJTdGF0ZW1lbnQiKSksW2xpdCgid2hpbGUiKSxsYXlvdXRzKCJMYXlvdXQiKSxsYWJlbCgiY29uZCIsc29ydCgiRXhwcmVzc2lvbiIpKSxsYXlvdXRzKCJMYXlvdXQiKSxsaXQoImRvIiksbGF5b3V0cygiTGF5b3V0IiksbGFiZWwoImJvZHkiLFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJTdGF0ZW1lbnQiKSxbbGF5b3V0cygiTGF5b3V0IiksbGl0KCI7IiksbGF5b3V0cygiTGF5b3V0IildKSksbGF5b3V0cygiTGF5b3V0IiksbGl0KCJvZCIpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[9];
      
      tmp[6] = new SeparatedListStackNode<IConstructor>(800, 6, cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RhdGVtZW50IiksW2xheW91dHMoIkxheW91dCIpLGxpdCgiOyIpLGxheW91dHMoIkxheW91dCIpXSkp, new NonTerminalStackNode<IConstructor>(796, 0, "Statement", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(797, 1, "layouts_Layout", null, null), new LiteralStackNode<IConstructor>(798, 2, cHJvZChsaXQoIjsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU5LDU5KV0pXSx7fSk00, new int[] {59}, null, null), new NonTerminalStackNode<IConstructor>(799, 3, "layouts_Layout", null, null)}, false, null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(791, 2, "Expression", null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(793, 3, "layouts_Layout", null, null);
      tmp[4] = new LiteralStackNode<IConstructor>(794, 4, cHJvZChsaXQoImRvIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMDAsMTAwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pXSx7fSk00, new int[] {100,111}, null, null);
      tmp[0] = new LiteralStackNode<IConstructor>(789, 0, cHJvZChsaXQoIndoaWxlIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTksMTE5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDQsMTA0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDUsMTA1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDgsMTA4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pXSx7fSk00, new int[] {119,104,105,108,101}, null, null);
      tmp[7] = new NonTerminalStackNode<IConstructor>(802, 7, "layouts_Layout", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(790, 1, "layouts_Layout", null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(795, 5, "layouts_Layout", null, null);
      tmp[8] = new LiteralStackNode<IConstructor>(803, 8, cHJvZChsaXQoIm9kIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDAsMTAwKV0pXSx7fSk00, new int[] {111,100}, null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgid2hpbGVTdGF0Iixzb3J0KCJTdGF0ZW1lbnQiKSksW2xpdCgid2hpbGUiKSxsYXlvdXRzKCJMYXlvdXQiKSxsYWJlbCgiY29uZCIsc29ydCgiRXhwcmVzc2lvbiIpKSxsYXlvdXRzKCJMYXlvdXQiKSxsaXQoImRvIiksbGF5b3V0cygiTGF5b3V0IiksbGFiZWwoImJvZHkiLFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJTdGF0ZW1lbnQiKSxbbGF5b3V0cygiTGF5b3V0IiksbGl0KCI7IiksbGF5b3V0cygiTGF5b3V0IildKSksbGF5b3V0cygiTGF5b3V0IiksbGl0KCJvZCIpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdGF0ZW1lbnQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiU3RhdGVtZW50XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJTdGF0ZW1lbnQiKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new CharStackNode<IConstructor>(811, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(808, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(806, 0, new int[][]{{0,0}}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(810, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(809, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(807, 1, cHJvZChsaXQoInNvcnQoXCJTdGF0ZW1lbnRcIikiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODMsODMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000, new int[] {115,111,114,116,40,34,83,116,97,116,101,109,101,110,116,34,41}, null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdGF0ZW1lbnQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiU3RhdGVtZW50XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJTdGF0ZW1lbnQiKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdGF0ZW1lbnQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc3Rhci1zZXBzKHNvcnQoXCJTdGF0ZW1lbnRcIiksW2xpdChcIjtcIildKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0YXRlbWVudCIpLFtsYXlvdXRzKCJMYXlvdXQiKSxsaXQoIjsiKSxsYXlvdXRzKCJMYXlvdXQiKV0pKSl9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[4] = new CharStackNode<IConstructor>(820, 4, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(817, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(815, 0, new int[][]{{0,0}}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(819, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(818, 0, new int[][]{{48,57}}, null, null), true, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(816, 1, cHJvZChsaXQoIlxcaXRlci1zdGFyLXNlcHMoc29ydChcIlN0YXRlbWVudFwiKSxbbGl0KFwiO1wiKV0pIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5Miw5MildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDUsNDUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0NSw0NSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEyLDExMildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE1LDExNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNSwxMTUpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExMSwxMTEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNCwxMTQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQwLDQwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoODMsODMpXSksXGNoYXItY2xhc3MoW3JhbmdlKDExNiwxMTYpXSksXGNoYXItY2xhc3MoW3JhbmdlKDk3LDk3KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDksMTA5KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDEsMTAxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTAsMTEwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgzNCwzNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQ0LDQ0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5MSw5MSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA4LDEwOCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDAsNDApXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg1OSw1OSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Myw5MyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoNDEsNDEpXSldLHt9KQ0000, new int[] {92,105,116,101,114,45,115,116,97,114,45,115,101,112,115,40,115,111,114,116,40,34,83,116,97,116,101,109,101,110,116,34,41,44,91,108,105,116,40,34,59,34,41,93,41}, null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdGF0ZW1lbnQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc3Rhci1zZXBzKHNvcnQoXCJTdGF0ZW1lbnRcIiksW2xpdChcIjtcIildKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0YXRlbWVudCIpLFtsYXlvdXRzKCJMYXlvdXQiKSxsaXQoIjsiKSxsYXlvdXRzKCJMYXlvdXQiKV0pKSl9KQ0000, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiaWZFbHNlU3RhdCIsc29ydCgiU3RhdGVtZW50IikpLFtsaXQoImlmIiksbGF5b3V0cygiTGF5b3V0IiksbGFiZWwoImNvbmQiLHNvcnQoIkV4cHJlc3Npb24iKSksbGF5b3V0cygiTGF5b3V0IiksbGl0KCJ0aGVuIiksbGF5b3V0cygiTGF5b3V0IiksbGFiZWwoInRoZW5QYXJ0IixcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RhdGVtZW50IiksW2xheW91dHMoIkxheW91dCIpLGxpdCgiOyIpLGxheW91dHMoIkxheW91dCIpXSkpLGxheW91dHMoIkxheW91dCIpLGxpdCgiZWxzZSIpLGxheW91dHMoIkxheW91dCIpLGxhYmVsKCJlbHNlUGFydCIsXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0YXRlbWVudCIpLFtsYXlvdXRzKCJMYXlvdXQiKSxsaXQoIjsiKSxsYXlvdXRzKCJMYXlvdXQiKV0pKSxsYXlvdXRzKCJMYXlvdXQiKSxsaXQoImZpIildLHt9KQ0000(builder);
      
        _init_cHJvZChsYWJlbCgiYXNnU3RhdCIsc29ydCgiU3RhdGVtZW50IikpLFtsYWJlbCgidmFyIixsZXgoIklkIikpLGxheW91dHMoIkxheW91dCIpLGxpdCgiOj0iKSxsYXlvdXRzKCJMYXlvdXQiKSxsYWJlbCgidmFsIixzb3J0KCJFeHByZXNzaW9uIikpXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgid2hpbGVTdGF0Iixzb3J0KCJTdGF0ZW1lbnQiKSksW2xpdCgid2hpbGUiKSxsYXlvdXRzKCJMYXlvdXQiKSxsYWJlbCgiY29uZCIsc29ydCgiRXhwcmVzc2lvbiIpKSxsYXlvdXRzKCJMYXlvdXQiKSxsaXQoImRvIiksbGF5b3V0cygiTGF5b3V0IiksbGFiZWwoImJvZHkiLFxpdGVyLXN0YXItc2Vwcyhzb3J0KCJTdGF0ZW1lbnQiKSxbbGF5b3V0cygiTGF5b3V0IiksbGl0KCI7IiksbGF5b3V0cygiTGF5b3V0IildKSksbGF5b3V0cygiTGF5b3V0IiksbGl0KCJvZCIpXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdGF0ZW1lbnQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiU3RhdGVtZW50XCIpIiksbGl0KCI6IiksaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpLFxjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSldLHt0YWcoImhvbGVUeXBlIihzb3J0KCJTdGF0ZW1lbnQiKSkpfSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJTdGF0ZW1lbnQiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJcXGl0ZXItc3Rhci1zZXBzKHNvcnQoXCJTdGF0ZW1lbnRcIiksW2xpdChcIjtcIildKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIoXGl0ZXItc3Rhci1zZXBzKHNvcnQoIlN0YXRlbWVudCIpLFtsYXlvdXRzKCJMYXlvdXQiKSxsaXQoIjsiKSxsYXlvdXRzKCJMYXlvdXQiKV0pKSl9KQ0000(builder);
      
    }
  }
	
  protected static class Natural {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsZXgoIk5hdHVyYWwiKSxbaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpXSx7fSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[1];
      
      tmp[0] = new ListStackNode<IConstructor>(857, 0, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(856, 0, new int[][]{{48,57}}, null, null), true, null, null);
      builder.addAlternative(PicoParser.cHJvZChsZXgoIk5hdHVyYWwiKSxbaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpXSx7fSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIk5hdHVyYWwiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiTmF0dXJhbFwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIobGV4KCJOYXR1cmFsIikpKX0p(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[2] = new LiteralStackNode<IConstructor>(862, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(865, 4, new int[][]{{0,0}}, null, null);
      tmp[0] = new CharStackNode<IConstructor>(860, 0, new int[][]{{0,0}}, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(861, 1, cHJvZChsaXQoInNvcnQoXCJOYXR1cmFsXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDc4LDc4KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE2LDExNildKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE3LDExNyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTE0LDExNCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoOTcsOTcpXSksXGNoYXItY2xhc3MoW3JhbmdlKDEwOCwxMDgpXSksXGNoYXItY2xhc3MoW3JhbmdlKDM0LDM0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MSw0MSldKV0se30p, new int[] {115,111,114,116,40,34,78,97,116,117,114,97,108,34,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(864, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(863, 0, new int[][]{{48,57}}, null, null), true, null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIk5hdHVyYWwiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiTmF0dXJhbFwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIobGV4KCJOYXR1cmFsIikpKX0p, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsZXgoIk5hdHVyYWwiKSxbaXRlcihcY2hhci1jbGFzcyhbcmFuZ2UoNDgsNTcpXSkpXSx7fSk00(builder);
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixsZXgoIk5hdHVyYWwiKSksW1xjaGFyLWNsYXNzKFtyYW5nZSgwLDApXSksbGl0KCJzb3J0KFwiTmF0dXJhbFwiKSIpLGxpdCgiOiIpLGl0ZXIoXGNoYXItY2xhc3MoW3JhbmdlKDQ4LDU3KV0pKSxcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pXSx7dGFnKCJob2xlVHlwZSIobGV4KCJOYXR1cmFsIikpKX0p(builder);
      
    }
  }
	
  protected static class Program {
    public final static AbstractStackNode<IConstructor>[] EXPECTS;
    static{
      ExpectBuilder<IConstructor> builder = new ExpectBuilder<IConstructor>(_resultStoreIdMappings);
      init(builder);
      EXPECTS = builder.buildExpectArray();
    }
    
    protected static final void _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQcm9ncmFtIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlByb2dyYW1cIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlByb2dyYW0iKSkpfSk00(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[5];
      
      tmp[0] = new CharStackNode<IConstructor>(1105, 0, new int[][]{{0,0}}, null, null);
      tmp[2] = new LiteralStackNode<IConstructor>(1107, 2, cHJvZChsaXQoIjoiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU4LDU4KV0pXSx7fSk00, new int[] {58}, null, null);
      tmp[4] = new CharStackNode<IConstructor>(1110, 4, new int[][]{{0,0}}, null, null);
      tmp[1] = new LiteralStackNode<IConstructor>(1106, 1, cHJvZChsaXQoInNvcnQoXCJQcm9ncmFtXCIpIiksW1xjaGFyLWNsYXNzKFtyYW5nZSgxMTUsMTE1KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTYsMTE2KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg0MCw0MCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDgwLDgwKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTEsMTExKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMDMsMTAzKV0pLFxjaGFyLWNsYXNzKFtyYW5nZSgxMTQsMTE0KV0pLFxjaGFyLWNsYXNzKFtyYW5nZSg5Nyw5NyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA5LDEwOSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMzQsMzQpXSksXGNoYXItY2xhc3MoW3JhbmdlKDQxLDQxKV0pXSx7fSk00, new int[] {115,111,114,116,40,34,80,114,111,103,114,97,109,34,41}, null, null);
      tmp[3] = new ListStackNode<IConstructor>(1109, 3, cmVndWxhcihpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSkp, new CharStackNode<IConstructor>(1108, 0, new int[][]{{48,57}}, null, null), true, null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQcm9ncmFtIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlByb2dyYW1cIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlByb2dyYW0iKSkpfSk00, tmp);
	}
    protected static final void _init_cHJvZChsYWJlbCgicHJvZ3JhbSIsc29ydCgiUHJvZ3JhbSIpKSxbbGl0KCJiZWdpbiIpLGxheW91dHMoIkxheW91dCIpLGxhYmVsKCJkZWNscyIsc29ydCgiRGVjbGFyYXRpb25zIikpLGxheW91dHMoIkxheW91dCIpLGxhYmVsKCJib2R5IixcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RhdGVtZW50IiksW2xheW91dHMoIkxheW91dCIpLGxpdCgiOyIpLGxheW91dHMoIkxheW91dCIpXSkpLGxheW91dHMoIkxheW91dCIpLGxpdCgiZW5kIildLHt9KQ0000(ExpectBuilder<IConstructor> builder) {
      AbstractStackNode<IConstructor>[] tmp = (AbstractStackNode<IConstructor>[]) new AbstractStackNode[7];
      
      tmp[0] = new LiteralStackNode<IConstructor>(1114, 0, cHJvZChsaXQoImJlZ2luIiksW1xjaGFyLWNsYXNzKFtyYW5nZSg5OCw5OCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAzLDEwMyldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTA1LDEwNSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKV0se30p, new int[] {98,101,103,105,110}, null, null);
      tmp[4] = new SeparatedListStackNode<IConstructor>(1123, 4, cmVndWxhcihcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RhdGVtZW50IiksW2xheW91dHMoIkxheW91dCIpLGxpdCgiOyIpLGxheW91dHMoIkxheW91dCIpXSkp, new NonTerminalStackNode<IConstructor>(1119, 0, "Statement", null, null), (AbstractStackNode<IConstructor>[]) new AbstractStackNode[]{new NonTerminalStackNode<IConstructor>(1120, 1, "layouts_Layout", null, null), new LiteralStackNode<IConstructor>(1121, 2, cHJvZChsaXQoIjsiKSxbXGNoYXItY2xhc3MoW3JhbmdlKDU5LDU5KV0pXSx7fSk00, new int[] {59}, null, null), new NonTerminalStackNode<IConstructor>(1122, 3, "layouts_Layout", null, null)}, false, null, null);
      tmp[2] = new NonTerminalStackNode<IConstructor>(1116, 2, "Declarations", null, null);
      tmp[6] = new LiteralStackNode<IConstructor>(1126, 6, cHJvZChsaXQoImVuZCIpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMTAxLDEwMSldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTEwLDExMCldKSxcY2hhci1jbGFzcyhbcmFuZ2UoMTAwLDEwMCldKV0se30p, new int[] {101,110,100}, null, null);
      tmp[3] = new NonTerminalStackNode<IConstructor>(1118, 3, "layouts_Layout", null, null);
      tmp[1] = new NonTerminalStackNode<IConstructor>(1115, 1, "layouts_Layout", null, null);
      tmp[5] = new NonTerminalStackNode<IConstructor>(1125, 5, "layouts_Layout", null, null);
      builder.addAlternative(PicoParser.cHJvZChsYWJlbCgicHJvZ3JhbSIsc29ydCgiUHJvZ3JhbSIpKSxbbGl0KCJiZWdpbiIpLGxheW91dHMoIkxheW91dCIpLGxhYmVsKCJkZWNscyIsc29ydCgiRGVjbGFyYXRpb25zIikpLGxheW91dHMoIkxheW91dCIpLGxhYmVsKCJib2R5IixcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RhdGVtZW50IiksW2xheW91dHMoIkxheW91dCIpLGxpdCgiOyIpLGxheW91dHMoIkxheW91dCIpXSkpLGxheW91dHMoIkxheW91dCIpLGxpdCgiZW5kIildLHt9KQ0000, tmp);
	}
    public static void init(ExpectBuilder<IConstructor> builder){
      
        _init_cHJvZChsYWJlbCgiJE1ldGFIb2xlIixzb3J0KCJQcm9ncmFtIikpLFtcY2hhci1jbGFzcyhbcmFuZ2UoMCwwKV0pLGxpdCgic29ydChcIlByb2dyYW1cIikiKSxsaXQoIjoiKSxpdGVyKFxjaGFyLWNsYXNzKFtyYW5nZSg0OCw1NyldKSksXGNoYXItY2xhc3MoW3JhbmdlKDAsMCldKV0se3RhZygiaG9sZVR5cGUiKHNvcnQoIlByb2dyYW0iKSkpfSk00(builder);
      
        _init_cHJvZChsYWJlbCgicHJvZ3JhbSIsc29ydCgiUHJvZ3JhbSIpKSxbbGl0KCJiZWdpbiIpLGxheW91dHMoIkxheW91dCIpLGxhYmVsKCJkZWNscyIsc29ydCgiRGVjbGFyYXRpb25zIikpLGxheW91dHMoIkxheW91dCIpLGxhYmVsKCJib2R5IixcaXRlci1zdGFyLXNlcHMoc29ydCgiU3RhdGVtZW50IiksW2xheW91dHMoIkxheW91dCIpLGxpdCgiOyIpLGxheW91dHMoIkxheW91dCIpXSkpLGxheW91dHMoIkxheW91dCIpLGxpdCgiZW5kIildLHt9KQ0000(builder);
      
    }
  }
	
  // Parse methods    
  
  public AbstractStackNode<IConstructor>[] start__Program() {
    return start__Program.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] Declarations() {
    return Declarations.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] String() {
    return String.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] Expression() {
    return Expression.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] layouts_$default$() {
    return layouts_$default$.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] Type() {
    return Type.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] Declaration() {
    return Declaration.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] Id() {
    return Id.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] layouts_Layout() {
    return layouts_Layout.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] WhitespaceAndComment() {
    return WhitespaceAndComment.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] Statement() {
    return Statement.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] Natural() {
    return Natural.EXPECTS;
  }
  public AbstractStackNode<IConstructor>[] Program() {
    return Program.EXPECTS;
  }
}